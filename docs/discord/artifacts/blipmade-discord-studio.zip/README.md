# Blipmade Discord Studio

A production-grade, developer-infrastructure visual Discord server builder, template manager, and deployment studio designed specifically for **Blipmade** hosting community and infrastructure operations.

---

## 1. Overview & Purpose

Blipmade Discord Studio provides a visual, audited interface to inspect, design, diff, and deploy the official Discord community server for [Blipmade](https://blipmade.com).

Unlike Discord's native template system (which only creates brand-new servers), Blipmade Discord Studio works directly against **EXISTING** Discord servers. It calculates precise structural diffs and applies changes through the official Discord REST API v10 using safe reconciliation strategies (`MERGE`, `SYNC`, or restricted `REPLACE`).

---

## 2. Core Architecture

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Plus Jakarta Sans & JetBrains Mono fonts.
- **Backend**: Node.js, Express, official Discord REST API v10 integration.
- **Visual Design**: Blipmade developer visual identity (`#060606` canvas, `#0D0D0D` elevated surfaces, `#F5F2EB` text, `#E64A4A` Blipmade crimson accent).
- **Security & Privacy**: Zero client-side exposure of bot tokens, OAuth client secrets, or webhook endpoints. All Discord API operations execute strictly on the server.
- **Dual-Mode Engine**:
  - **Live Mode**: Uses the official Discord REST API v10 and bot permissions bitfield (`268435456`) to manage real Discord servers.
  - **Demo Mode**: Zero-credential simulated Discord environment (`Blipmade Community (Demo Guild)`), enabling instant experimentation with hierarchy, visual channel builder, diffs, and simulated deployments.

---

## 3. Official Blipmade Template Specification

Preloaded as the default blueprint: `Blipmade | Official Hosting Community` (v1.2.0):

### Hierarchy & Categories:

1. **`START HERE`**
   - `#welcome` — Read-only for `@everyone`. Pinned welcome embed with docs, status, and tickets links.
   - `#rules` — Read-only for `@everyone`. Contains the 8 official Blipmade community standards.
   - `#announcements` — Announcement channel (`type: 5`). Platform releases, datacenter node upgrades.
   - `#service-status` — Read-only. Connected to Blipmade incident alerts and probers.

2. **`HELP & SUPPORT`**
   - `#community-help` — Forum/Text channel with 10s slowmode for peer troubleshooting. Includes redirect notice to official authenticated ticket system for private billing/invoices.
   - `#guides` — Read-only. Curated tutorials for Linux kernel tuning, Minecraft mods, Docker, and reverse proxy setup.
   - `#suggestions` — 60s slowmode for community feature requests.

3. **`HOSTING`**
   - `#vps-hosting` — Discussions on Linux distros, Docker, kernel tuning, and cloud VPS architecture.
   - `#game-servers` — Minecraft (Paper/Forge/Fabric), Rust, Palworld, ARK, and dedicated game server optimization.
   - `#apps-and-bots` — Node.js, Python, Go, and Discord bot container hosting.
   - `#domains-and-email` — DNS records, SSL/TLS certificates, reverse proxy, and SPF/DKIM/DMARC routing.

4. **`COMMUNITY`**
   - `#general` — Casual hosting chatter and developer hanging out.
   - `#showcase` — Customer server showcases, benchmarks, and bot demos.
   - `General Voice` — Voice channel (`type: 2`).

5. **`BLIPMADE TEAM (PRIVATE)`**
   - Restricted access: `@everyone` strictly denied `ViewChannel` (`1024`).
   - `#staff-chat` — Private coordination channel for staff.
   - `#ops-alerts` — Private telemetry alerts: CPU/RAM thresholds, node connectivity.
   - `#moderation-log` — Audit logs and security actions.

### Predefined Roles:
- **`Owner`** (`#E64A4A` / Blipmade Red, Hoisted, Position 5) — Platform Founders (visual designation, never transfers native Discord server ownership).
- **`Administrator`** (`#FF7676`, Hoisted, Position 4) — Infrastructure architects.
- **`Support Team`** (`#3B82F6` / Blue, Hoisted, Position 3) — Technical support staff.
- **`Verified Customer`** (`#10B981` / Emerald, Hoisted, Position 2) — Validated active Blipmade server tenant.
- **`Community Member`** (`#9E9B95` / Silver, Position 1) — Regular registered member.

---

## 4. Smart Reconciliation Strategies

1. **`MERGE` (Default & Recommended)**
   - Creates only missing roles, categories, and channels.
   - Preserves all existing content, positions, and permissions.
   - Zero deletions. Completely non-destructive.

2. **`SYNC`**
   - Compares the live server against the desired blueprint.
   - Applies additions and updates mismatched properties (topics, positions, slowmode).
   - Deletions are optional and require explicit opt-in.

3. **`REPLACE STRUCTURE` (Restricted)**
   - High-risk administrative operation.
   - Automatically generates a complete structural backup snapshot prior to changes.
   - Requires typing the exact confirmation phrase: `CONFIRM REPLACE BLIPMADE SERVER`.
   - Purges obsolete channels and provisions the exact template structure.

---

## 5. Discord Developer Portal Setup Guide

To connect a live Discord server to Blipmade Discord Studio:

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications).
2. Click **New Application** and name it `Blipmade Studio Bot`.
3. Under **Bot**, click **Reset Token** and copy your **Bot Token**.
4. In the **OAuth2** tab:
   - Copy the **Client ID**.
   - Add the Redirect URI: `http://localhost:3000/api/auth/discord/callback` (or your domain).
5. Generate an invite link using the studio's built-in generator or with permissions bitfield `268435456` (`Manage Roles`, `Manage Channels`, `Send Messages`, `Embed Links`, `View Audit Log`).
6. Invite the bot to your server. Ensure the bot's role is positioned **higher** than the roles it needs to manage in Discord server settings.
7. Paste the **Client ID** and **Bot Token** in Blipmade Discord Studio under **Settings**.

---

## 6. Environment Configuration (`.env`)

```bash
# Server port
PORT=3000

# Application Base URL
APP_URL=http://localhost:3000

# Discord Developer Credentials
DISCORD_CLIENT_ID=your_client_id_here
DISCORD_BOT_TOKEN=your_bot_token_here
DISCORD_REDIRECT_URI=http://localhost:3000/api/auth/discord/callback

# Blipmade Operational Webhooks (Optional)
BLIPMADE_STATUS_WEBHOOK_URL=https://discord.com/api/webhooks/...
BLIPMADE_OPS_WEBHOOK_URL=https://discord.com/api/webhooks/...
BLIPMADE_ANNOUNCEMENTS_WEBHOOK_URL=https://discord.com/api/webhooks/...

# Lock deployment strictly to one guild (Optional)
BLIPMADE_TARGET_GUILD_ID=
```

---

## 7. Build & Run Instructions

```bash
# Install dependencies
npm install

# Start full-stack development server (Express + Vite)
npm run dev

# Build production assets
npm run build

# Start production server
npm start

# Typecheck / Lint
npm run lint
```

---

## 8. Docker Deployment

```dockerfile
FROM node:22-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

---

## 9. Known Limitations

- **Message Content Restoration**: Structural backups store channel configurations, roles, and permission overwrites. Due to Discord API constraints and privacy regulations, historic chat messages cannot be bulk recreated.
- **Native Server Owner**: The native Discord server owner cannot have their ownership revoked or transferred via bot APIs. The `Owner` role in the studio is a visual leadership designation.
- **Discord Bot Role Hierarchy**: A Discord bot cannot assign or edit roles that sit higher than its own highest role in Discord's native role settings.
