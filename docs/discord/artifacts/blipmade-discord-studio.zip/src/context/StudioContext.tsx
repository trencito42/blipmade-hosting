/**
 * Studio Global State & Context Provider
 */

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  StudioStatus,
  GuildItem,
  GuildDetails,
  ServerTemplate,
  ChannelTemplate,
  RoleTemplate,
  ServerDiff,
} from '../types/discord.ts';
import {
  fetchStudioStatus,
  fetchGuilds,
  fetchGuildDetails,
  fetchTemplates,
  calculateDiff,
} from '../api/client.ts';

export type StudioTab = 'overview' | 'builder' | 'templates' | 'roles' | 'messages' | 'activity' | 'settings';

interface StudioContextType {
  status: StudioStatus | null;
  guilds: GuildItem[];
  selectedGuild: GuildItem | null;
  guildDetails: GuildDetails | null;
  templates: ServerTemplate[];
  activeTemplate: ServerTemplate;
  selectedChannelName: string | null;
  selectedCategoryName: string | null;
  selectedRoleName: string | null;
  activeTab: StudioTab;
  isDeployModalOpen: boolean;
  deployMode: 'MERGE' | 'SYNC' | 'REPLACE';
  diff: ServerDiff | null;
  isCalculatingDiff: boolean;
  hasUnsavedChanges: boolean;
  canUndo: boolean;
  canRedo: boolean;
  setActiveTab: (tab: StudioTab) => void;
  setSelectedGuildId: (guildId: string) => void;
  setSelectedChannelName: (name: string | null) => void;
  setSelectedCategoryName: (name: string | null) => void;
  setSelectedRoleName: (name: string | null) => void;
  loadTemplate: (templateId: string) => void;
  setDraftTemplate: (template: ServerTemplate) => void;
  addCategory: (name: string) => void;
  updateCategory: (name: string, changes: Partial<ChannelTemplate>) => void;
  deleteCategory: (name: string) => void;
  addChannel: (channel: ChannelTemplate) => void;
  updateChannel: (name: string, changes: Partial<ChannelTemplate>) => void;
  deleteChannel: (name: string) => void;
  duplicateChannel: (name: string) => void;
  addRole: (role: RoleTemplate) => void;
  updateRole: (name: string, changes: Partial<RoleTemplate>) => void;
  deleteRole: (name: string) => void;
  undo: () => void;
  redo: () => void;
  openDeployModal: (mode?: 'MERGE' | 'SYNC' | 'REPLACE') => void;
  closeDeployModal: () => void;
  refreshGuildDetails: () => Promise<void>;
  refreshStatus: () => Promise<void>;
  computeDiff: () => Promise<void>;
}

const StudioContext = createContext<StudioContextType | undefined>(undefined);

export const StudioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [status, setStatus] = useState<StudioStatus | null>(null);
  const [guilds, setGuilds] = useState<GuildItem[]>([]);
  const [selectedGuildId, setSelectedGuildIdState] = useState<string>('demo-guild-blipmade-001');
  const [guildDetails, setGuildDetails] = useState<GuildDetails | null>(null);
  const [templates, setTemplates] = useState<ServerTemplate[]>([]);
  const [activeTemplate, setActiveTemplateState] = useState<ServerTemplate>({
    id: 'blipmade-draft',
    name: 'Blipmade | Official Hosting Community',
    description: 'The standard Discord community and infrastructure operations server for Blipmade VPS, game server, and application hosting.',
    version: '1.2.0',
    author: 'Blipmade Core Team',
    roles: [],
    categories: [],
    channels: [],
  });

  const [undoStack, setUndoStack] = useState<ServerTemplate[]>([]);
  const [redoStack, setRedoStack] = useState<ServerTemplate[]>([]);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);

  const [selectedChannelName, setSelectedChannelName] = useState<string | null>('welcome');
  const [selectedCategoryName, setSelectedCategoryName] = useState<string | null>(null);
  const [selectedRoleName, setSelectedRoleName] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<StudioTab>('overview');
  const [isDeployModalOpen, setIsDeployModalOpen] = useState<boolean>(false);
  const [deployMode, setDeployMode] = useState<'MERGE' | 'SYNC' | 'REPLACE'>('MERGE');

  const [diff, setDiff] = useState<ServerDiff | null>(null);
  const [isCalculatingDiff, setIsCalculatingDiff] = useState<boolean>(false);

  // Helper to commit state with history
  const commitTemplate = useCallback((newTemplate: ServerTemplate) => {
    setActiveTemplateState(prev => {
      setUndoStack(u => [...u.slice(-20), prev]);
      setRedoStack([]);
      setHasUnsavedChanges(true);
      return newTemplate;
    });
  }, []);

  const undo = useCallback(() => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setUndoStack(u => u.slice(0, -1));
    setRedoStack(r => [activeTemplate, ...r]);
    setActiveTemplateState(previous);
  }, [undoStack, activeTemplate]);

  const redo = useCallback(() => {
    if (redoStack.length === 0) return;
    const next = redoStack[0];
    setRedoStack(r => r.slice(1));
    setUndoStack(u => [...u, activeTemplate]);
    setActiveTemplateState(next);
  }, [redoStack, activeTemplate]);

  // Initial load
  useEffect(() => {
    Promise.all([fetchStudioStatus(), fetchGuilds(), fetchTemplates()])
      .then(([statusData, guildsData, templatesData]) => {
        setStatus(statusData);
        setGuilds(guildsData);
        setTemplates(templatesData);

        const official = templatesData.find(t => t.id === 'blipmade-official-v1') || templatesData[0];
        if (official) {
          setActiveTemplateState(JSON.parse(JSON.stringify(official)));
        }

        if (guildsData.length > 0) {
          const live = guildsData.find(g => !g.isDemo);
          setSelectedGuildIdState(live ? live.id : guildsData[0].id);
        }
      })
      .catch(err => {
        console.error('Initialization error:', err);
      });
  }, []);

  // Fetch guild details when selectedGuildId changes
  const refreshGuildDetails = useCallback(async () => {
    if (!selectedGuildId) return;
    try {
      const details = await fetchGuildDetails(selectedGuildId);
      setGuildDetails(details);
    } catch (err) {
      console.error('Error fetching guild details:', err);
    }
  }, [selectedGuildId]);

  useEffect(() => {
    refreshGuildDetails();
  }, [refreshGuildDetails]);

  const refreshStatus = useCallback(async () => {
    try {
      const s = await fetchStudioStatus();
      setStatus(s);
      const g = await fetchGuilds();
      setGuilds(g);
    } catch (err) {
      console.error('Error refreshing status:', err);
    }
  }, []);

  // Compute diff against selected guild
  const computeDiff = useCallback(async () => {
    if (!selectedGuildId) return;
    setIsCalculatingDiff(true);
    try {
      const result = await calculateDiff({
        guildId: selectedGuildId,
        customTemplate: activeTemplate,
      });
      setDiff(result);
    } catch (err) {
      console.error('Error computing diff:', err);
    } finally {
      setIsCalculatingDiff(false);
    }
  }, [selectedGuildId, activeTemplate]);

  // Load a template
  const loadTemplate = useCallback((templateId: string) => {
    const found = templates.find(t => t.id === templateId);
    if (found) {
      commitTemplate(JSON.parse(JSON.stringify(found)));
      if (found.channels.length > 0) {
        setSelectedChannelName(found.channels[0].name);
        setSelectedCategoryName(null);
        setSelectedRoleName(null);
      }
    }
  }, [templates, commitTemplate]);

  // Visual builder mutations
  const addCategory = useCallback((name: string) => {
    const exists = activeTemplate.categories.some(c => c.name.toLowerCase() === name.toLowerCase());
    if (exists) return;
    const newCat: ChannelTemplate = {
      name: name.toUpperCase(),
      type: 4,
      position: activeTemplate.categories.length,
      permissionOverwrites: [],
    };
    commitTemplate({
      ...activeTemplate,
      categories: [...activeTemplate.categories, newCat],
    });
    setSelectedCategoryName(newCat.name);
    setSelectedChannelName(null);
  }, [activeTemplate, commitTemplate]);

  const updateCategory = useCallback((name: string, changes: Partial<ChannelTemplate>) => {
    const updatedCategories = activeTemplate.categories.map(c => {
      if (c.name.toLowerCase() === name.toLowerCase()) {
        return { ...c, ...changes };
      }
      return c;
    });

    // If name changed, update child channels
    let updatedChannels = activeTemplate.channels;
    if (changes.name && changes.name !== name) {
      updatedChannels = activeTemplate.channels.map(ch => {
        if (ch.categoryName?.toLowerCase() === name.toLowerCase()) {
          return { ...ch, categoryName: changes.name };
        }
        return ch;
      });
      if (selectedCategoryName === name) {
        setSelectedCategoryName(changes.name);
      }
    }

    commitTemplate({
      ...activeTemplate,
      categories: updatedCategories,
      channels: updatedChannels,
    });
  }, [activeTemplate, selectedCategoryName, commitTemplate]);

  const deleteCategory = useCallback((name: string) => {
    const updatedCategories = activeTemplate.categories.filter(c => c.name.toLowerCase() !== name.toLowerCase());
    // Also remove or detach channels
    const updatedChannels = activeTemplate.channels.filter(ch => ch.categoryName?.toLowerCase() !== name.toLowerCase());
    commitTemplate({
      ...activeTemplate,
      categories: updatedCategories,
      channels: updatedChannels,
    });
    setSelectedCategoryName(null);
  }, [activeTemplate, commitTemplate]);

  const addChannel = useCallback((channel: ChannelTemplate) => {
    commitTemplate({
      ...activeTemplate,
      channels: [...activeTemplate.channels, channel],
    });
    setSelectedChannelName(channel.name);
    setSelectedCategoryName(null);
    setSelectedRoleName(null);
  }, [activeTemplate, commitTemplate]);

  const updateChannel = useCallback((name: string, changes: Partial<ChannelTemplate>) => {
    const updatedChannels = activeTemplate.channels.map(c => {
      if (c.name.toLowerCase() === name.toLowerCase()) {
        return { ...c, ...changes };
      }
      return c;
    });

    if (changes.name && selectedChannelName === name) {
      setSelectedChannelName(changes.name);
    }

    commitTemplate({
      ...activeTemplate,
      channels: updatedChannels,
    });
  }, [activeTemplate, selectedChannelName, commitTemplate]);

  const deleteChannel = useCallback((name: string) => {
    const updatedChannels = activeTemplate.channels.filter(c => c.name.toLowerCase() !== name.toLowerCase());
    commitTemplate({
      ...activeTemplate,
      channels: updatedChannels,
    });
    if (selectedChannelName === name) {
      setSelectedChannelName(updatedChannels[0]?.name || null);
    }
  }, [activeTemplate, selectedChannelName, commitTemplate]);

  const duplicateChannel = useCallback((name: string) => {
    const target = activeTemplate.channels.find(c => c.name.toLowerCase() === name.toLowerCase());
    if (!target) return;
    const copy: ChannelTemplate = {
      ...JSON.parse(JSON.stringify(target)),
      name: `${target.name}-copy`,
      position: target.position + 1,
    };
    commitTemplate({
      ...activeTemplate,
      channels: [...activeTemplate.channels, copy],
    });
    setSelectedChannelName(copy.name);
  }, [activeTemplate, commitTemplate]);

  const addRole = useCallback((role: RoleTemplate) => {
    commitTemplate({
      ...activeTemplate,
      roles: [...activeTemplate.roles, role],
    });
    setSelectedRoleName(role.name);
  }, [activeTemplate, commitTemplate]);

  const updateRole = useCallback((name: string, changes: Partial<RoleTemplate>) => {
    const updatedRoles = activeTemplate.roles.map(r => {
      if (r.name.toLowerCase() === name.toLowerCase()) {
        return { ...r, ...changes };
      }
      return r;
    });
    if (changes.name && selectedRoleName === name) {
      setSelectedRoleName(changes.name);
    }
    commitTemplate({
      ...activeTemplate,
      roles: updatedRoles,
    });
  }, [activeTemplate, selectedRoleName, commitTemplate]);

  const deleteRole = useCallback((name: string) => {
    const updatedRoles = activeTemplate.roles.filter(r => r.name.toLowerCase() !== name.toLowerCase());
    commitTemplate({
      ...activeTemplate,
      roles: updatedRoles,
    });
    if (selectedRoleName === name) {
      setSelectedRoleName(null);
    }
  }, [activeTemplate, selectedRoleName, commitTemplate]);

  const openDeployModal = useCallback((mode: 'MERGE' | 'SYNC' | 'REPLACE' = 'MERGE') => {
    setDeployMode(mode);
    computeDiff();
    setIsDeployModalOpen(true);
  }, [computeDiff]);

  const closeDeployModal = useCallback(() => {
    setIsDeployModalOpen(false);
  }, []);

  const selectedGuild = guilds.find(g => g.id === selectedGuildId) || null;

  return (
    <StudioContext.Provider
      value={{
        status,
        guilds,
        selectedGuild,
        guildDetails,
        templates,
        activeTemplate,
        selectedChannelName,
        selectedCategoryName,
        selectedRoleName,
        activeTab,
        isDeployModalOpen,
        deployMode,
        diff,
        isCalculatingDiff,
        hasUnsavedChanges,
        canUndo: undoStack.length > 0,
        canRedo: redoStack.length > 0,
        setActiveTab,
        setSelectedGuildId: setSelectedGuildIdState,
        setSelectedChannelName,
        setSelectedCategoryName,
        setSelectedRoleName,
        loadTemplate,
        setDraftTemplate: commitTemplate,
        addCategory,
        updateCategory,
        deleteCategory,
        addChannel,
        updateChannel,
        deleteChannel,
        duplicateChannel,
        addRole,
        updateRole,
        deleteRole,
        undo,
        redo,
        openDeployModal,
        closeDeployModal,
        refreshGuildDetails,
        refreshStatus,
        computeDiff,
      }}
    >
      {children}
    </StudioContext.Provider>
  );
};

export function useStudio() {
  const context = useContext(StudioContext);
  if (!context) {
    throw new Error('useStudio must be used within a StudioProvider');
  }
  return context;
}
