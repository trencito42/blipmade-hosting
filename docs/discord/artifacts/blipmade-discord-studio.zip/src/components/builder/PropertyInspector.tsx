/**
 * Visual Builder: Right Panel - Property Inspector
 * Full control over channel configuration, permissions, topics, and categories
 */

import React from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Sliders,
  Hash,
  Volume2,
  Megaphone,
  Folder,
  Shield,
  Trash2,
  Copy,
  Lock,
  Clock,
  AlertCircle,
} from 'lucide-react';
import { ChannelTemplate, OverwriteTemplate } from '../../types/discord.ts';

export const PropertyInspector: React.FC = () => {
  const {
    activeTemplate,
    selectedChannelName,
    selectedCategoryName,
    updateChannel,
    deleteChannel,
    duplicateChannel,
    updateCategory,
    deleteCategory,
  } = useStudio();

  // If a Category is selected
  if (selectedCategoryName) {
    const category = activeTemplate.categories.find(
      c => c.name.toLowerCase() === selectedCategoryName.toLowerCase()
    );

    if (!category) return null;

    const isPrivate =
      category.name.includes('PRIVATE') ||
      category.permissionOverwrites?.some(ow => ow.deny.includes('1024'));

    const togglePrivateCategory = () => {
      let overwrites = [...(category.permissionOverwrites || [])];
      if (isPrivate) {
        // Make public
        overwrites = overwrites.filter(ow => ow.roleName !== '@everyone');
      } else {
        // Make private
        overwrites.push({
          roleName: '@everyone',
          allow: '0',
          deny: '1024',
        });
      }
      updateCategory(category.name, { permissionOverwrites: overwrites });
    };

    return (
      <div className="w-80 bg-[#0A0A0A] border-l border-[#1B1B1B] flex flex-col h-full overflow-y-auto p-4 space-y-6 shrink-0">
        <div className="border-b border-[#1A1A1A] pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Folder className="w-4 h-4 text-[#E64A4A]" />
            <h3 className="text-xs font-semibold text-[#F5F2EB] uppercase tracking-wider">
              Category Inspector
            </h3>
          </div>
          <button
            onClick={() => {
              if (confirm(`Remove category "${category.name}" and its channels?`)) {
                deleteCategory(category.name);
              }
            }}
            className="text-xs text-[#9E9B95] hover:text-[#E64A4A] p-1 cursor-pointer"
            title="Delete category"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-4 text-xs">
          <div>
            <label className="text-[#9E9B95] block mb-1">Category Name</label>
            <input
              type="text"
              value={category.name}
              onChange={(e) => updateCategory(category.name, { name: e.target.value.toUpperCase() })}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] font-medium uppercase focus:outline-none focus:border-[#E64A4A]"
            />
          </div>

          <div className="bg-[#121212] border border-[#1F1F1F] rounded p-3 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[#F5F2EB] font-medium flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#E64A4A]" /> Private Category
              </span>
              <input
                type="checkbox"
                checked={Boolean(isPrivate)}
                onChange={togglePrivateCategory}
                className="w-4 h-4 accent-[#E64A4A] cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-[#6E6C68] leading-relaxed">
              When enabled, channels nested under this category automatically hide from @everyone unless explicit role overwrites are granted.
            </p>
          </div>

          <div className="pt-2">
            <span className="text-[#9E9B95] block mb-2 font-semibold">Associated Roles</span>
            <div className="space-y-1.5">
              {activeTemplate.roles.map(r => (
                <div key={r.name} className="flex items-center justify-between py-1 border-b border-[#141414] text-[11px]">
                  <span className="text-[#D8D5CD]">@{r.name}</span>
                  <span className="text-[#6E6C68] font-mono">
                    {r.name === 'Owner' || r.name === 'Administrator' ? 'Full Access' : isPrivate ? 'Restricted' : 'Inherited'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // If a Channel is selected
  const channel = activeTemplate.channels.find(
    c => c.name.toLowerCase() === selectedChannelName?.toLowerCase()
  );

  if (!channel) {
    return (
      <div className="w-80 bg-[#0A0A0A] border-l border-[#1B1B1B] flex flex-col items-center justify-center p-6 text-center text-[#6E6C68] shrink-0">
        <Sliders className="w-10 h-10 mb-2 stroke-[1.2]" />
        <h4 className="text-xs font-semibold text-[#9E9B95]">Properties Inspector</h4>
        <p className="text-[11px] text-[#6E6C68] mt-1">
          Select any channel or category to edit name, topic, slowmode, and role permissions.
        </p>
      </div>
    );
  }

  const isPrivateChannel = channel.permissionOverwrites?.some(
    ow => ow.roleName === '@everyone' && ow.deny.includes('1024')
  );

  const isReadOnlyChannel = channel.permissionOverwrites?.some(
    ow => ow.roleName === '@everyone' && ow.deny.includes('2048')
  );

  const handleTogglePrivate = () => {
    let overwrites = [...(channel.permissionOverwrites || [])];
    if (isPrivateChannel) {
      overwrites = overwrites.filter(ow => !(ow.roleName === '@everyone' && ow.deny.includes('1024')));
    } else {
      overwrites.push({
        roleName: '@everyone',
        allow: '0',
        deny: '1024',
      });
    }
    updateChannel(channel.name, { permissionOverwrites: overwrites });
  };

  const handleToggleReadOnly = () => {
    let overwrites = [...(channel.permissionOverwrites || [])];
    if (isReadOnlyChannel) {
      overwrites = overwrites.filter(ow => !(ow.roleName === '@everyone' && ow.deny.includes('2048')));
    } else {
      overwrites.push({
        roleName: '@everyone',
        allow: '1024',
        deny: '2048',
      });
    }
    updateChannel(channel.name, { permissionOverwrites: overwrites });
  };

  return (
    <div className="w-80 bg-[#0A0A0A] border-l border-[#1B1B1B] flex flex-col h-full overflow-y-auto p-4 space-y-6 shrink-0 select-none">
      {/* Inspector Header */}
      <div className="border-b border-[#1A1A1A] pb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#E64A4A]" />
          <h3 className="text-xs font-semibold text-[#F5F2EB] uppercase tracking-wider">
            Channel Properties
          </h3>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => duplicateChannel(channel.name)}
            title="Duplicate channel"
            className="p-1 text-[#9E9B95] hover:text-[#F5F2EB] cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => deleteChannel(channel.name)}
            title="Delete from draft"
            className="p-1 text-[#9E9B95] hover:text-[#E64A4A] cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Primary Channel Fields */}
      <div className="space-y-4 text-xs">
        <div>
          <label className="text-[#9E9B95] block mb-1">Channel Name</label>
          <div className="flex items-center bg-[#141414] border border-[#262626] rounded px-2.5 py-1.5 focus-within:border-[#E64A4A]">
            <Hash className="w-3.5 h-3.5 text-[#6E6C68] mr-1.5 shrink-0" />
            <input
              type="text"
              value={channel.name}
              onChange={(e) => {
                const formatted = e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '-');
                updateChannel(channel.name, { name: formatted });
              }}
              className="w-full bg-transparent text-[#F5F2EB] font-mono focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="text-[#9E9B95] block mb-1">Category Assignment</label>
          <select
            value={channel.categoryName || ''}
            onChange={(e) => updateChannel(channel.name, { categoryName: e.target.value || undefined })}
            className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
          >
            <option value="">(None - Top Level)</option>
            {activeTemplate.categories.map(c => (
              <option key={c.name} value={c.name}>{c.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-[#9E9B95] block mb-1">Channel Type</label>
          <select
            value={channel.type}
            onChange={(e) => updateChannel(channel.name, { type: Number(e.target.value) })}
            className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
          >
            <option value={0}>Text Channel</option>
            <option value={2}>Voice Channel</option>
            <option value={5}>Announcement Channel</option>
            <option value={15}>Forum Channel</option>
          </select>
        </div>

        <div>
          <label className="text-[#9E9B95] block mb-1">Topic / Description</label>
          <textarea
            rows={3}
            value={channel.topic || ''}
            onChange={(e) => updateChannel(channel.name, { topic: e.target.value })}
            placeholder="Describe what this channel is used for..."
            className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#F5F2EB] placeholder:text-[#555555] focus:outline-none focus:border-[#E64A4A] resize-none"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[#9E9B95] flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#6E6C68]" /> Slowmode (Rate Limit)
            </label>
            <span className="font-mono text-[#F5F2EB] text-[11px]">
              {channel.rateLimitPerUser ? `${channel.rateLimitPerUser}s` : 'Off'}
            </span>
          </div>
          <select
            value={channel.rateLimitPerUser || 0}
            onChange={(e) => updateChannel(channel.name, { rateLimitPerUser: Number(e.target.value) })}
            className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
          >
            <option value={0}>Off</option>
            <option value={5}>5 seconds</option>
            <option value={10}>10 seconds</option>
            <option value={15}>15 seconds</option>
            <option value={30}>30 seconds</option>
            <option value={60}>1 minute</option>
            <option value={120}>2 minutes</option>
            <option value={300}>5 minutes</option>
            <option value={600}>10 minutes</option>
          </select>
        </div>

        {/* Access Overwrites Toggles */}
        <div className="pt-2 border-t border-[#181818] space-y-3">
          <span className="text-[#9E9B95] block font-semibold">Access & Permissions</span>

          <div className="bg-[#121212] border border-[#1F1F1F] rounded p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[#F5F2EB] font-medium flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#E64A4A]" /> Private Channel
              </span>
              <input
                type="checkbox"
                checked={Boolean(isPrivateChannel)}
                onChange={handleTogglePrivate}
                className="w-4 h-4 accent-[#E64A4A] cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-[#6E6C68]">
              Denies View Channel to @everyone. Only specified staff roles can see this channel.
            </p>
          </div>

          <div className="bg-[#121212] border border-[#1F1F1F] rounded p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[#F5F2EB] font-medium flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-amber-400" /> Read-Only for Members
              </span>
              <input
                type="checkbox"
                checked={Boolean(isReadOnlyChannel)}
                onChange={handleToggleReadOnly}
                className="w-4 h-4 accent-[#E64A4A] cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-[#6E6C68]">
              Members can view and read history, but only administrators & support staff can post messages.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
