/**
 * Visual Builder: Center Panel - Live Channel Preview
 * Authentic Discord dark interface simulation
 */

import React from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Hash,
  Volume2,
  Megaphone,
  Bell,
  Pin,
  Users,
  Search,
  Lock,
  EyeOff,
  Clock,
  Send,
  Smile,
  Gift,
  Paperclip,
  CheckCircle2,
} from 'lucide-react';

export const ChannelPreview: React.FC = () => {
  const { activeTemplate, selectedChannelName } = useStudio();

  const channel = activeTemplate.channels.find(
    c => c.name.toLowerCase() === selectedChannelName?.toLowerCase()
  );

  if (!channel) {
    return (
      <div className="flex-1 bg-[#0E0E0E] flex flex-col items-center justify-center text-center p-6 text-[#6E6C68]">
        <Hash className="w-12 h-12 mb-3 stroke-[1.2]" />
        <h3 className="text-sm font-semibold text-[#9E9B95]">No Channel Selected</h3>
        <p className="text-xs text-[#6E6C68] max-w-sm mt-1">
          Select a channel from the left structure tree or create a new one to preview its live Discord appearance.
        </p>
      </div>
    );
  }

  // Calculate permission restrictions
  const deniesEveryoneView = channel.permissionOverwrites?.some(
    ow => ow.roleName === '@everyone' && ow.deny.includes('1024')
  ) || channel.categoryName?.includes('PRIVATE');

  const deniesEveryoneSend = channel.permissionOverwrites?.some(
    ow => ow.roleName === '@everyone' && ow.deny.includes('2048')
  );

  const initialEmbed = channel.initialMessage?.embeds?.[0];

  return (
    <div className="flex-1 bg-[#0E0E0E] flex flex-col h-full overflow-hidden select-none">
      {/* Discord Header Bar */}
      <div className="h-12 border-b border-[#1A1A1A] px-4 flex items-center justify-between bg-[#0C0C0C] shrink-0">
        <div className="flex items-center gap-2.5 truncate flex-1 mr-4">
          {channel.type === 2 ? (
            <Volume2 className="w-4 h-4 text-[#9E9B95] shrink-0" />
          ) : channel.type === 5 ? (
            <Megaphone className="w-4 h-4 text-[#9E9B95] shrink-0" />
          ) : (
            <Hash className="w-4 h-4 text-[#9E9B95] shrink-0" />
          )}

          <span className="text-xs font-bold text-[#F5F2EB] truncate">
            {channel.name}
          </span>

          {channel.categoryName && (
            <span className="text-[11px] text-[#6E6C68] font-mono">
              / {channel.categoryName}
            </span>
          )}

          {channel.topic && (
            <>
              <span className="text-[#333333]">|</span>
              <span className="text-xs text-[#9E9B95] truncate max-w-md font-normal">
                {channel.topic}
              </span>
            </>
          )}
        </div>

        {/* Discord Action Icons */}
        <div className="flex items-center gap-3 text-[#6E6C68] shrink-0">
          <Bell className="w-4 h-4 hover:text-[#F5F2EB] cursor-pointer" />
          <Pin className="w-4 h-4 hover:text-[#F5F2EB] cursor-pointer" />
          <Users className="w-4 h-4 hover:text-[#F5F2EB] cursor-pointer" />
          <div className="flex items-center bg-[#151515] border border-[#222222] rounded px-2 py-1 text-[11px] text-[#6E6C68] w-28">
            <span className="truncate">Search</span>
            <Search className="w-3 h-3 ml-auto text-[#555555]" />
          </div>
        </div>
      </div>

      {/* Permission & Security Status Strip */}
      <div className="bg-[#111111] border-b border-[#1A1A1A] px-4 py-2 flex flex-wrap items-center gap-3 text-xs">
        {deniesEveryoneView ? (
          <div className="flex items-center gap-1.5 text-rose-400 font-medium">
            <Lock className="w-3.5 h-3.5" />
            <span>Private Channel (@everyone denied view)</span>
          </div>
        ) : deniesEveryoneSend ? (
          <div className="flex items-center gap-1.5 text-amber-400 font-medium">
            <EyeOff className="w-3.5 h-3.5" />
            <span>Read-Only Channel (Announcements / Rules)</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Public Member Channel</span>
          </div>
        )}

        {channel.rateLimitPerUser && channel.rateLimitPerUser > 0 ? (
          <div className="flex items-center gap-1 text-[#9E9B95] font-mono text-[11px] ml-auto">
            <Clock className="w-3 h-3" />
            <span>Slowmode: {channel.rateLimitPerUser}s</span>
          </div>
        ) : null}
      </div>

      {/* Channel Chat Viewport */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6">
        {/* Welcome Kicker */}
        <div className="space-y-1.5 pt-6 pb-2">
          <div className="w-12 h-12 rounded-full bg-[#181818] border border-[#262626] flex items-center justify-center text-[#9E9B95]">
            <Hash className="w-6 h-6 text-[#F5F2EB]" />
          </div>
          <h2 className="text-xl font-bold text-[#F5F2EB]">
            Welcome to #{channel.name}!
          </h2>
          <p className="text-xs text-[#9E9B95] leading-relaxed max-w-xl">
            {channel.topic || `This is the start of the #${channel.name} channel.`}
          </p>
        </div>

        {/* Pinned Embed if specified in template */}
        {initialEmbed && (
          <div className="max-w-2xl bg-[#111111] border border-[#1F1F1F] rounded-md p-4 space-y-3 relative overflow-hidden">
            {/* Color accent left bar */}
            <div
              className="absolute left-0 top-0 bottom-0 w-1"
              style={{
                backgroundColor: initialEmbed.color
                  ? `#${initialEmbed.color.toString(16).padStart(6, '0')}`
                  : '#E64A4A',
              }}
            />

            <div className="pl-2 space-y-2">
              <h4 className="text-sm font-bold text-[#F5F2EB]">
                {initialEmbed.title}
              </h4>

              <div className="text-xs text-[#9E9B95] leading-relaxed whitespace-pre-line">
                {initialEmbed.description}
              </div>

              {/* Embed Fields */}
              {initialEmbed.fields && initialEmbed.fields.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {initialEmbed.fields.map((field, i) => (
                    <div key={i} className="text-xs">
                      <div className="font-semibold text-[#F5F2EB]">{field.name}</div>
                      <div className="text-[#9E9B95] mt-0.5 leading-snug">{field.value}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Embed Footer */}
              {initialEmbed.footer && (
                <div className="text-[11px] text-[#6E6C68] pt-2 border-t border-[#1C1C1C]">
                  {initialEmbed.footer.text}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Simulated Community Message */}
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-full bg-[#E64A4A] flex items-center justify-center text-white font-bold text-xs shrink-0">
            B
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#F5F2EB]">Blipmade Bot</span>
              <span className="text-[10px] font-mono bg-[#E64A4A]/20 text-[#E64A4A] px-1 rounded">
                BOT
              </span>
              <span className="text-[10px] text-[#6E6C68] font-mono">Today at 12:00 PM</span>
            </div>
            <p className="text-xs text-[#D8D5CD] leading-relaxed">
              Channel <span className="text-[#E64A4A] font-mono font-medium">#{channel.name}</span> configured via Blipmade Discord Studio.
            </p>
          </div>
        </div>
      </div>

      {/* Simulated Message Input Bar */}
      <div className="p-4 bg-[#0C0C0C] border-t border-[#1A1A1A] shrink-0">
        <div className="flex items-center gap-3 bg-[#141414] border border-[#222222] rounded-lg px-4 py-2.5">
          <div className="p-1 rounded-full bg-[#1F1F1F] text-[#9E9B95] hover:text-white cursor-pointer">
            <Paperclip className="w-3.5 h-3.5" />
          </div>
          <input
            type="text"
            readOnly
            disabled={Boolean(deniesEveryoneSend)}
            placeholder={
              deniesEveryoneSend
                ? `You do not have permission to send messages in #${channel.name}.`
                : `Message #${channel.name}`
            }
            className="w-full bg-transparent text-xs text-[#F5F2EB] placeholder:text-[#555555] focus:outline-none cursor-default"
          />
          <div className="flex items-center gap-2 text-[#6E6C68]">
            <Gift className="w-4 h-4 hover:text-[#9E9B95] cursor-pointer" />
            <Smile className="w-4 h-4 hover:text-[#9E9B95] cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );
};
