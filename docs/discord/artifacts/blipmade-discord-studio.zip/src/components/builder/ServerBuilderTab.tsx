/**
 * Three-Panel Visual Discord Server Builder
 */

import React from 'react';
import { ChannelTree } from './ChannelTree.tsx';
import { ChannelPreview } from './ChannelPreview.tsx';
import { PropertyInspector } from './PropertyInspector.tsx';

export const ServerBuilderTab: React.FC = () => {
  return (
    <div className="flex-1 flex overflow-hidden h-[calc(100vh-3.5rem)]">
      {/* Left Panel: Hierarchy & Channels */}
      <ChannelTree />

      {/* Center Panel: Live Preview */}
      <ChannelPreview />

      {/* Right Panel: Properties & Permissions */}
      <PropertyInspector />
    </div>
  );
};
