/**
 * Visual Builder: Left Panel - Channel Tree & Hierarchy
 */

import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Hash,
  Volume2,
  Megaphone,
  FolderPlus,
  Plus,
  ChevronDown,
  ChevronRight,
  Lock,
  MessageSquare,
  Undo2,
  Redo2,
  Copy,
  Trash2,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { ChannelTemplate } from '../../types/discord.ts';

export const ChannelTree: React.FC = () => {
  const {
    activeTemplate,
    selectedChannelName,
    setSelectedChannelName,
    selectedCategoryName,
    setSelectedCategoryName,
    addCategory,
    addChannel,
    deleteChannel,
    duplicateChannel,
    deleteCategory,
    canUndo,
    canRedo,
    undo,
    redo,
    hasUnsavedChanges,
  } = useStudio();

  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});
  const [isAddCatModalOpen, setIsAddCatModalOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [isAddChanModalOpen, setIsAddChanModalOpen] = useState(false);
  const [newChanName, setNewChanName] = useState('');
  const [newChanType, setNewChanType] = useState<number>(0);
  const [newChanCategory, setNewChanCategory] = useState<string>('');

  const toggleCategory = (catName: string) => {
    setCollapsedCategories(prev => ({
      ...prev,
      [catName]: !prev[catName],
    }));
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    addCategory(newCatName.trim());
    setNewCatName('');
    setIsAddCatModalOpen(false);
  };

  const handleCreateChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChanName.trim()) return;
    const formattedName = newChanName.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-');
    const newChan: ChannelTemplate = {
      name: formattedName,
      type: newChanType,
      categoryName: newChanCategory || undefined,
      position: activeTemplate.channels.length,
      topic: '',
      permissionOverwrites: [],
    };
    addChannel(newChan);
    setNewChanName('');
    setIsAddChanModalOpen(false);
  };

  return (
    <div className="w-64 bg-[#0A0A0A] border-r border-[#1B1B1B] flex flex-col h-full select-none shrink-0">
      {/* Panel Header & Controls */}
      <div className="h-12 border-b border-[#1A1A1A] px-4 flex items-center justify-between">
        <span className="text-xs font-semibold text-[#F5F2EB] tracking-wider uppercase">
          Structure
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={undo}
            disabled={!canUndo}
            title="Undo"
            className={`p-1.5 rounded transition-colors ${
              canUndo
                ? 'text-[#9E9B95] hover:text-[#F5F2EB] hover:bg-[#181818] cursor-pointer'
                : 'text-[#444444] cursor-not-allowed'
            }`}
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={redo}
            disabled={!canRedo}
            title="Redo"
            className={`p-1.5 rounded transition-colors ${
              canRedo
                ? 'text-[#9E9B95] hover:text-[#F5F2EB] hover:bg-[#181818] cursor-pointer'
                : 'text-[#444444] cursor-not-allowed'
            }`}
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsAddCatModalOpen(true)}
            title="Add Category"
            className="p-1.5 text-[#9E9B95] hover:text-[#F5F2EB] hover:bg-[#181818] rounded transition-colors cursor-pointer"
          >
            <FolderPlus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setNewChanCategory(activeTemplate.categories[0]?.name || '');
              setIsAddChanModalOpen(true);
            }}
            title="Add Channel"
            className="p-1.5 text-[#E64A4A] hover:text-white hover:bg-[#E64A4A] rounded transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Hierarchy List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-4">
        {activeTemplate.categories.map(cat => {
          const isCollapsed = collapsedCategories[cat.name];
          const isCatSelected = selectedCategoryName === cat.name;
          const childChannels = activeTemplate.channels.filter(
            ch => ch.categoryName?.toLowerCase() === cat.name.toLowerCase()
          );
          const isPrivate =
            cat.name.includes('PRIVATE') ||
            cat.permissionOverwrites?.some(ow => ow.deny.includes('1024'));

          return (
            <div key={cat.name} className="space-y-1">
              {/* Category Row */}
              <div
                className={`group flex items-center justify-between px-2 py-1 rounded text-[11px] font-semibold tracking-wider cursor-pointer transition-colors ${
                  isCatSelected
                    ? 'text-[#F5F2EB] bg-[#161616]'
                    : 'text-[#6E6C68] hover:text-[#9E9B95] hover:bg-[#121212]'
                }`}
                onClick={() => {
                  setSelectedCategoryName(cat.name);
                  setSelectedChannelName(null);
                }}
              >
                <div
                  className="flex items-center gap-1.5 truncate flex-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleCategory(cat.name);
                  }}
                >
                  {isCollapsed ? (
                    <ChevronRight className="w-3 h-3 text-[#6E6C68] shrink-0" />
                  ) : (
                    <ChevronDown className="w-3 h-3 text-[#6E6C68] shrink-0" />
                  )}
                  <span className="truncate uppercase">{cat.name}</span>
                  {isPrivate && (
                    <Lock className="w-2.5 h-2.5 text-[#E64A4A] shrink-0 ml-0.5" />
                  )}
                </div>

                <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setNewChanCategory(cat.name);
                      setIsAddChanModalOpen(true);
                    }}
                    title="Add channel under this category"
                    className="p-1 text-[#9E9B95] hover:text-[#F5F2EB] cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Remove category "${cat.name}" and all its proposed channels?`)) {
                        deleteCategory(cat.name);
                      }
                    }}
                    title="Delete category"
                    className="p-1 text-[#9E9B95] hover:text-[#E64A4A] cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Channels under category */}
              {!isCollapsed && (
                <div className="space-y-0.5 pl-2">
                  {childChannels.map(channel => {
                    const isSelected = selectedChannelName === channel.name;
                    return (
                      <div
                        key={channel.name}
                        onClick={() => {
                          setSelectedChannelName(channel.name);
                          setSelectedCategoryName(null);
                        }}
                        className={`group flex items-center justify-between px-2 py-1 rounded text-xs cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-[#1E1E1E] text-[#F5F2EB] font-medium'
                            : 'text-[#9E9B95] hover:bg-[#141414] hover:text-[#F5F2EB]'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 truncate">
                          {channel.type === 2 ? (
                            <Volume2 className="w-3.5 h-3.5 text-[#6E6C68] shrink-0" />
                          ) : channel.type === 5 ? (
                            <Megaphone className="w-3.5 h-3.5 text-[#6E6C68] shrink-0" />
                          ) : channel.type === 15 ? (
                            <MessageSquare className="w-3.5 h-3.5 text-[#6E6C68] shrink-0" />
                          ) : (
                            <Hash className="w-3.5 h-3.5 text-[#6E6C68] shrink-0" />
                          )}
                          <span className="truncate">{channel.name}</span>
                        </div>

                        {/* Quick Hover Actions */}
                        <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              duplicateChannel(channel.name);
                            }}
                            title="Duplicate channel"
                            className="p-1 text-[#6E6C68] hover:text-[#F5F2EB] cursor-pointer"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteChannel(channel.name);
                            }}
                            title="Delete channel"
                            className="p-1 text-[#6E6C68] hover:text-[#E64A4A] cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })}

                  {childChannels.length === 0 && (
                    <div className="text-[11px] text-[#555555] px-2 py-1 italic">
                      Empty category
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Uncategorized channels */}
        {(() => {
          const uncategorized = activeTemplate.channels.filter(
            ch => !ch.categoryName || !activeTemplate.categories.some(c => c.name.toLowerCase() === ch.categoryName?.toLowerCase())
          );
          if (uncategorized.length === 0) return null;
          return (
            <div className="space-y-1 pt-2 border-t border-[#181818]">
              <span className="text-[11px] font-semibold text-[#6E6C68] uppercase px-2">
                Uncategorized
              </span>
              <div className="space-y-0.5">
                {uncategorized.map(channel => {
                  const isSelected = selectedChannelName === channel.name;
                  return (
                    <div
                      key={channel.name}
                      onClick={() => {
                        setSelectedChannelName(channel.name);
                        setSelectedCategoryName(null);
                      }}
                      className={`flex items-center justify-between px-2 py-1 rounded text-xs cursor-pointer ${
                        isSelected
                          ? 'bg-[#1E1E1E] text-[#F5F2EB] font-medium'
                          : 'text-[#9E9B95] hover:bg-[#141414] hover:text-[#F5F2EB]'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 truncate">
                        <Hash className="w-3.5 h-3.5 text-[#6E6C68]" />
                        <span className="truncate">{channel.name}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })()}
      </div>

      {/* Add Category Modal */}
      {isAddCatModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <form
            onSubmit={handleCreateCategory}
            className="bg-[#0F0F0F] border border-[#222222] rounded-lg p-5 w-full max-w-sm space-y-4 shadow-xl"
          >
            <h3 className="text-sm font-semibold text-[#F5F2EB]">Create Proposed Category</h3>
            <div>
              <label className="text-xs text-[#9E9B95] block mb-1">Category Name</label>
              <input
                type="text"
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value.toUpperCase())}
                placeholder="e.g. OPERATIONS"
                autoFocus
                className="w-full bg-[#161616] border border-[#2A2A2A] rounded px-3 py-1.5 text-xs text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddCatModalOpen(false)}
                className="px-3 py-1.5 text-xs text-[#9E9B95] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!newCatName.trim()}
                className="px-3 py-1.5 text-xs bg-[#E64A4A] hover:bg-[#F05555] text-white rounded font-medium disabled:opacity-50 cursor-pointer"
              >
                Add Category
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Channel Modal */}
      {isAddChanModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <form
            onSubmit={handleCreateChannel}
            className="bg-[#0F0F0F] border border-[#222222] rounded-lg p-5 w-full max-w-sm space-y-4 shadow-xl"
          >
            <h3 className="text-sm font-semibold text-[#F5F2EB]">Create Proposed Channel</h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-[#9E9B95] block mb-1">Channel Name</label>
                <div className="flex items-center bg-[#161616] border border-[#2A2A2A] rounded px-2.5 py-1.5 focus-within:border-[#E64A4A]">
                  <Hash className="w-3.5 h-3.5 text-[#6E6C68] mr-1.5" />
                  <input
                    type="text"
                    value={newChanName}
                    onChange={(e) => setNewChanName(e.target.value)}
                    placeholder="new-channel"
                    autoFocus
                    className="w-full bg-transparent text-xs text-[#F5F2EB] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-[#9E9B95] block mb-1">Channel Type</label>
                <select
                  value={newChanType}
                  onChange={(e) => setNewChanType(Number(e.target.value))}
                  className="w-full bg-[#161616] border border-[#2A2A2A] rounded px-3 py-1.5 text-xs text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
                >
                  <option value={0}>Text Channel (standard)</option>
                  <option value={2}>Voice Channel</option>
                  <option value={5}>Announcement Channel</option>
                  <option value={15}>Forum Channel</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-[#9E9B95] block mb-1">Category</label>
                <select
                  value={newChanCategory}
                  onChange={(e) => setNewChanCategory(e.target.value)}
                  className="w-full bg-[#161616] border border-[#2A2A2A] rounded px-3 py-1.5 text-xs text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
                >
                  <option value="">(None - Top Level)</option>
                  {activeTemplate.categories.map(c => (
                    <option key={c.name} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddChanModalOpen(false)}
                className="px-3 py-1.5 text-xs text-[#9E9B95] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!newChanName.trim()}
                className="px-3 py-1.5 text-xs bg-[#E64A4A] hover:bg-[#F05555] text-white rounded font-medium disabled:opacity-50 cursor-pointer"
              >
                Create Channel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
