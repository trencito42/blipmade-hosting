/**
 * Overview Section
 * Server health, connected guilds, channel metrics, and quick deployment triggers
 */

import React, { useEffect, useState } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Server,
  Layers,
  Shield,
  FileText,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  Download,
  Terminal,
  Activity as ActivityIcon,
  HelpCircle,
} from 'lucide-react';
import { fetchBackups, fetchActivityRuns } from '../../api/client.ts';
import { AuditRun } from '../../types/discord.ts';

export const OverviewTab: React.FC = () => {
  const {
    status,
    guilds,
    selectedGuild,
    setSelectedGuildId,
    guildDetails,
    activeTemplate,
    setActiveTab,
    openDeployModal,
  } = useStudio();

  const [recentRuns, setRecentRuns] = useState<AuditRun[]>([]);

  useEffect(() => {
    fetchActivityRuns()
      .then(runs => setRecentRuns(runs.slice(0, 3)))
      .catch(console.error);
  }, []);

  const totalChannels = guildDetails?.channels.length || selectedGuild?.channelsCount || 0;
  const categoriesCount = guildDetails?.channels.filter(c => c.type === 4).length || 0;
  const textChannelsCount = guildDetails?.channels.filter(c => c.type === 0 || c.type === 5).length || 0;
  const voiceChannelsCount = guildDetails?.channels.filter(c => c.type === 2).length || 0;
  const rolesCount = guildDetails?.roles.length || selectedGuild?.rolesCount || 0;

  const isDemo = selectedGuild?.isDemo;

  return (
    <div className="max-w-6xl mx-auto py-8 px-6 space-y-8 animate-fadeIn">
      {/* Top Banner if in Demo Mode */}
      {isDemo && (
        <div className="bg-[#121212] border border-[#262626] rounded-lg p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded bg-amber-500/10 text-amber-400 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#F5F2EB]">
                Running in Simulated Demo Environment
              </h3>
              <p className="text-xs text-[#9E9B95] mt-0.5 leading-relaxed">
                You are managing <span className="text-[#F5F2EB] font-mono">Blipmade Community (Demo Guild)</span>. All builder edits, diffs, and simulated deployments run safely without requiring Discord credentials.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('settings')}
            className="text-xs font-medium text-[#F5F2EB] hover:text-white bg-[#1C1C1C] hover:bg-[#262626] border border-[#333333] px-3.5 py-2 rounded transition-colors whitespace-nowrap cursor-pointer shrink-0"
          >
            Configure Bot Credentials
          </button>
        </div>
      )}

      {/* Primary Server Information & Selection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Server Card */}
        <div className="lg:col-span-2 bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-[#161616] border border-[#2B2B2B] flex items-center justify-center text-[#E64A4A] font-bold text-xl">
                {selectedGuild?.name ? selectedGuild.name.charAt(0) : 'B'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-semibold text-[#F5F2EB]">
                    {selectedGuild?.name || 'Selected Discord Server'}
                  </h2>
                  {isDemo ? (
                    <span className="text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      Simulated
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      Live Guild
                    </span>
                  )}
                </div>
                <p className="text-xs font-mono text-[#6E6C68] mt-1">
                  ID: {selectedGuild?.id || '—'}
                </p>
              </div>
            </div>

            {/* Server Selector Dropdown */}
            {guilds.length > 1 && (
              <select
                value={selectedGuild?.id || ''}
                onChange={(e) => setSelectedGuildId(e.target.value)}
                className="bg-[#141414] border border-[#2A2A2A] text-xs text-[#F5F2EB] px-3 py-1.5 rounded focus:outline-none focus:border-[#E64A4A]"
              >
                {guilds.map(g => (
                  <option key={g.id} value={g.id}>
                    {g.name} {g.isDemo ? '(Demo)' : ''}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Metric Figures */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3.5 rounded bg-[#111111] border border-[#1A1A1A]">
              <span className="text-xs text-[#9E9B95]">Total Channels</span>
              <p className="text-xl font-bold font-mono text-[#F5F2EB] mt-1 tabular-nums">
                {totalChannels}
              </p>
              <span className="text-[11px] text-[#6E6C68] mt-0.5 block">
                {textChannelsCount} text · {voiceChannelsCount} voice
              </span>
            </div>

            <div className="p-3.5 rounded bg-[#111111] border border-[#1A1A1A]">
              <span className="text-xs text-[#9E9B95]">Categories</span>
              <p className="text-xl font-bold font-mono text-[#F5F2EB] mt-1 tabular-nums">
                {categoriesCount}
              </p>
              <span className="text-[11px] text-[#6E6C68] mt-0.5 block">
                Hierarchy groups
              </span>
            </div>

            <div className="p-3.5 rounded bg-[#111111] border border-[#1A1A1A]">
              <span className="text-xs text-[#9E9B95]">Roles Configured</span>
              <p className="text-xl font-bold font-mono text-[#F5F2EB] mt-1 tabular-nums">
                {rolesCount}
              </p>
              <span className="text-[11px] text-[#6E6C68] mt-0.5 block">
                Access tiers
              </span>
            </div>

            <div className="p-3.5 rounded bg-[#111111] border border-[#1A1A1A]">
              <span className="text-xs text-[#9E9B95]">Target Template</span>
              <p className="text-sm font-semibold text-[#E64A4A] mt-2 truncate" title={activeTemplate.name}>
                {activeTemplate.name.replace('Blipmade | ', '')}
              </p>
              <span className="text-[11px] text-[#6E6C68] mt-0.5 block font-mono">
                v{activeTemplate.version}
              </span>
            </div>
          </div>

          {/* Direct Action Hub */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('builder')}
              className="flex items-center gap-2 bg-[#E64A4A] hover:bg-[#F05555] text-white text-xs font-medium px-4 py-2 rounded transition-colors cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Customize in Visual Builder</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => openDeployModal('MERGE')}
              className="flex items-center gap-2 bg-[#1A1A1A] hover:bg-[#242424] text-[#F5F2EB] border border-[#2B2B2B] text-xs font-medium px-4 py-2 rounded transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Safe Merge (Add Missing)</span>
            </button>

            <button
              onClick={() => setActiveTab('messages')}
              className="flex items-center gap-2 bg-[#141414] hover:bg-[#1C1C1C] text-[#9E9B95] hover:text-[#F5F2EB] border border-[#222222] text-xs font-medium px-4 py-2 rounded transition-colors cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Publish Official Embeds</span>
            </button>
          </div>
        </div>

        {/* Side Preflight & Status Verification Card */}
        <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 flex flex-col justify-between space-y-6">
          <div>
            <h3 className="text-sm font-semibold text-[#F5F2EB] flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#E64A4A]" />
              <span>Preflight & Integration Checks</span>
            </h3>
            <p className="text-xs text-[#9E9B95] mt-1 leading-relaxed">
              Validation status for official Discord API permissions and Blipmade telemetry.
            </p>

            <div className="mt-5 space-y-3">
              <div className="flex items-center justify-between text-xs py-2 border-b border-[#171717]">
                <span className="text-[#9E9B95]">Discord API Gateway</span>
                <span className="font-mono text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Connected
                </span>
              </div>

              <div className="flex items-center justify-between text-xs py-2 border-b border-[#171717]">
                <span className="text-[#9E9B95]">Manage Channels Perm</span>
                <span className="font-mono text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                </span>
              </div>

              <div className="flex items-center justify-between text-xs py-2 border-b border-[#171717]">
                <span className="text-[#9E9B95]">Manage Roles Perm</span>
                <span className="font-mono text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                </span>
              </div>

              <div className="flex items-center justify-between text-xs py-2 border-b border-[#171717]">
                <span className="text-[#9E9B95]">Status Webhook (#service-status)</span>
                {status?.integrations?.hasStatusWebhook ? (
                  <span className="font-mono text-emerald-400">Ready</span>
                ) : (
                  <span className="font-mono text-[#6E6C68]">Unset (Simulated)</span>
                )}
              </div>

              <div className="flex items-center justify-between text-xs py-2">
                <span className="text-[#9E9B95]">Ops Webhook (#ops-alerts)</span>
                {status?.integrations?.hasOpsWebhook ? (
                  <span className="font-mono text-emerald-400">Ready</span>
                ) : (
                  <span className="font-mono text-[#6E6C68]">Unset (Simulated)</span>
                )}
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-[#1A1A1A]">
            <a
              href="https://blipmade.com"
              target="_blank"
              rel="noreferrer"
              className="text-xs text-[#9E9B95] hover:text-[#F5F2EB] flex items-center justify-between py-1 transition-colors"
            >
              <span>Blipmade Cloud Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <a
              href="https://blipmade.com/docs"
              target="_blank"
              rel="noreferrer"
              className="text-xs text-[#9E9B95] hover:text-[#F5F2EB] flex items-center justify-between py-1 transition-colors"
            >
              <span>Infrastructure Documentation</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Target Template Blueprint Preview */}
      <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-[#F5F2EB]">
              Proposed Server Blueprint: {activeTemplate.name}
            </h3>
            <p className="text-xs text-[#9E9B95] mt-0.5">
              {activeTemplate.categories.length} categories · {activeTemplate.channels.length} channels · {activeTemplate.roles.length} roles
            </p>
          </div>
          <button
            onClick={() => setActiveTab('templates')}
            className="text-xs text-[#E64A4A] hover:text-[#F05555] font-medium transition-colors cursor-pointer"
          >
            Change Template →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
          {activeTemplate.categories.map(cat => {
            const childChannels = activeTemplate.channels.filter(
              c => c.categoryName?.toLowerCase() === cat.name.toLowerCase()
            );
            const isPrivate = cat.name.includes('PRIVATE') || cat.permissionOverwrites?.some(ow => ow.deny.includes('1024'));

            return (
              <div
                key={cat.name}
                className="bg-[#111111] border border-[#1C1C1C] rounded p-3 text-xs space-y-2"
              >
                <div className="flex items-center justify-between text-[#F5F2EB] font-semibold tracking-wide text-[11px]">
                  <span className="truncate">{cat.name}</span>
                  {isPrivate && (
                    <span className="text-[10px] text-[#E64A4A] font-mono font-normal">LOCK</span>
                  )}
                </div>
                <div className="space-y-1 text-[#9E9B95] font-mono text-[11px]">
                  {childChannels.map(ch => (
                    <div key={ch.name} className="truncate flex items-center gap-1.5 hover:text-[#F5F2EB]">
                      <span className="text-[#6E6C68]">{ch.type === 2 ? '🔊' : ch.type === 5 ? '📢' : '#'}</span>
                      <span>{ch.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Deployments Activity */}
      {recentRuns.length > 0 && (
        <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-[#F5F2EB] flex items-center gap-2">
              <ActivityIcon className="w-4 h-4 text-[#9E9B95]" />
              <span>Recent Reconciliation Operations</span>
            </h3>
            <button
              onClick={() => setActiveTab('activity')}
              className="text-xs text-[#9E9B95] hover:text-[#F5F2EB] transition-colors cursor-pointer"
            >
              View Full History →
            </button>
          </div>

          <div className="divide-y divide-[#171717] text-xs">
            {recentRuns.map(run => (
              <div key={run.id} className="py-3 flex items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-[#F5F2EB] font-mono">{run.mode}</span>
                    <span className="text-[#6E6C68]">·</span>
                    <span className="text-[#9E9B95]">{run.guildName}</span>
                    <span className="text-[#6E6C68]">·</span>
                    <span className={`font-mono text-[11px] ${run.status === 'SUCCESS' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {run.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#6E6C68] font-mono">
                    Created: {run.summary.channelsCreated} channels, {run.summary.rolesCreated} roles · Overwrites: {run.summary.overwritesApplied}
                  </p>
                </div>
                <span className="text-[11px] font-mono text-[#6E6C68] whitespace-nowrap">
                  {new Date(run.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
