/**
 * Top Bar Navigation
 * Strictly complies with Top Bar Contract (3 zones separated by gap-8)
 */

import React from 'react';
import { useStudio, StudioTab } from '../../context/StudioContext.tsx';
import { ShieldCheck, Sparkles, Layers, Send } from 'lucide-react';

const NAV_ITEMS: { id: StudioTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'builder', label: 'Server Builder' },
  { id: 'templates', label: 'Templates' },
  { id: 'roles', label: 'Roles & Perms' },
  { id: 'messages', label: 'Messages' },
  { id: 'activity', label: 'Activity' },
  { id: 'settings', label: 'Settings' },
];

export const Navbar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    status,
    selectedGuild,
    openDeployModal,
    hasUnsavedChanges,
  } = useStudio();

  const isLive = status?.isLive;

  return (
    <header className="h-14 border-b border-[#1E1E1E] bg-[#0A0A0A] px-6 flex items-center justify-between gap-8 shrink-0 select-none z-30">
      {/* Zone 1: Brand wordmark (single text element) */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('overview');
          }}
          className="text-sm font-semibold tracking-tight text-[#F5F2EB] hover:text-white transition-colors flex items-center gap-2.5 whitespace-nowrap"
        >
          <div className="w-6 h-6 rounded bg-[#E64A4A] flex items-center justify-center text-white font-black text-xs">
            B
          </div>
          <span>Blipmade Discord Studio</span>
        </a>
      </div>

      {/* Zone 2: Navigation Links (single-line, clean typography) */}
      <nav className="hidden lg:flex items-center gap-7 text-xs font-medium text-[#9E9B95]">
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`transition-colors whitespace-nowrap py-1 relative cursor-pointer ${
                isActive
                  ? 'text-[#F5F2EB] font-semibold'
                  : 'hover:text-[#F5F2EB]'
              }`}
            >
              {item.label}
              {isActive && (
                <span className="absolute bottom-[-16px] left-0 right-0 h-[2px] bg-[#E64A4A]" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1 Primary Action + Mode indicator */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Status Mode Indicator */}
        <div className="flex items-center gap-2 text-xs text-[#9E9B95] px-2.5 py-1 rounded bg-[#141414] border border-[#222222]">
          {isLive ? (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="text-[#F5F2EB] font-mono text-[11px]">LIVE: @{status?.botUser?.username || 'Bot'}</span>
            </>
          ) : (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
              <span className="text-[#F5F2EB] font-mono text-[11px]">DEMO MODE</span>
            </>
          )}
        </div>

        {/* Deploy / Sync CTA */}
        <button
          onClick={() => openDeployModal('MERGE')}
          className="flex items-center gap-2 bg-[#E64A4A] hover:bg-[#F05555] text-white text-xs font-semibold px-3.5 py-1.5 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm"
          title="Compare desired template with server and apply changes safely"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Deploy to Server</span>
          {hasUnsavedChanges && (
            <span className="w-1.5 h-1.5 rounded-full bg-white opacity-80" />
          )}
        </button>
      </div>
    </header>
  );
};
