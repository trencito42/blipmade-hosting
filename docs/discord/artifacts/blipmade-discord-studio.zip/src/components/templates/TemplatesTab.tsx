/**
 * Templates Section
 * Manage, export, import, inspect, and compare Discord server blueprints
 */

import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Layers,
  Download,
  Upload,
  CheckCircle2,
  Trash2,
  Plus,
  GitCompare,
  FileJson,
  ArrowRight,
  Shield,
  Copy,
} from 'lucide-react';
import { ServerTemplate } from '../../types/discord.ts';
import { saveTemplate, deleteTemplate } from '../../api/client.ts';

export const TemplatesTab: React.FC = () => {
  const {
    templates,
    activeTemplate,
    loadTemplate,
    setDraftTemplate,
    setActiveTab,
  } = useStudio();

  const [compareTemplateA, setCompareTemplateA] = useState<string>(activeTemplate.id);
  const [compareTemplateB, setCompareTemplateB] = useState<string>('blipmade-minimal-v1');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);

  const handleExportJson = (tmpl: ServerTemplate) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(tmpl, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${tmpl.id || 'blipmade-template'}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.FormEvent) => {
    e.preventDefault();
    setImportError(null);
    try {
      const parsed = JSON.parse(importJsonText);
      if (!parsed.name || !Array.isArray(parsed.channels) || !Array.isArray(parsed.roles)) {
        throw new Error('Template JSON must contain "name", "channels", and "roles" arrays.');
      }
      parsed.id = `template-import-${Date.now()}`;
      saveTemplate(parsed).then(saved => {
        setDraftTemplate(saved);
        setIsImportModalOpen(false);
        setImportJsonText('');
      });
    } catch (err: any) {
      setImportError(err.message || 'Invalid JSON syntax');
    }
  };

  const tmplA = templates.find(t => t.id === compareTemplateA) || activeTemplate;
  const tmplB = templates.find(t => t.id === compareTemplateB) || templates[1] || activeTemplate;

  return (
    <div className="max-w-6xl mx-auto py-8 px-6 space-y-8 animate-fadeIn select-none">
      {/* Header with Import / Export triggers */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-5">
        <div>
          <h2 className="text-base font-semibold text-[#F5F2EB]">
            Discord Server Templates Library
          </h2>
          <p className="text-xs text-[#9E9B95] mt-0.5">
            Pre-engineered blueprints for Blipmade cloud hosting, game nodes, and development infrastructure.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 bg-[#141414] hover:bg-[#1E1E1E] text-[#F5F2EB] border border-[#222222] text-xs font-medium px-3.5 py-1.5 rounded transition-colors cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-[#9E9B95]" />
            <span>Import JSON</span>
          </button>

          <button
            onClick={() => handleExportJson(activeTemplate)}
            className="flex items-center gap-2 bg-[#141414] hover:bg-[#1E1E1E] text-[#F5F2EB] border border-[#222222] text-xs font-medium px-3.5 py-1.5 rounded transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#9E9B95]" />
            <span>Export Active Draft</span>
          </button>
        </div>
      </div>

      {/* Available Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {templates.map(tmpl => {
          const isCurrentlyActive = activeTemplate.id === tmpl.id;
          const isOfficial = tmpl.id.startsWith('blipmade-');

          return (
            <div
              key={tmpl.id}
              className={`bg-[#0D0D0D] border rounded-lg p-5 flex flex-col justify-between space-y-4 transition-all ${
                isCurrentlyActive
                  ? 'border-[#E64A4A] ring-1 ring-[#E64A4A]/20'
                  : 'border-[#1F1F1F] hover:border-[#2C2C2C]'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded bg-[#161616] border border-[#262626] flex items-center justify-center text-[#E64A4A]">
                      <Layers className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <h3 className="text-xs font-semibold text-[#F5F2EB]">
                        {tmpl.name}
                      </h3>
                      <span className="text-[10px] font-mono text-[#6E6C68]">
                        v{tmpl.version} · {tmpl.author}
                      </span>
                    </div>
                  </div>
                  {isOfficial && (
                    <span className="text-[10px] font-mono bg-[#E64A4A]/10 text-[#E64A4A] px-1.5 py-0.5 rounded border border-[#E64A4A]/20">
                      Official
                    </span>
                  )}
                </div>

                <p className="text-xs text-[#9E9B95] leading-relaxed">
                  {tmpl.description}
                </p>

                <div className="flex items-center gap-4 text-xs font-mono text-[#6E6C68] pt-2 border-t border-[#161616]">
                  <span>{tmpl.categories.length} Categories</span>
                  <span>·</span>
                  <span>{tmpl.channels.length} Channels</span>
                  <span>·</span>
                  <span>{tmpl.roles.length} Roles</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#161616]">
                <button
                  onClick={() => handleExportJson(tmpl)}
                  className="p-1.5 text-[#6E6C68] hover:text-[#F5F2EB] text-xs cursor-pointer"
                  title="Download template JSON"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center gap-2">
                  {isCurrentlyActive ? (
                    <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Loaded
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        loadTemplate(tmpl.id);
                        setActiveTab('builder');
                      }}
                      className="text-xs bg-[#E64A4A] hover:bg-[#F05555] text-white px-3 py-1.5 rounded font-medium transition-colors cursor-pointer"
                    >
                      Load in Builder
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Template Comparison & Diff Viewer */}
      <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#181818] pb-4">
          <div className="flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-[#E64A4A]" />
            <h3 className="text-sm font-semibold text-[#F5F2EB]">
              Template Version Inspector & Diff Tool
            </h3>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <select
              value={compareTemplateA}
              onChange={(e) => setCompareTemplateA(e.target.value)}
              className="bg-[#141414] border border-[#262626] rounded px-2.5 py-1.5 text-[#F5F2EB]"
            >
              {templates.map(t => (
                <option key={t.id} value={t.id}>Left: {t.name}</option>
              ))}
            </select>

            <span className="text-[#6E6C68]">vs</span>

            <select
              value={compareTemplateB}
              onChange={(e) => setCompareTemplateB(e.target.value)}
              className="bg-[#141414] border border-[#262626] rounded px-2.5 py-1.5 text-[#F5F2EB]"
            >
              {templates.map(t => (
                <option key={t.id} value={t.id}>Right: {t.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* 2-Column Comparison Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Template Details */}
          <div className="bg-[#111111] border border-[#1A1A1A] rounded p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-[#F5F2EB]">
              <span>{tmplA.name}</span>
              <span className="text-[11px] font-mono text-[#6E6C68]">v{tmplA.version}</span>
            </div>
            <div className="space-y-1 text-xs text-[#9E9B95] font-mono max-h-56 overflow-y-auto">
              <span className="text-[10px] uppercase text-[#6E6C68] font-semibold block mb-1">Categories & Channels</span>
              {tmplA.categories.map(cat => (
                <div key={cat.name} className="space-y-0.5">
                  <div className="text-[#F5F2EB] font-bold">[{cat.name}]</div>
                  {tmplA.channels
                    .filter(c => c.categoryName?.toLowerCase() === cat.name.toLowerCase())
                    .map(ch => (
                      <div key={ch.name} className="pl-3 text-[#9E9B95]">#{ch.name}</div>
                    ))}
                </div>
              ))}
            </div>
          </div>

          {/* Right Template Details */}
          <div className="bg-[#111111] border border-[#1A1A1A] rounded p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-[#F5F2EB]">
              <span>{tmplB.name}</span>
              <span className="text-[11px] font-mono text-[#6E6C68]">v{tmplB.version}</span>
            </div>
            <div className="space-y-1 text-xs text-[#9E9B95] font-mono max-h-56 overflow-y-auto">
              <span className="text-[10px] uppercase text-[#6E6C68] font-semibold block mb-1">Categories & Channels</span>
              {tmplB.categories.map(cat => (
                <div key={cat.name} className="space-y-0.5">
                  <div className="text-[#F5F2EB] font-bold">[{cat.name}]</div>
                  {tmplB.channels
                    .filter(c => c.categoryName?.toLowerCase() === cat.name.toLowerCase())
                    .map(ch => (
                      <div key={ch.name} className="pl-3 text-[#9E9B95]">#{ch.name}</div>
                    ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <form
            onSubmit={handleImportJson}
            className="bg-[#0F0F0F] border border-[#222222] rounded-lg p-6 w-full max-w-lg space-y-4 shadow-xl"
          >
            <h3 className="text-sm font-semibold text-[#F5F2EB] flex items-center gap-2">
              <FileJson className="w-4 h-4 text-[#E64A4A]" />
              <span>Import Server Template JSON</span>
            </h3>
            <p className="text-xs text-[#9E9B95]">
              Paste exported template JSON or backup file content to import as a new reusable template.
            </p>

            <textarea
              rows={8}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder='{ "name": "My Custom Template", "categories": [...], "channels": [...], "roles": [...] }'
              className="w-full bg-[#141414] border border-[#282828] rounded p-3 text-xs text-[#F5F2EB] font-mono focus:outline-none focus:border-[#E64A4A]"
            />

            {importError && (
              <div className="p-2 rounded bg-rose-950/30 border border-rose-500/30 text-rose-300 text-xs">
                {importError}
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsImportModalOpen(false)}
                className="px-3 py-1.5 text-xs text-[#9E9B95] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!importJsonText.trim()}
                className="px-4 py-1.5 text-xs bg-[#E64A4A] hover:bg-[#F05555] text-white rounded font-medium disabled:opacity-50 cursor-pointer"
              >
                Import Template
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
