/**
 * Messages & Embed Composer
 * Interactive Discord embed authoring and publishing suite
 */

import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  FileText,
  Send,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Loader2,
  Copy,
  Sparkles,
} from 'lucide-react';
import { publishMessage } from '../../api/client.ts';

interface EmbedField {
  name: string;
  value: string;
  inline: boolean;
}

interface MessageDraft {
  title: string;
  description: string;
  color: number;
  authorName: string;
  footerText: string;
  thumbnailUrl: string;
  imageUrl: string;
  fields: EmbedField[];
}

const PRESET_MESSAGES: { id: string; label: string; channelTarget: string; draft: MessageDraft }[] = [
  {
    id: 'welcome',
    label: 'Welcome & Infrastructure Overview',
    channelTarget: 'welcome',
    draft: {
      title: 'Welcome to Blipmade Cloud Infrastructure',
      description: 'Blipmade provides resilient enterprise VPS hosting, AMD Ryzen dedicated game servers, and containerized bot platforms.\n\n• **Cloud Dashboard**: https://blipmade.com\n• **Documentation**: https://blipmade.com/docs\n• **Platform Status**: https://blipmade.com/status\n• **Support Tickets**: https://blipmade.com/app/tickets\n\n*Review #rules before chatting and select your hosting interests below!*',
      color: 0xE64A4A,
      authorName: 'Blipmade Operations',
      footerText: 'Blipmade High-Performance Hosting · London & Frankfurt',
      thumbnailUrl: '',
      imageUrl: '',
      fields: [
        { name: 'Need Technical Help?', value: 'For billing, SLA inquiries, or private server matters, open an official ticket at [blipmade.com/app/tickets](https://blipmade.com/app/tickets). For peer discussions, use #community-help.', inline: false },
        { name: 'Customer Verification', value: 'Link your Discord in your customer portal to receive the Verified Customer badge.', inline: true },
        { name: 'Game Server Nodes', value: 'High-frequency Ryzen 9 9950X compute nodes live in US & EU.', inline: true },
      ],
    },
  },
  {
    id: 'rules',
    label: 'Official Community Standards (8 Rules)',
    channelTarget: 'rules',
    draft: {
      title: 'Blipmade Community Standards & Policies',
      description: 'To ensure a stable, productive environment for all developers, system administrators, and game server owners, adhere to these 8 policies:\n\n1. **Respect & Professional Conduct**: Treat all customers, engineers, and support staff with courtesy.\n2. **No Malicious Activity**: Do not discuss, distribute, or configure exploits, stressers/DDoS tools, or malware.\n3. **Privacy & Security**: Never share root SSH credentials, API secrets, or personal billing invoices in public channels.\n4. **Appropriate Channels**: Post questions in the matching channel (#vps-hosting, #game-servers, #apps-and-bots).\n5. **Billing & Dispute Routing**: All payment and SLA disputes must be directed to https://blipmade.com/app/tickets.\n6. **No Unsolicited Advertising**: Competing services or crypto promotions are strictly prohibited.\n7. **Comply with Discord TOS**: You must adhere to Discord\'s Terms of Service and Community Guidelines.\n8. **Follow Staff Guidance**: Blipmade staff decisions are final.',
      color: 0xE64A4A,
      authorName: 'Blipmade Trust & Safety',
      footerText: 'Policies enforced across all Blipmade communication hubs',
      thumbnailUrl: '',
      imageUrl: '',
      fields: [],
    },
  },
  {
    id: 'support-guide',
    label: 'Support Ticketing vs Community Help Guide',
    channelTarget: 'community-help',
    draft: {
      title: 'Blipmade Technical Support Routing',
      description: 'Here is how to get help quickly and securely:\n\n**Official Authenticated Ticket System** (Required for private matters):\n• Billing, invoices, and refunds\n• VPS root password resets\n• IP address reassignments & rDNS\n• Service outages & SLA claims\n👉 Open a ticket: **https://blipmade.com/app/tickets**\n\n**Community Peer Help** (#community-help):\n• Linux configuration advice\n• Docker and reverse proxy configs\n• Game server mod installation (Paper/Fabric/Forge)\n• General hosting optimization tips',
      color: 0x3B82F6,
      authorName: 'Blipmade Support Team',
      footerText: 'Never disclose passwords or SSH keys to anyone claiming to be staff on Discord',
      thumbnailUrl: '',
      imageUrl: '',
      fields: [],
    },
  },
  {
    id: 'incident',
    label: 'Service Incident / Scheduled Maintenance Notice',
    channelTarget: 'service-status',
    draft: {
      title: 'Scheduled Maintenance Notice: Frankfurt Node Cluster',
      description: 'Datacenter node cluster **fra1-vps-c2** is scheduled for automated memory compaction and Linux kernel 6.8 live patching.\n\n• **Window**: Saturday 03:00 UTC - 03:30 UTC\n• **Expected Impact**: Brief network reboot (< 30 seconds)\n• **Real-time Status**: https://blipmade.com/status',
      color: 0xF59E0B,
      authorName: 'Blipmade Infrastructure Prober',
      footerText: 'Automated Telemetry Dispatch',
      thumbnailUrl: '',
      imageUrl: '',
      fields: [
        { name: 'Impacted Tiers', value: 'Standard NVMe VPS in FRA1', inline: true },
        { name: 'Dedicated Game Nodes', value: 'Unaffected (Isolated HW)', inline: true },
      ],
    },
  },
];

export const MessagesTab: React.FC = () => {
  const { selectedGuild, activeTemplate } = useStudio();

  const [activePresetId, setActivePresetId] = useState<string>('welcome');
  const [targetChannelName, setTargetChannelName] = useState<string>('welcome');
  const [draft, setDraft] = useState<MessageDraft>(PRESET_MESSAGES[0].draft);

  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishSuccess, setPublishSuccess] = useState<string | null>(null);
  const [publishError, setPublishError] = useState<string | null>(null);

  const handleSelectPreset = (presetId: string) => {
    const found = PRESET_MESSAGES.find(p => p.id === presetId);
    if (found) {
      setActivePresetId(presetId);
      setTargetChannelName(found.channelTarget);
      setDraft(JSON.parse(JSON.stringify(found.draft)));
      setPublishSuccess(null);
    }
  };

  const handleAddField = () => {
    setDraft(prev => ({
      ...prev,
      fields: [...prev.fields, { name: 'Field Title', value: 'Field description or link', inline: true }],
    }));
  };

  const handleUpdateField = (index: number, changes: Partial<EmbedField>) => {
    setDraft(prev => {
      const copy = [...prev.fields];
      copy[index] = { ...copy[index], ...changes };
      return { ...prev, fields: copy };
    });
  };

  const handleRemoveField = (index: number) => {
    setDraft(prev => ({
      ...prev,
      fields: prev.fields.filter((_, i) => i !== index),
    }));
  };

  const handleExecutePublish = async () => {
    setIsPublishing(true);
    setPublishError(null);

    try {
      const payload = {
        channelId: targetChannelName,
        guildId: selectedGuild?.id,
        message: {
          embeds: [
            {
              title: draft.title,
              description: draft.description,
              color: draft.color,
              author: draft.authorName ? { name: draft.authorName } : undefined,
              footer: draft.footerText ? { text: draft.footerText } : undefined,
              fields: draft.fields.map(f => ({ name: f.name, value: f.value, inline: f.inline })),
              timestamp: new Date().toISOString(),
            },
          ],
        },
      };

      await publishMessage(payload);
      setPublishSuccess(`Successfully published message to #${targetChannelName}`);
      setIsPublishModalOpen(false);
    } catch (err: any) {
      setPublishError(err.message || 'Failed to publish message');
    } finally {
      setIsPublishing(false);
    }
  };

  const hexColor = `#${draft.color.toString(16).padStart(6, '0')}`;

  return (
    <div className="max-w-6xl mx-auto py-8 px-6 space-y-8 animate-fadeIn select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-5">
        <div>
          <h2 className="text-base font-semibold text-[#F5F2EB]">
            Discord Message & Embed Studio
          </h2>
          <p className="text-xs text-[#9E9B95] mt-0.5">
            Craft rich embeds for welcome messages, rules, guides, and platform notices.
          </p>
        </div>

        <button
          onClick={() => setIsPublishModalOpen(true)}
          className="flex items-center gap-2 bg-[#E64A4A] hover:bg-[#F05555] text-white text-xs font-semibold px-4 py-2 rounded transition-colors cursor-pointer shadow-sm"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Publish Embed to #{targetChannelName}</span>
        </button>
      </div>

      {publishSuccess && (
        <div className="p-3 rounded bg-emerald-950/20 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{publishSuccess}</span>
          </div>
          <button onClick={() => setPublishSuccess(null)} className="text-emerald-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Preset Selector */}
      <div className="flex flex-wrap items-center gap-2">
        {PRESET_MESSAGES.map(preset => (
          <button
            key={preset.id}
            onClick={() => handleSelectPreset(preset.id)}
            className={`px-3 py-1.5 rounded text-xs transition-colors cursor-pointer ${
              activePresetId === preset.id
                ? 'bg-[#1C1C1C] text-[#F5F2EB] border border-[#2E2E2E] font-medium'
                : 'bg-[#121212] text-[#9E9B95] border border-[#1A1A1A] hover:border-[#262626]'
            }`}
          >
            {preset.label}
          </button>
        ))}
      </div>

      {/* 2-Column Split: Form Editor (Left) & Discord Preview (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Form Editor */}
        <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-5 space-y-4 text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-[#1A1A1A]">
            <h3 className="font-semibold text-[#F5F2EB] uppercase tracking-wider text-[11px]">
              Embed Configuration
            </h3>
            <div className="flex items-center gap-2">
              <label className="text-[#6E6C68]">Target Channel:</label>
              <select
                value={targetChannelName}
                onChange={(e) => setTargetChannelName(e.target.value)}
                className="bg-[#141414] border border-[#262626] rounded px-2.5 py-1 text-[#F5F2EB] font-mono text-[11px]"
              >
                {activeTemplate.channels.filter(c => c.type === 0 || c.type === 5).map(c => (
                  <option key={c.name} value={c.name}>#{c.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-[#9E9B95] block mb-1">Author Name</label>
            <input
              type="text"
              value={draft.authorName}
              onChange={(e) => setDraft({ ...draft, authorName: e.target.value })}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
            />
          </div>

          <div>
            <label className="text-[#9E9B95] block mb-1">Embed Title</label>
            <input
              type="text"
              value={draft.title}
              onChange={(e) => setDraft({ ...draft, title: e.target.value })}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] font-semibold focus:outline-none focus:border-[#E64A4A]"
            />
          </div>

          <div>
            <label className="text-[#9E9B95] block mb-1">Description (Supports Discord Markdown & URLs)</label>
            <textarea
              rows={7}
              value={draft.description}
              onChange={(e) => setDraft({ ...draft, description: e.target.value })}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#F5F2EB] font-mono text-[11px] leading-relaxed focus:outline-none focus:border-[#E64A4A] resize-y"
            />
          </div>

          <div>
            <label className="text-[#9E9B95] block mb-1">Accent Bar Color</label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={hexColor}
                onChange={(e) => setDraft({ ...draft, color: parseInt(e.target.value.replace('#', ''), 16) })}
                className="w-8 h-8 rounded bg-transparent border border-[#262626] cursor-pointer"
              />
              <span className="font-mono text-[#F5F2EB]">{hexColor.toUpperCase()}</span>
            </div>
          </div>

          {/* Fields List */}
          <div className="pt-2 border-t border-[#181818] space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#9E9B95] text-[11px]">Embed Fields</span>
              <button
                onClick={handleAddField}
                className="text-[11px] text-[#E64A4A] hover:text-[#F05555] flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" /> Add Field
              </button>
            </div>

            <div className="space-y-2">
              {draft.fields.map((f, idx) => (
                <div key={idx} className="bg-[#121212] border border-[#1E1E1E] rounded p-2.5 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <input
                      type="text"
                      value={f.name}
                      onChange={(e) => handleUpdateField(idx, { name: e.target.value })}
                      placeholder="Field Title"
                      className="w-1/2 bg-[#181818] border border-[#242424] rounded px-2 py-1 text-[#F5F2EB] font-medium"
                    />
                    <label className="flex items-center gap-1 text-[11px] text-[#6E6C68]">
                      <input
                        type="checkbox"
                        checked={f.inline}
                        onChange={(e) => handleUpdateField(idx, { inline: e.target.checked })}
                        className="accent-[#E64A4A]"
                      />
                      Inline
                    </label>
                    <button
                      onClick={() => handleRemoveField(idx)}
                      className="text-[#6E6C68] hover:text-[#E64A4A] p-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <input
                    type="text"
                    value={f.value}
                    onChange={(e) => handleUpdateField(idx, { value: e.target.value })}
                    placeholder="Field Value / Content"
                    className="w-full bg-[#181818] border border-[#242424] rounded px-2 py-1 text-[#9E9B95]"
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[#9E9B95] block mb-1">Footer Text</label>
            <input
              type="text"
              value={draft.footerText}
              onChange={(e) => setDraft({ ...draft, footerText: e.target.value })}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB]"
            />
          </div>
        </div>

        {/* Live Discord Embed Preview */}
        <div className="bg-[#0C0C0C] border border-[#1F1F1F] rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#181818]">
            <span className="text-xs font-semibold text-[#F5F2EB] uppercase tracking-wider">
              Discord Live Client Preview
            </span>
            <span className="text-[11px] font-mono text-[#6E6C68]">
              Target: #{targetChannelName}
            </span>
          </div>

          {/* User message header */}
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-[#E64A4A] flex items-center justify-center text-white font-bold text-sm shrink-0">
              B
            </div>
            <div className="space-y-1 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#F5F2EB]">Blipmade Bot</span>
                <span className="text-[10px] font-mono bg-[#E64A4A]/20 text-[#E64A4A] px-1 rounded">
                  BOT
                </span>
                <span className="text-[10px] text-[#6E6C68] font-mono">Today at 12:00 PM</span>
              </div>

              {/* Rich Embed Box */}
              <div className="bg-[#111111] border border-[#1A1A1A] rounded p-4 relative overflow-hidden space-y-3 mt-2">
                {/* Accent Color Left Bar */}
                <div
                  className="absolute left-0 top-0 bottom-0 w-1"
                  style={{ backgroundColor: hexColor }}
                />

                <div className="pl-2 space-y-2.5">
                  {draft.authorName && (
                    <div className="text-[11px] font-semibold text-[#D8D5CD]">
                      {draft.authorName}
                    </div>
                  )}

                  <h3 className="text-sm font-bold text-[#F5F2EB]">
                    {draft.title || 'Untitled Embed'}
                  </h3>

                  <div className="text-xs text-[#C5C2BA] leading-relaxed whitespace-pre-line">
                    {draft.description}
                  </div>

                  {draft.fields.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      {draft.fields.map((f, i) => (
                        <div key={i} className="text-xs">
                          <div className="font-semibold text-[#F5F2EB]">{f.name}</div>
                          <div className="text-[#9E9B95] mt-0.5 leading-snug">{f.value}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  {draft.footerText && (
                    <div className="text-[10px] text-[#6E6C68] pt-2 border-t border-[#181818] flex items-center justify-between">
                      <span>{draft.footerText}</span>
                      <span className="font-mono">Today at 12:00 PM</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal Before Publishing */}
      {isPublishModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#0F0F0F] border border-[#222222] rounded-lg p-6 w-full max-w-md space-y-4 shadow-xl">
            <h3 className="text-sm font-semibold text-[#F5F2EB] flex items-center gap-2">
              <Send className="w-4 h-4 text-[#E64A4A]" />
              <span>Confirm Message Publication</span>
            </h3>

            <p className="text-xs text-[#9E9B95] leading-relaxed">
              Are you sure you want to publish the <span className="font-semibold text-[#F5F2EB]">"{draft.title}"</span> embed to channel <span className="font-mono text-[#F5F2EB]">#{targetChannelName}</span> on <span className="font-semibold text-[#F5F2EB]">{selectedGuild?.name}</span>?
            </p>

            {publishError && (
              <div className="p-2 rounded bg-rose-950/30 border border-rose-500/30 text-rose-300 text-xs">
                {publishError}
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsPublishModalOpen(false)}
                disabled={isPublishing}
                className="px-3 py-1.5 text-xs text-[#9E9B95] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecutePublish}
                disabled={isPublishing}
                className="flex items-center gap-1.5 px-4 py-1.5 text-xs bg-[#E64A4A] hover:bg-[#F05555] text-white rounded font-medium cursor-pointer"
              >
                {isPublishing ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Publishing...</span>
                  </>
                ) : (
                  <span>Confirm & Send</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
