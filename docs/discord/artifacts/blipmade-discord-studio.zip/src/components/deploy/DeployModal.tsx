/**
 * Deploy & Reconciliation Modal
 * Diff review, MERGE / SYNC / REPLACE mode selector, confirmation phrase, live execution runner
 */

import React, { useState, useEffect } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  X,
  AlertTriangle,
  CheckCircle2,
  Send,
  Download,
  Loader2,
  ShieldAlert,
  ArrowRight,
  Plus,
  RefreshCw,
  Trash2,
  FileText,
} from 'lucide-react';
import { executeDeploy, calculateDiff } from '../../api/client.ts';
import { AuditRun, ServerDiff } from '../../types/discord.ts';

export const DeployModal: React.FC = () => {
  const {
    selectedGuild,
    activeTemplate,
    isDeployModalOpen,
    closeDeployModal,
    deployMode: initialDeployMode,
    refreshGuildDetails,
    refreshStatus,
  } = useStudio();

  const [mode, setMode] = useState<'MERGE' | 'SYNC' | 'REPLACE'>(initialDeployMode || 'MERGE');
  const [diff, setDiff] = useState<ServerDiff | null>(null);
  const [loadingDiff, setLoadingDiff] = useState(false);
  const [publishInitialMessages, setPublishInitialMessages] = useState(true);
  const [confirmationPhrase, setConfirmationPhrase] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<AuditRun | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync mode with prop
  useEffect(() => {
    if (initialDeployMode) {
      setMode(initialDeployMode);
    }
  }, [initialDeployMode]);

  // Load diff whenever modal opens or mode changes
  useEffect(() => {
    if (!isDeployModalOpen || !selectedGuild) return;
    setLoadingDiff(true);
    setErrorMsg(null);
    setExecutionResult(null);

    calculateDiff({
      guildId: selectedGuild.id,
      customTemplate: activeTemplate,
    })
      .then(d => setDiff(d))
      .catch(err => setErrorMsg(err.message))
      .finally(() => setLoadingDiff(false));
  }, [isDeployModalOpen, selectedGuild, activeTemplate]);

  if (!isDeployModalOpen || !selectedGuild) return null;

  const REQUIRED_REPLACE_PHRASE = 'CONFIRM REPLACE BLIPMADE SERVER';
  const isPhraseValid = mode !== 'REPLACE' || confirmationPhrase === REQUIRED_REPLACE_PHRASE;

  const handleStartDeploy = async () => {
    if (!isPhraseValid) return;
    setIsExecuting(true);
    setErrorMsg(null);

    try {
      const result = await executeDeploy({
        guildId: selectedGuild.id,
        guildName: selectedGuild.name,
        mode,
        customTemplate: activeTemplate,
        confirmationPhrase: mode === 'REPLACE' ? confirmationPhrase : undefined,
        publishInitialMessages,
      });

      setExecutionResult(result);
      await refreshGuildDetails();
      await refreshStatus();
    } catch (err: any) {
      setErrorMsg(err.message || 'Deployment execution failed');
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none animate-fadeIn">
      <div className="bg-[#0D0D0D] border border-[#222222] rounded-xl w-full max-w-3xl flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="h-14 border-b border-[#1A1A1A] px-6 flex items-center justify-between bg-[#111111] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded bg-[#E64A4A]/10 border border-[#E64A4A]/30 flex items-center justify-center text-[#E64A4A]">
              <Send className="w-3.5 h-3.5" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-[#F5F2EB]">
                Deploy Configuration to {selectedGuild.name}
              </h2>
              <span className="text-[11px] text-[#6E6C68] font-mono">
                {selectedGuild.isDemo ? 'Simulated Demo Guild' : `Target ID: ${selectedGuild.id}`}
              </span>
            </div>
          </div>
          <button
            onClick={closeDeployModal}
            className="p-1.5 text-[#6E6C68] hover:text-[#F5F2EB] rounded hover:bg-[#1A1A1A] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Result view if execution finished */}
          {executionResult ? (
            <div className="space-y-4">
              <div className={`p-4 rounded-lg border ${
                executionResult.status === 'SUCCESS'
                  ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-950/20 border-amber-500/30 text-amber-300'
              }`}>
                <div className="flex items-center gap-2 font-semibold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Deployment Completed: {executionResult.status}</span>
                </div>
                <p className="text-xs mt-1 text-[#9E9B95]">
                  Reconciled in <span className="font-mono">{executionResult.mode}</span> mode.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3 pt-3 border-t border-emerald-500/20 text-xs font-mono">
                  <div>Channels Created: {executionResult.summary.channelsCreated}</div>
                  <div>Roles Created: {executionResult.summary.rolesCreated}</div>
                  <div>Overwrites: {executionResult.summary.overwritesApplied}</div>
                  <div>Deletions: {executionResult.summary.channelsDeleted}</div>
                </div>
              </div>

              {/* Step by Step Trace */}
              <div className="bg-[#090909] border border-[#1A1A1A] rounded p-3 font-mono text-xs max-h-48 overflow-y-auto space-y-1">
                {executionResult.details.map((d, i) => (
                  <div key={i} className="flex items-center justify-between text-[11px]">
                    <span className="text-[#D8D5CD]">{d.target}</span>
                    <span className={d.status === 'SUCCESS' ? 'text-emerald-400' : 'text-rose-400'}>
                      {d.status} ({d.action})
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-3 pt-4">
                <button
                  onClick={closeDeployModal}
                  className="bg-[#E64A4A] hover:bg-[#F05555] text-white text-xs font-semibold px-4 py-2 rounded cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Mode Selection Tabs */}
              <div>
                <label className="text-xs text-[#9E9B95] block mb-2 font-medium">
                  Reconciliation Strategy
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* MERGE Mode */}
                  <div
                    onClick={() => setMode('MERGE')}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      mode === 'MERGE'
                        ? 'bg-[#161616] border-[#E64A4A] text-[#F5F2EB]'
                        : 'bg-[#111111] border-[#1C1C1C] text-[#9E9B95] hover:border-[#2C2C2C]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs text-[#F5F2EB]">MERGE (Recommended)</span>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-mono">Safe</span>
                    </div>
                    <p className="text-[11px] text-[#6E6C68] mt-1.5 leading-snug">
                      Adds only missing roles, categories, and channels. Never modifies or deletes existing Discord content.
                    </p>
                  </div>

                  {/* SYNC Mode */}
                  <div
                    onClick={() => setMode('SYNC')}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      mode === 'SYNC'
                        ? 'bg-[#161616] border-[#E64A4A] text-[#F5F2EB]'
                        : 'bg-[#111111] border-[#1C1C1C] text-[#9E9B95] hover:border-[#2C2C2C]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs text-[#F5F2EB]">SYNC</span>
                      <span className="text-[10px] bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded font-mono">Updates</span>
                    </div>
                    <p className="text-[11px] text-[#6E6C68] mt-1.5 leading-snug">
                      Creates missing items and updates mismatched properties (positions, topics, colors).
                    </p>
                  </div>

                  {/* REPLACE STRUCTURE Mode */}
                  <div
                    onClick={() => setMode('REPLACE')}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      mode === 'REPLACE'
                        ? 'bg-[#1E1111] border-rose-500 text-rose-200'
                        : 'bg-[#111111] border-[#1C1C1C] text-[#9E9B95] hover:border-rose-900/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs text-rose-400">REPLACE</span>
                      <span className="text-[10px] bg-rose-500/10 text-rose-400 px-1.5 py-0.5 rounded font-mono">Destructive</span>
                    </div>
                    <p className="text-[11px] text-[#805050] mt-1.5 leading-snug">
                      Purges existing channels and reinstalls fresh structure. Automatically saves backup first.
                    </p>
                  </div>
                </div>
              </div>

              {/* Diff Inspection */}
              {loadingDiff ? (
                <div className="p-8 text-center text-xs text-[#9E9B95] flex items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-[#E64A4A]" />
                  <span>Calculating real-time server diff...</span>
                </div>
              ) : diff ? (
                <div className="bg-[#101010] border border-[#1A1A1A] rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs border-b border-[#181818] pb-2">
                    <span className="font-semibold text-[#F5F2EB]">
                      Proposed Structural Changes ({diff.totalChanges} modifications)
                    </span>
                    <span className="font-mono text-[#9E9B95] text-[11px]">
                      Template: {diff.targetTemplateName}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    {/* Additions */}
                    <div className="space-y-1.5 bg-[#141414] p-3 rounded border border-[#1C1C1C]">
                      <span className="text-emerald-400 font-medium flex items-center gap-1 text-[11px]">
                        <Plus className="w-3 h-3" /> To Create ({diff.channels.toCreate.length + diff.roles.toCreate.length + diff.categories.toCreate.length})
                      </span>
                      <div className="space-y-1 text-[11px] text-[#9E9B95] max-h-36 overflow-y-auto">
                        {diff.categories.toCreate.map(c => (
                          <div key={c.item.name} className="truncate">Category: [{c.item.name}]</div>
                        ))}
                        {diff.channels.toCreate.map(ch => (
                          <div key={ch.item.name} className="truncate">#{ch.item.name}</div>
                        ))}
                        {diff.roles.toCreate.map(r => (
                          <div key={r.item.name} className="truncate">@{r.item.name}</div>
                        ))}
                      </div>
                    </div>

                    {/* Updates */}
                    <div className="space-y-1.5 bg-[#141414] p-3 rounded border border-[#1C1C1C]">
                      <span className="text-blue-400 font-medium flex items-center gap-1 text-[11px]">
                        <RefreshCw className="w-3 h-3" /> To Update ({diff.channels.toUpdate.length + diff.roles.toUpdate.length})
                      </span>
                      <div className="space-y-1 text-[11px] text-[#9E9B95] max-h-36 overflow-y-auto">
                        {diff.channels.toUpdate.map(ch => (
                          <div key={ch.item.proposed.name} className="truncate">#{ch.item.proposed.name}</div>
                        ))}
                        {diff.roles.toUpdate.map(r => (
                          <div key={r.item.proposed.name} className="truncate">@{r.item.proposed.name}</div>
                        ))}
                        {diff.channels.toUpdate.length === 0 && diff.roles.toUpdate.length === 0 && (
                          <span className="text-[#555555] italic">None</span>
                        )}
                      </div>
                    </div>

                    {/* Unchanged / Protected */}
                    <div className="space-y-1.5 bg-[#141414] p-3 rounded border border-[#1C1C1C]">
                      <span className="text-[#6E6C68] font-medium flex items-center gap-1 text-[11px]">
                        <CheckCircle2 className="w-3 h-3" /> Unchanged ({diff.channels.unchanged.length + diff.roles.unchanged.length})
                      </span>
                      <div className="space-y-1 text-[11px] text-[#6E6C68] max-h-36 overflow-y-auto">
                        {diff.channels.unchanged.map(ch => (
                          <div key={ch.id} className="truncate">#{ch.name}</div>
                        ))}
                        {diff.roles.unchanged.map(r => (
                          <div key={r.id} className="truncate">@{r.name}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}

              {/* Options */}
              <div className="flex items-center gap-2 pt-1 text-xs text-[#9E9B95]">
                <input
                  type="checkbox"
                  id="initialMsgs"
                  checked={publishInitialMessages}
                  onChange={(e) => setPublishInitialMessages(e.target.checked)}
                  className="w-4 h-4 accent-[#E64A4A] cursor-pointer"
                />
                <label htmlFor="initialMsgs" className="cursor-pointer">
                  Publish initial welcome & rules embed messages into #welcome and #rules
                </label>
              </div>

              {/* Destructive Replace Confirmation Phrase */}
              {mode === 'REPLACE' && (
                <div className="bg-rose-950/20 border border-rose-500/30 rounded-lg p-4 space-y-3">
                  <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs">
                    <ShieldAlert className="w-4 h-4" />
                    <span>High Risk Operation: Structure Replacement</span>
                  </div>
                  <p className="text-[11px] text-rose-300/80 leading-relaxed">
                    This will delete existing channels on <span className="font-mono text-white">{selectedGuild.name}</span>. An automated structural backup snapshot will be recorded before deletion, but chat history cannot be restored via Discord API.
                  </p>
                  <div>
                    <label className="text-[11px] text-rose-200 block mb-1">
                      Type <span className="font-mono font-bold select-all bg-rose-900/40 px-1 py-0.5 rounded">{REQUIRED_REPLACE_PHRASE}</span> to confirm:
                    </label>
                    <input
                      type="text"
                      value={confirmationPhrase}
                      onChange={(e) => setConfirmationPhrase(e.target.value)}
                      placeholder={REQUIRED_REPLACE_PHRASE}
                      className="w-full bg-[#180E0E] border border-rose-800 rounded px-3 py-1.5 text-xs text-rose-200 font-mono focus:outline-none focus:border-rose-500"
                    />
                  </div>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 rounded bg-rose-950/30 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Modal Footer Controls */}
              <div className="flex items-center justify-between pt-4 border-t border-[#1A1A1A]">
                <button
                  type="button"
                  onClick={closeDeployModal}
                  disabled={isExecuting}
                  className="px-4 py-2 text-xs text-[#9E9B95] hover:text-white transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleStartDeploy}
                  disabled={isExecuting || !isPhraseValid}
                  className={`flex items-center gap-2 text-xs font-semibold px-5 py-2 rounded transition-colors cursor-pointer ${
                    mode === 'REPLACE'
                      ? 'bg-rose-600 hover:bg-rose-500 text-white disabled:opacity-40'
                      : 'bg-[#E64A4A] hover:bg-[#F05555] text-white disabled:opacity-40'
                  }`}
                >
                  {isExecuting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Applying Changes Safely...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Execute {mode} Deployment</span>
                    </>
                  )}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
