/**
 * Settings & Integrations Management
 * Discord Bot Credentials, OAuth2 Invite Generator, Blipmade Webhooks, and Backup Center
 */

import React, { useState, useEffect } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Settings as SettingsIcon,
  Key,
  Shield,
  Radio,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Send,
  Download,
  RotateCcw,
  Copy,
  Check,
  Loader2,
} from 'lucide-react';
import {
  fetchSettings,
  updateSettings,
  testWebhookAlert,
  fetchBackups,
  restoreBackup,
  resetDemoGuild,
} from '../../api/client.ts';
import { StudioSettings, StructuralBackup } from '../../types/discord.ts';

export const SettingsTab: React.FC = () => {
  const { status, refreshStatus, refreshGuildDetails } = useStudio();

  const [settings, setSettings] = useState<StudioSettings | null>(null);
  const [botTokenInput, setBotTokenInput] = useState('');
  const [clientIdInput, setClientIdInput] = useState('');
  const [targetGuildIdInput, setTargetGuildIdInput] = useState('');
  const [statusWebhookInput, setStatusWebhookInput] = useState('');
  const [opsWebhookInput, setOpsWebhookInput] = useState('');
  const [announcementsWebhookInput, setAnnouncementsWebhookInput] = useState('');
  const [ticketsUrlInput, setTicketsUrlInput] = useState('');

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [testWebhookStatus, setTestWebhookStatus] = useState<string | null>(null);
  const [isTestingWebhook, setIsTestingWebhook] = useState(false);

  const [backups, setBackups] = useState<StructuralBackup[]>([]);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    fetchSettings().then(s => {
      setSettings(s);
      setClientIdInput(s.discordClientId || '');
      setTargetGuildIdInput(s.targetGuildId || '207468519221100544');
      setStatusWebhookInput(s.webhookStatusUrl || '');
      setOpsWebhookInput(s.webhookOpsUrl || '');
      setAnnouncementsWebhookInput(s.webhookAnnouncementsUrl || '');
      setTicketsUrlInput(s.blipmadeTicketsUrl || 'https://blipmade.com/app/tickets');
    });

    fetchBackups().then(setBackups);
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const payload: Partial<StudioSettings> = {
        discordClientId: clientIdInput.trim(),
        targetGuildId: targetGuildIdInput.trim(),
        webhookStatusUrl: statusWebhookInput.trim(),
        webhookOpsUrl: opsWebhookInput.trim(),
        webhookAnnouncementsUrl: announcementsWebhookInput.trim(),
        blipmadeTicketsUrl: ticketsUrlInput.trim(),
      };

      if (botTokenInput.trim()) {
        (payload as any).discordBotToken = botTokenInput.trim();
      }

      const updated = await updateSettings(payload);
      setSettings(updated);
      setBotTokenInput('');
      setSaveSuccess(true);
      await refreshStatus();
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      alert(`Failed to save settings: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleTestWebhook = async (target: 'status' | 'ops' | 'announcements') => {
    setIsTestingWebhook(true);
    setTestWebhookStatus(null);
    try {
      const res = await testWebhookAlert(target);
      setTestWebhookStatus(`${target.toUpperCase()}: ${res.message}`);
    } catch (err: any) {
      setTestWebhookStatus(`Error: ${err.message}`);
    } finally {
      setIsTestingWebhook(false);
    }
  };

  const handleResetDemo = async () => {
    if (confirm('Reset the simulated Demo Guild back to its original clean state?')) {
      await resetDemoGuild();
      await refreshGuildDetails();
      alert('Demo guild structure reset successfully.');
    }
  };

  const handleDownloadBackup = (b: StructuralBackup) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(b, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${b.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const botInviteUrl = settings?.discordClientId
    ? `https://discord.com/api/oauth2/authorize?client_id=${settings.discordClientId}&permissions=268435456&scope=bot%20applications.commands`
    : status?.botInviteUrl;

  return (
    <div className="max-w-4xl mx-auto py-8 px-6 space-y-8 animate-fadeIn select-none">
      {/* Header */}
      <div className="border-b border-[#1A1A1A] pb-5">
        <h2 className="text-base font-semibold text-[#F5F2EB]">
          Platform Settings & Integrations
        </h2>
        <p className="text-xs text-[#9E9B95] mt-0.5">
          Configure Discord bot authentication, Blipmade webhook dispatchers, and structural backup points.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3 rounded bg-emerald-950/20 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Settings saved successfully. Environment synchronized.</span>
        </div>
      )}

      {/* 1. Discord Developer Authentication */}
      <form onSubmit={handleSaveSettings} className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-[#181818] pb-3">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-[#E64A4A]" />
            <h3 className="text-sm font-semibold text-[#F5F2EB]">
              Discord Bot Credentials & OAuth2
            </h3>
          </div>
          <span className="text-[11px] font-mono text-[#6E6C68]">
            {status?.isLive ? 'LIVE MODE READY' : 'CURRENTLY DEMO MODE'}
          </span>
        </div>

        <div className="space-y-4 text-xs">
          <div>
            <label className="text-[#9E9B95] block mb-1">Discord Application Client ID</label>
            <input
              type="text"
              value={clientIdInput}
              onChange={(e) => setClientIdInput(e.target.value)}
              placeholder="e.g. 123456789012345678"
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#F5F2EB] font-mono focus:outline-none focus:border-[#E64A4A]"
            />
            <span className="text-[11px] text-[#6E6C68] mt-1 block">
              Found under "General Information" in the Discord Developer Portal.
            </span>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[#9E9B95]">Discord Bot Token</label>
              {settings?.hasDiscordBotToken && (
                <span className="text-[11px] font-mono text-emerald-400">
                  Configured: {settings.botTokenPrefix}
                </span>
              )}
            </div>
            <input
              type="password"
              value={botTokenInput}
              onChange={(e) => setBotTokenInput(e.target.value)}
              placeholder={settings?.hasDiscordBotToken ? '•••••••••••••••••••• (Leave blank to keep current)' : 'Paste Discord Bot Token to enable Live Mode'}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#F5F2EB] font-mono focus:outline-none focus:border-[#E64A4A]"
            />
            <span className="text-[11px] text-[#6E6C68] mt-1 block">
              Never exposed to the client bundle. Only stored securely on the Node.js server.
            </span>
          </div>

          <div>
            <label className="text-[#9E9B95] block mb-1">Target Discord Server (Guild) ID</label>
            <input
              type="text"
              value={targetGuildIdInput}
              onChange={(e) => setTargetGuildIdInput(e.target.value)}
              placeholder="e.g. 207468519221100544"
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#F5F2EB] font-mono focus:outline-none focus:border-[#E64A4A]"
            />
            <span className="text-[11px] text-[#6E6C68] mt-1 block">
              Right-click your server in Discord and select "Copy Server ID". Current default: 207468519221100544 (Blipmade).
            </span>
          </div>

          {/* Bot Invite Link */}
          {botInviteUrl && (
            <div className="bg-[#121212] border border-[#1F1F1F] rounded p-3 space-y-2">
              <span className="text-[#9E9B95] block font-medium">Bot Invite URL (Required Permissions)</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={botInviteUrl}
                  className="w-full bg-[#181818] border border-[#262626] rounded px-2.5 py-1 text-[11px] text-[#9E9B95] font-mono select-all"
                />
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(botInviteUrl);
                    setCopiedLink(true);
                    setTimeout(() => setCopiedLink(false), 2000);
                  }}
                  className="p-1.5 bg-[#1C1C1C] hover:bg-[#252525] text-white rounded cursor-pointer"
                  title="Copy invite URL"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 2. Blipmade Webhook Telemetry */}
        <div className="pt-4 border-t border-[#181818] space-y-4 text-xs">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-[#E64A4A]" />
            <h3 className="text-sm font-semibold text-[#F5F2EB]">
              Blipmade Operational Webhook Dispatchers
            </h3>
          </div>
          <p className="text-[11px] text-[#9E9B95] leading-relaxed">
            Routes existing Blipmade health scripts (`scripts/set-discord-webhook.sh`) into the designated server channels.
          </p>

          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[#9E9B95]">Public Incidents Webhook (#service-status)</label>
                <button
                  type="button"
                  onClick={() => handleTestWebhook('status')}
                  className="text-[11px] text-[#E64A4A] hover:underline cursor-pointer"
                >
                  Send Test Alert
                </button>
              </div>
              <input
                type="text"
                value={statusWebhookInput}
                onChange={(e) => setStatusWebhookInput(e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
                className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] font-mono"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[#9E9B95]">Private Ops Monitoring Webhook (#ops-alerts)</label>
                <button
                  type="button"
                  onClick={() => handleTestWebhook('ops')}
                  className="text-[11px] text-[#E64A4A] hover:underline cursor-pointer"
                >
                  Send Test Alert
                </button>
              </div>
              <input
                type="text"
                value={opsWebhookInput}
                onChange={(e) => setOpsWebhookInput(e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
                className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] font-mono"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[#9E9B95]">Announcements Webhook (#announcements)</label>
                <button
                  type="button"
                  onClick={() => handleTestWebhook('announcements')}
                  className="text-[11px] text-[#E64A4A] hover:underline cursor-pointer"
                >
                  Send Test Alert
                </button>
              </div>
              <input
                type="text"
                value={announcementsWebhookInput}
                onChange={(e) => setAnnouncementsWebhookInput(e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
                className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] font-mono"
              />
            </div>
          </div>

          {testWebhookStatus && (
            <div className="p-2.5 rounded bg-[#161616] border border-[#262626] text-xs font-mono text-[#D8D5CD]">
              {testWebhookStatus}
            </div>
          )}
        </div>

        {/* 3. Blipmade Hosting Portal Links */}
        <div className="pt-4 border-t border-[#181818] space-y-3 text-xs">
          <span className="text-sm font-semibold text-[#F5F2EB] block">
            Customer Support & Ticketing Portal
          </span>
          <p className="text-[11px] text-[#9E9B95]">
            Account disputes, invoice requests, and VPS password resets are strictly routed through authenticated tickets.
          </p>
          <div>
            <label className="text-[#9E9B95] block mb-1">Support Tickets URL</label>
            <input
              type="text"
              value={ticketsUrlInput}
              onChange={(e) => setTicketsUrlInput(e.target.value)}
              className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-1.5 text-[#F5F2EB] font-mono"
            />
          </div>
        </div>

        <div className="flex items-center justify-end pt-4 border-t border-[#181818]">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 bg-[#E64A4A] hover:bg-[#F05555] text-white text-xs font-semibold px-5 py-2 rounded transition-colors cursor-pointer"
          >
            {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
            <span>Save Settings</span>
          </button>
        </div>
      </form>

      {/* 4. Structural Backups & Demo Environment Control */}
      <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-[#181818] pb-3">
          <h3 className="text-sm font-semibold text-[#F5F2EB]">
            Structural Backups & Simulation Controls
          </h3>
          <button
            onClick={handleResetDemo}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Guild State</span>
          </button>
        </div>

        <div className="space-y-2">
          {backups.length === 0 ? (
            <p className="text-xs text-[#6E6C68] py-2">
              No automatic backup snapshots generated yet. Backups are created automatically before any destructive or sync operation.
            </p>
          ) : (
            <div className="divide-y divide-[#171717] text-xs">
              {backups.map(b => (
                <div key={b.id} className="py-2.5 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="font-semibold text-[#F5F2EB] font-mono">{b.id}</span>
                    <span className="text-[#6E6C68] block text-[11px]">{b.reason}</span>
                  </div>
                  <button
                    onClick={() => handleDownloadBackup(b)}
                    className="p-1.5 text-[#9E9B95] hover:text-[#F5F2EB] cursor-pointer flex items-center gap-1 text-[11px]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download JSON</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
