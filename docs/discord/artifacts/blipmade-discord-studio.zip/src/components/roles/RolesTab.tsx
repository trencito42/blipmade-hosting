/**
 * Roles & Permissions Management Studio
 * Role hierarchy ordering, permissions matrix, color assignment, and safety validation
 */

import React, { useState } from 'react';
import { useStudio } from '../../context/StudioContext.tsx';
import {
  Shield,
  Plus,
  Trash2,
  Lock,
  Check,
  AlertTriangle,
  MoveUp,
  MoveDown,
  Info,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { RoleTemplate } from '../../types/discord.ts';
import { Permissions, decomposePermissions, combinePermissions } from '../../../server/discord/permissions.ts';

const BLIPMADE_COLOR_PRESETS = [
  { label: 'Blipmade Crimson', value: 0xE64A4A },
  { label: 'Admin Coral', value: 0xFF7676 },
  { label: 'Support Blue', value: 0x3B82F6 },
  { label: 'Verified Emerald', value: 0x10B981 },
  { label: 'Amber Ops', value: 0xF59E0B },
  { label: 'Violet Bot', value: 0x8B5CF6 },
  { label: 'Community Muted', value: 0x9E9B95 },
  { label: 'Default Gray', value: 0x6E6C68 },
];

const PERMISSION_GROUPS: {
  category: string;
  items: { key: keyof typeof Permissions; label: string; desc: string; danger?: boolean }[];
}[] = [
  {
    category: 'General Server Management',
    items: [
      { key: 'ADMINISTRATOR', label: 'Administrator', desc: 'Bypasses all channel permissions. Grant ONLY to server executives.', danger: true },
      { key: 'MANAGE_GUILD', label: 'Manage Server', desc: 'Allows modifying server name, region, and integration settings.', danger: true },
      { key: 'MANAGE_ROLES', label: 'Manage Roles', desc: 'Create and edit roles lower than this role.', danger: true },
      { key: 'MANAGE_CHANNELS', label: 'Manage Channels', desc: 'Create, edit, or delete categories and channels.', danger: true },
      { key: 'VIEW_AUDIT_LOG', label: 'View Audit Log', desc: 'Inspect administrative actions and moderation traces.' },
    ],
  },
  {
    category: 'Membership & Moderation',
    items: [
      { key: 'KICK_MEMBERS', label: 'Kick Members', desc: 'Remove members from server.' },
      { key: 'BAN_MEMBERS', label: 'Ban Members', desc: 'Permanently ban malicious actors from server.' },
      { key: 'MANAGE_MESSAGES', label: 'Manage Messages', desc: 'Delete spam or pin important technical announcements.' },
      { key: 'MUTE_MEMBERS', label: 'Mute Members', desc: 'Mute members in voice channels.' },
      { key: 'PRIORITY_SPEAKER', label: 'Priority Speaker', desc: 'Allows staff to be heard louder in community voice calls.' },
    ],
  },
  {
    category: 'Text & Media Permissions',
    items: [
      { key: 'VIEW_CHANNEL', label: 'View Channels', desc: 'Allows members to see public channels by default.' },
      { key: 'SEND_MESSAGES', label: 'Send Messages', desc: 'Post text messages and replies.' },
      { key: 'EMBED_LINKS', label: 'Embed Links', desc: 'Allows posting URLs that render rich previews.' },
      { key: 'ATTACH_FILES', label: 'Attach Files', desc: 'Upload screenshots, server configs, and crash logs.' },
      { key: 'READ_MESSAGE_HISTORY', label: 'Read History', desc: 'Read previously sent messages.' },
      { key: 'MENTION_EVERYONE', label: 'Mention @everyone', desc: 'Pings every member. Restricted to staff.', danger: true },
      { key: 'USE_EXTERNAL_EMOJIS', label: 'Use External Emojis', desc: 'Use custom emotes from other servers.' },
    ],
  },
];

export const RolesTab: React.FC = () => {
  const {
    activeTemplate,
    selectedRoleName,
    setSelectedRoleName,
    addRole,
    updateRole,
    deleteRole,
  } = useStudio();

  const [isAddRoleOpen, setIsAddRoleOpen] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleColor, setNewRoleColor] = useState(0x9E9B95);

  const selectedRole = activeTemplate.roles.find(
    r => r.name.toLowerCase() === selectedRoleName?.toLowerCase()
  ) || activeTemplate.roles[0];

  const activePermissions = selectedRole ? decomposePermissions(selectedRole.permissions) : [];

  const handleTogglePermission = (key: keyof typeof Permissions) => {
    if (!selectedRole) return;
    const current = new Set(activePermissions);
    if (current.has(key)) {
      current.delete(key);
    } else {
      current.add(key);
    }
    const newBitfield = combinePermissions(Array.from(current));
    updateRole(selectedRole.name, { permissions: newBitfield });
  };

  const handleCreateRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoleName.trim()) return;
    const role: RoleTemplate = {
      name: newRoleName.trim(),
      color: newRoleColor,
      hoist: true,
      mentionable: false,
      permissions: '369664',
    };
    addRole(role);
    setNewRoleName('');
    setIsAddRoleOpen(false);
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-6 space-y-8 animate-fadeIn select-none">
      {/* Tab Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-5">
        <div>
          <h2 className="text-base font-semibold text-[#F5F2EB]">
            Roles & Permissions Architecture
          </h2>
          <p className="text-xs text-[#9E9B95] mt-0.5">
            Configure access tiers, visual hoist separation, and Discord permission matrices.
          </p>
        </div>

        <button
          onClick={() => setIsAddRoleOpen(true)}
          className="flex items-center gap-2 bg-[#E64A4A] hover:bg-[#F05555] text-white text-xs font-medium px-3.5 py-1.5 rounded transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create Proposed Role</span>
        </button>
      </div>

      {/* Role Hierarchy Notice */}
      <div className="bg-[#121212] border border-[#222222] rounded-lg p-4 flex items-start gap-3">
        <Info className="w-4 h-4 text-[#E64A4A] shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <p className="text-[#F5F2EB] font-medium">Discord Role Hierarchy Safety Rule</p>
          <p className="text-[#9E9B95] leading-relaxed">
            The bot cannot modify or assign roles that sit higher than its own integrated role in the Discord server settings. The <span className="font-mono text-[#F5F2EB]">Owner</span> role here is an executive badge and never transfers native server ownership.
          </p>
        </div>
      </div>

      {/* 2-Column Layout: Role List & Permission Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Roles List */}
        <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#181818]">
            <span className="text-xs font-semibold text-[#F5F2EB] uppercase tracking-wider">
              Hierarchy Order
            </span>
            <span className="text-[11px] text-[#6E6C68] font-mono">
              Top to Bottom
            </span>
          </div>

          <div className="space-y-1">
            {activeTemplate.roles.map((role, idx) => {
              const isSelected = selectedRole?.name.toLowerCase() === role.name.toLowerCase();
              const hexColor = `#${role.color.toString(16).padStart(6, '0')}`;

              return (
                <div
                  key={role.name}
                  onClick={() => setSelectedRoleName(role.name)}
                  className={`flex items-center justify-between p-2.5 rounded cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-[#1C1C1C] text-[#F5F2EB] border border-[#2E2E2E]'
                      : 'hover:bg-[#141414] text-[#9E9B95] border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: hexColor }}
                    />
                    <span className="text-xs font-semibold">{role.name}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {role.hoist && (
                      <span className="text-[10px] font-mono text-[#6E6C68] bg-[#141414] px-1.5 py-0.5 rounded">
                        HOIST
                      </span>
                    )}
                    {role.name !== 'Owner' && role.name !== 'Administrator' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Remove role @${role.name} from draft?`)) {
                            deleteRole(role.name);
                          }
                        }}
                        className="text-[#555555] hover:text-[#E64A4A] p-0.5"
                        title="Delete role"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Role Settings & Permission Matrix */}
        {selectedRole && (
          <div className="lg:col-span-2 bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg p-6 space-y-6">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-5">
              <div className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs shrink-0"
                  style={{ backgroundColor: `#${selectedRole.color.toString(16).padStart(6, '0')}` }}
                >
                  @
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-[#F5F2EB]">
                    Role: @{selectedRole.name}
                  </h3>
                  <p className="text-xs text-[#9E9B95]">
                    {selectedRole.description || 'Configured community or staff role.'}
                  </p>
                </div>
              </div>

              {/* Hoist & Mentionable Toggles */}
              <div className="flex items-center gap-4 text-xs">
                <label className="flex items-center gap-1.5 cursor-pointer text-[#9E9B95] hover:text-[#F5F2EB]">
                  <input
                    type="checkbox"
                    checked={selectedRole.hoist}
                    onChange={(e) => updateRole(selectedRole.name, { hoist: e.target.checked })}
                    className="accent-[#E64A4A] cursor-pointer"
                  />
                  <span>Display Separately (Hoist)</span>
                </label>

                <label className="flex items-center gap-1.5 cursor-pointer text-[#9E9B95] hover:text-[#F5F2EB]">
                  <input
                    type="checkbox"
                    checked={selectedRole.mentionable}
                    onChange={(e) => updateRole(selectedRole.name, { mentionable: e.target.checked })}
                    className="accent-[#E64A4A] cursor-pointer"
                  />
                  <span>Mentionable</span>
                </label>
              </div>
            </div>

            {/* Color Palette Presets */}
            <div>
              <label className="text-xs text-[#9E9B95] block mb-2 font-medium">
                Role Color Preset
              </label>
              <div className="flex flex-wrap items-center gap-2">
                {BLIPMADE_COLOR_PRESETS.map(preset => (
                  <button
                    key={preset.label}
                    onClick={() => updateRole(selectedRole.name, { color: preset.value })}
                    className={`flex items-center gap-2 px-2.5 py-1 rounded text-xs border transition-colors cursor-pointer ${
                      selectedRole.color === preset.value
                        ? 'border-white bg-[#1C1C1C] text-white font-medium'
                        : 'border-[#262626] bg-[#141414] text-[#9E9B95] hover:border-[#383838]'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: `#${preset.value.toString(16).padStart(6, '0')}` }}
                    />
                    <span>{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Permission Matrix */}
            <div className="space-y-6 pt-2">
              {PERMISSION_GROUPS.map(group => (
                <div key={group.category} className="space-y-3">
                  <h4 className="text-xs font-semibold text-[#F5F2EB] tracking-wide uppercase">
                    {group.category}
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {group.items.map(perm => {
                      const isGranted = activePermissions.includes(perm.key);
                      return (
                        <div
                          key={perm.key}
                          onClick={() => handleTogglePermission(perm.key)}
                          className={`p-3 rounded border flex items-center justify-between cursor-pointer transition-colors ${
                            isGranted
                              ? perm.danger
                                ? 'bg-rose-950/20 border-rose-500/40 text-rose-200'
                                : 'bg-[#151515] border-[#2A2A2A] text-[#F5F2EB]'
                              : 'bg-[#0F0F0F] border-[#1A1A1A] text-[#6E6C68] hover:border-[#262626]'
                          }`}
                        >
                          <div className="space-y-0.5 pr-4">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-semibold">{perm.label}</span>
                              {perm.danger && (
                                <span className="text-[10px] font-mono text-rose-400 bg-rose-500/10 px-1 rounded">
                                  DANGER
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#9E9B95] leading-snug">
                              {perm.desc}
                            </p>
                          </div>

                          <div
                            className={`w-5 h-5 rounded flex items-center justify-center shrink-0 border ${
                              isGranted
                                ? 'bg-[#E64A4A] border-[#E64A4A] text-white'
                                : 'border-[#333333] bg-[#141414]'
                            }`}
                          >
                            {isGranted && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Create Role Modal */}
      {isAddRoleOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <form
            onSubmit={handleCreateRole}
            className="bg-[#0F0F0F] border border-[#222222] rounded-lg p-5 w-full max-w-sm space-y-4 shadow-xl"
          >
            <h3 className="text-sm font-semibold text-[#F5F2EB]">Create Proposed Role</h3>
            <div>
              <label className="text-xs text-[#9E9B95] block mb-1">Role Name</label>
              <input
                type="text"
                value={newRoleName}
                onChange={(e) => setNewRoleName(e.target.value)}
                placeholder="e.g. Beta Tester"
                autoFocus
                className="w-full bg-[#161616] border border-[#2A2A2A] rounded px-3 py-1.5 text-xs text-[#F5F2EB] focus:outline-none focus:border-[#E64A4A]"
              />
            </div>
            <div>
              <label className="text-xs text-[#9E9B95] block mb-1">Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={`#${newRoleColor.toString(16).padStart(6, '0')}`}
                  onChange={(e) => setNewRoleColor(parseInt(e.target.value.replace('#', ''), 16))}
                  className="w-8 h-8 rounded bg-transparent border border-[#2A2A2A] cursor-pointer"
                />
                <span className="text-xs font-mono text-[#F5F2EB]">
                  #{newRoleColor.toString(16).padStart(6, '0').toUpperCase()}
                </span>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddRoleOpen(false)}
                className="px-3 py-1.5 text-xs text-[#9E9B95] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!newRoleName.trim()}
                className="px-3 py-1.5 text-xs bg-[#E64A4A] hover:bg-[#F05555] text-white rounded font-medium disabled:opacity-50 cursor-pointer"
              >
                Create Role
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
