/**
 * Activity & Audit Log Section
 * Complete traceability of Discord server installations, syncs, and rollbacks
 */

import React, { useState, useEffect } from 'react';
import { fetchActivityRuns } from '../../api/client.ts';
import { AuditRun } from '../../types/discord.ts';
import {
  Activity as ActivityIcon,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Download,
  Filter,
  RefreshCw,
  Eye,
  FileCode,
} from 'lucide-react';

export const ActivityTab: React.FC = () => {
  const [runs, setRuns] = useState<AuditRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'SUCCESS' | 'PARTIAL' | 'FAILED'>('ALL');
  const [selectedRun, setSelectedRun] = useState<AuditRun | null>(null);

  const loadRuns = () => {
    setLoading(true);
    fetchActivityRuns()
      .then(data => setRuns(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadRuns();
  }, []);

  const filteredRuns = runs.filter(r => {
    if (statusFilter === 'ALL') return true;
    return r.status === statusFilter;
  });

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(runs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `blipmade-audit-log-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-6 space-y-8 animate-fadeIn select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1A1A1A] pb-5">
        <div>
          <h2 className="text-base font-semibold text-[#F5F2EB]">
            Reconciliation Activity & Audit History
          </h2>
          <p className="text-xs text-[#9E9B95] mt-0.5">
            Immutable log of all MERGE, SYNC, and REPLACE installations executed against Discord.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadRuns}
            className="p-2 text-[#9E9B95] hover:text-[#F5F2EB] hover:bg-[#141414] rounded border border-[#222222] cursor-pointer"
            title="Refresh logs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleExportJson}
            className="flex items-center gap-2 bg-[#141414] hover:bg-[#1E1E1E] text-[#F5F2EB] border border-[#222222] text-xs font-medium px-3.5 py-1.5 rounded transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#9E9B95]" />
            <span>Export Audit Log</span>
          </button>
        </div>
      </div>

      {/* Filter Strip */}
      <div className="flex items-center gap-2 text-xs">
        <Filter className="w-3.5 h-3.5 text-[#6E6C68]" />
        <span className="text-[#6E6C68]">Filter Status:</span>
        {(['ALL', 'SUCCESS', 'PARTIAL', 'FAILED'] as const).map(filter => (
          <button
            key={filter}
            onClick={() => setStatusFilter(filter)}
            className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
              statusFilter === filter
                ? 'bg-[#1C1C1C] text-[#F5F2EB] font-semibold border border-[#2E2E2E]'
                : 'text-[#9E9B95] hover:text-[#F5F2EB]'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Activity Table */}
      <div className="bg-[#0D0D0D] border border-[#1F1F1F] rounded-lg overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-xs text-[#9E9B95]">
            Loading audit runs...
          </div>
        ) : filteredRuns.length === 0 ? (
          <div className="p-12 text-center text-[#6E6C68] space-y-2">
            <ActivityIcon className="w-8 h-8 mx-auto stroke-[1.2]" />
            <p className="text-xs">No reconciliation runs recorded yet.</p>
            <p className="text-[11px] text-[#555555]">
              Deploy a template from the visual builder to generate execution traces.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[#171717] text-xs">
            {filteredRuns.map(run => (
              <div
                key={run.id}
                onClick={() => setSelectedRun(run)}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-[#121212] transition-colors cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {run.status === 'SUCCESS' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : run.status === 'PARTIAL' ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400" />
                    )}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 font-mono">
                      <span className="font-bold text-[#F5F2EB]">{run.mode}</span>
                      <span className="text-[#555555]">·</span>
                      <span className="text-[#9E9B95]">{run.guildName}</span>
                      {run.isDemo && (
                        <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 rounded">
                          DEMO
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-[#6E6C68] font-mono">
                      + {run.summary.channelsCreated} channels, + {run.summary.rolesCreated} roles, {run.summary.overwritesApplied} overwrites applied
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-right">
                  <span className="text-[11px] text-[#6E6C68] font-mono">
                    {new Date(run.timestamp).toLocaleString()}
                  </span>
                  <Eye className="w-3.5 h-3.5 text-[#555555]" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Run Detail Modal */}
      {selectedRun && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#0F0F0F] border border-[#222222] rounded-lg p-6 w-full max-w-2xl max-h-[85vh] flex flex-col space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-[#1A1A1A] pb-3">
              <div>
                <h3 className="text-sm font-semibold text-[#F5F2EB]">
                  Execution Audit Trace: {selectedRun.id}
                </h3>
                <span className="text-xs text-[#6E6C68] font-mono">
                  {selectedRun.mode} on {selectedRun.guildName} at {new Date(selectedRun.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <button
                onClick={() => setSelectedRun(null)}
                className="text-[#9E9B95] hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 font-mono text-xs max-h-96 pr-2">
              {selectedRun.details.map((d, i) => (
                <div
                  key={i}
                  className="bg-[#141414] border border-[#1E1E1E] rounded p-2.5 flex items-center justify-between text-[11px]"
                >
                  <div className="space-y-0.5">
                    <span className="font-semibold text-[#F5F2EB]">{d.target}</span>
                    {d.message && (
                      <p className="text-[#6E6C68] text-[10px]">{d.message}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <span
                      className={`font-bold ${
                        d.status === 'SUCCESS' ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {d.status}
                    </span>
                    <span className="text-[#555555] block text-[10px]">{d.action}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end pt-3 border-t border-[#1A1A1A]">
              <button
                onClick={() => setSelectedRun(null)}
                className="px-4 py-1.5 text-xs bg-[#1C1C1C] hover:bg-[#262626] text-white rounded cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
