/**
 * Shared Type Definitions for Blipmade Discord Studio
 */

export interface RoleTemplate {
  name: string;
  color: number;
  hoist: boolean;
  mentionable: boolean;
  permissions: string;
  isCustom?: boolean;
  description?: string;
}

export interface OverwriteTemplate {
  roleName: string;
  allow: string;
  deny: string;
}

export interface ChannelTemplate {
  id?: string;
  name: string;
  type: number; // 0 = text, 2 = voice, 4 = category, 5 = announcement, 15 = forum
  topic?: string;
  categoryName?: string;
  position: number;
  nsfw?: boolean;
  rateLimitPerUser?: number;
  permissionOverwrites?: OverwriteTemplate[];
  initialMessage?: {
    content?: string;
    embeds?: Array<{
      title: string;
      description: string;
      color: number;
      fields?: Array<{ name: string; value: string; inline?: boolean }>;
      footer?: { text: string };
    }>;
  };
}

export interface ServerTemplate {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  roles: RoleTemplate[];
  categories: ChannelTemplate[];
  channels: ChannelTemplate[];
}

export interface GuildItem {
  id: string;
  name: string;
  icon: string | null;
  isDemo: boolean;
  channelsCount?: number;
  rolesCount?: number;
}

export interface DiscordRole {
  id: string;
  name: string;
  color: number;
  hoist: boolean;
  position: number;
  permissions: string;
  managed?: boolean;
  mentionable?: boolean;
}

export interface DiscordChannel {
  id: string;
  name: string;
  type: number;
  position: number;
  topic?: string | null;
  parent_id?: string | null;
  rate_limit_per_user?: number;
  permission_overwrites?: Array<{
    id: string;
    type: number;
    allow: string;
    deny: string;
  }>;
}

export interface GuildDetails {
  id: string;
  name: string;
  icon: string | null;
  isDemo: boolean;
  roles: DiscordRole[];
  channels: DiscordChannel[];
}

export interface DiffItem<T> {
  item: T;
  reason?: string;
}

export interface ServerDiff {
  guildId: string;
  guildName: string;
  targetTemplateId: string;
  targetTemplateName: string;
  roles: {
    toCreate: DiffItem<RoleTemplate>[];
    toUpdate: DiffItem<{ existing: DiscordRole; proposed: RoleTemplate }>[];
    unchanged: DiscordRole[];
    toDelete: DiscordRole[];
  };
  categories: {
    toCreate: DiffItem<ChannelTemplate>[];
    toUpdate: DiffItem<{ existing: DiscordChannel; proposed: ChannelTemplate }>[];
    unchanged: DiscordChannel[];
    toDelete: DiscordChannel[];
  };
  channels: {
    toCreate: DiffItem<ChannelTemplate>[];
    toUpdate: DiffItem<{ existing: DiscordChannel; proposed: ChannelTemplate }>[];
    unchanged: DiscordChannel[];
    toDelete: DiscordChannel[];
  };
  totalChanges: number;
}

export interface AuditRun {
  id: string;
  timestamp: string;
  mode: 'MERGE' | 'SYNC' | 'REPLACE';
  guildId: string;
  guildName: string;
  isDemo: boolean;
  status: 'SUCCESS' | 'PARTIAL' | 'FAILED' | 'DRY_RUN';
  summary: {
    rolesCreated: number;
    rolesUpdated: number;
    rolesDeleted: number;
    categoriesCreated: number;
    categoriesUpdated: number;
    categoriesDeleted: number;
    channelsCreated: number;
    channelsUpdated: number;
    channelsDeleted: number;
    overwritesApplied: number;
  };
  details: Array<{
    target: string;
    action: string;
    status: 'SUCCESS' | 'FAILED' | 'SKIPPED';
    message?: string;
  }>;
}

export interface StructuralBackup {
  id: string;
  timestamp: string;
  guildId: string;
  guildName: string;
  reason: string;
  data: {
    roles: Array<{ id: string; name: string; color: number; position: number; permissions: string }>;
    channels: Array<{ id: string; name: string; type: number; position: number; topic?: string; parentId?: string }>;
  };
}

export interface StudioStatus {
  mode: 'LIVE' | 'DEMO';
  isLive: boolean;
  botUser: { id: string; username: string; avatar: string | null } | null;
  botError: string | null;
  botInviteUrl: string | null;
  requiredPermissionsBitfield: string;
  integrations: {
    hasStatusWebhook: boolean;
    hasOpsWebhook: boolean;
    hasAnnouncementsWebhook: boolean;
  };
  links: {
    tickets: string;
    docs: string;
    status: string;
  };
}

export interface StudioSettings {
  discordClientId: string;
  hasDiscordBotToken: boolean;
  botTokenPrefix: string;
  discordRedirectUri: string;
  targetGuildId?: string;
  webhookStatusUrl: string;
  webhookOpsUrl: string;
  webhookAnnouncementsUrl: string;
  blipmadeTicketsUrl: string;
  blipmadeDocsUrl: string;
  blipmadeStatusUrl: string;
  isLiveModeEnabled: boolean;
}
