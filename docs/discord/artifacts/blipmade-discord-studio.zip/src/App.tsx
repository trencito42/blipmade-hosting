/**
 * Blipmade Discord Studio - Main Application Entry
 * Visual Discord server architect, template manager, and deployment studio.
 */

import React from 'react';
import { StudioProvider, useStudio } from './context/StudioContext.tsx';
import { Navbar } from './components/layout/Navbar.tsx';
import { OverviewTab } from './components/overview/OverviewTab.tsx';
import { ServerBuilderTab } from './components/builder/ServerBuilderTab.tsx';
import { TemplatesTab } from './components/templates/TemplatesTab.tsx';
import { RolesTab } from './components/roles/RolesTab.tsx';
import { MessagesTab } from './components/messages/MessagesTab.tsx';
import { ActivityTab } from './components/activity/ActivityTab.tsx';
import { SettingsTab } from './components/settings/SettingsTab.tsx';
import { DeployModal } from './components/deploy/DeployModal.tsx';

const AppContent: React.FC = () => {
  const { activeTab } = useStudio();

  return (
    <div className="min-h-screen flex flex-col bg-[#060606] text-[#F5F2EB] font-sans antialiased">
      {/* Universal Top Bar */}
      <Navbar />

      {/* Main Viewport */}
      <main className="flex-1 flex flex-col overflow-y-auto">
        {activeTab === 'overview' && <OverviewTab />}
        {activeTab === 'builder' && <ServerBuilderTab />}
        {activeTab === 'templates' && <TemplatesTab />}
        {activeTab === 'roles' && <RolesTab />}
        {activeTab === 'messages' && <MessagesTab />}
        {activeTab === 'activity' && <ActivityTab />}
        {activeTab === 'settings' && <SettingsTab />}
      </main>

      {/* Global Deploy & Reconciliation Modal */}
      <DeployModal />

      {/* Subtle Developer Infrastructure Footer (except on full-screen visual builder) */}
      {activeTab !== 'builder' && (
        <footer className="border-t border-[#141414] py-4 px-6 text-xs text-[#6E6C68] flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#080808]">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#9E9B95]">Blipmade Discord Studio</span>
            <span>·</span>
            <span>Official Hosting Community Architecture</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <a href="https://blipmade.com" target="_blank" rel="noreferrer" className="hover:text-[#F5F2EB] transition-colors">
              blipmade.com
            </a>
            <a href="https://blipmade.com/docs" target="_blank" rel="noreferrer" className="hover:text-[#F5F2EB] transition-colors">
              Docs
            </a>
            <a href="https://blipmade.com/status" target="_blank" rel="noreferrer" className="hover:text-[#F5F2EB] transition-colors">
              Platform Status
            </a>
            <a href="https://blipmade.com/app/tickets" target="_blank" rel="noreferrer" className="hover:text-[#F5F2EB] transition-colors">
              Support Tickets
            </a>
          </div>
        </footer>
      )}
    </div>
  );
};

export default function App() {
  return (
    <StudioProvider>
      <AppContent />
    </StudioProvider>
  );
}
