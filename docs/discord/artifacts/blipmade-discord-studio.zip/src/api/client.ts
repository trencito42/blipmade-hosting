/**
 * Type-safe API Client for Blipmade Discord Studio Backend
 */

import {
  StudioStatus,
  GuildItem,
  GuildDetails,
  ServerTemplate,
  ServerDiff,
  AuditRun,
  StructuralBackup,
  StudioSettings,
} from '../types/discord.ts';

const API_BASE = '/api';

export async function fetchStudioStatus(): Promise<StudioStatus> {
  const res = await fetch(`${API_BASE}/status`);
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch studio status`);
  return res.json();
}

export async function fetchGuilds(): Promise<GuildItem[]> {
  const res = await fetch(`${API_BASE}/guilds`);
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch guilds`);
  return res.json();
}

export async function fetchGuildDetails(guildId: string): Promise<GuildDetails> {
  const res = await fetch(`${API_BASE}/guilds/${guildId}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to fetch guild details`);
  }
  return res.json();
}

export async function fetchTemplates(): Promise<ServerTemplate[]> {
  const res = await fetch(`${API_BASE}/templates`);
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch templates`);
  return res.json();
}

export async function saveTemplate(template: ServerTemplate): Promise<ServerTemplate> {
  const res = await fetch(`${API_BASE}/templates`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(template),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to save template`);
  }
  return res.json();
}

export async function deleteTemplate(templateId: string): Promise<void> {
  const res = await fetch(`${API_BASE}/templates/${templateId}`, {
    method: 'DELETE',
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to delete template`);
  }
}

export async function calculateDiff(payload: {
  guildId: string;
  templateId?: string;
  customTemplate?: ServerTemplate;
}): Promise<ServerDiff> {
  const res = await fetch(`${API_BASE}/diff`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to calculate diff`);
  }
  return res.json();
}

export async function executeDeploy(payload: {
  guildId: string;
  guildName?: string;
  mode: 'MERGE' | 'SYNC' | 'REPLACE';
  templateId?: string;
  customTemplate?: ServerTemplate;
  confirmationPhrase?: string;
  publishInitialMessages?: boolean;
}): Promise<AuditRun> {
  const res = await fetch(`${API_BASE}/deploy`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Deployment failed`);
  }
  return res.json();
}

export async function fetchBackups(guildId?: string): Promise<StructuralBackup[]> {
  const url = guildId ? `${API_BASE}/backups?guildId=${guildId}` : `${API_BASE}/backups`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch backups`);
  return res.json();
}

export async function restoreBackup(backupId: string): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${API_BASE}/backups/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ backupId }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to restore backup`);
  }
  return res.json();
}

export async function fetchActivityRuns(): Promise<AuditRun[]> {
  const res = await fetch(`${API_BASE}/activity`);
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch activity history`);
  return res.json();
}

export async function publishMessage(payload: {
  channelId: string;
  guildId?: string;
  message: {
    content?: string;
    embeds?: any[];
  };
}): Promise<{ success: boolean; id: string }> {
  const res = await fetch(`${API_BASE}/messages/publish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to publish message`);
  }
  return res.json();
}

export async function testWebhookAlert(target: 'status' | 'ops' | 'announcements'): Promise<{
  success: boolean;
  simulated: boolean;
  message: string;
  payload?: any;
}> {
  const res = await fetch(`${API_BASE}/integrations/test-webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Webhook test failed`);
  }
  return res.json();
}

export async function fetchSettings(): Promise<StudioSettings> {
  const res = await fetch(`${API_BASE}/settings`);
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to fetch settings`);
  return res.json();
}

export async function updateSettings(settings: Partial<StudioSettings>): Promise<StudioSettings> {
  const res = await fetch(`${API_BASE}/settings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}: Failed to update settings`);
  }
  return res.json();
}

export async function resetDemoGuild(): Promise<GuildDetails> {
  const res = await fetch(`${API_BASE}/demo/reset`, { method: 'POST' });
  if (!res.ok) throw new Error(`HTTP ${res.status}: Failed to reset demo guild`);
  return res.json();
}
