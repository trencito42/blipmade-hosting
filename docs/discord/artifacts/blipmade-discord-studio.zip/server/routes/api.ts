/**
 * Express REST API Routes for Blipmade Discord Studio
 */

import express from 'express';
import type { Request, Response } from 'express';
import { z } from 'zod';
import { db } from '../store/db.ts';
import type { StructuralBackup } from '../store/db.ts';
import { DiscordRestClient } from '../discord/api.ts';
import { TemplateReconciler } from '../discord/reconciler.ts';
import { BLIPMADE_OFFICIAL_TEMPLATE } from '../templates/blipmadeDefault.ts';
import type { ServerTemplate } from '../templates/blipmadeDefault.ts';
import { REQUIRED_BOT_PERMISSIONS, getBotInviteUrl } from '../discord/permissions.ts';

export const apiRouter = express.Router();

// Helper to get Discord client if token configured
function getDiscordClient(): DiscordRestClient | null {
  const settings = db.getSettings();
  if (settings.discordBotToken && settings.discordBotToken.trim().length > 10) {
    return new DiscordRestClient(settings.discordBotToken.trim());
  }
  return null;
}

// 1. Studio Status & Health
apiRouter.get('/status', async (req: Request, res: Response) => {
  const settings = db.getSettings();
  const client = getDiscordClient();
  let botUser = null;
  let botError = null;

  if (client) {
    try {
      botUser = await client.getBotUser();
    } catch (err: any) {
      botError = err.message || 'Failed to authenticate bot token with Discord';
    }
  }

  const isLive = Boolean(client && botUser);

  res.json({
    mode: isLive ? 'LIVE' : 'DEMO',
    isLive,
    botUser: botUser ? { id: botUser.id, username: botUser.username, avatar: botUser.avatar } : null,
    botError,
    botInviteUrl: settings.discordClientId ? getBotInviteUrl(settings.discordClientId) : null,
    requiredPermissionsBitfield: REQUIRED_BOT_PERMISSIONS,
    integrations: {
      hasStatusWebhook: Boolean(settings.webhookStatusUrl),
      hasOpsWebhook: Boolean(settings.webhookOpsUrl),
      hasAnnouncementsWebhook: Boolean(settings.webhookAnnouncementsUrl),
    },
    links: {
      tickets: settings.blipmadeTicketsUrl,
      docs: settings.blipmadeDocsUrl,
      status: settings.blipmadeStatusUrl,
    },
  });
});

// 2. Guilds list
apiRouter.get('/guilds', async (req: Request, res: Response) => {
  const client = getDiscordClient();
  const demoGuild = db.getDemoGuild();
  const settings = db.getSettings();

  const guildsList: any[] = [];

  // If live mode is configured, discover bot guilds from Discord API
  if (client) {
    try {
      const botGuilds = await client.getBotGuilds();
      for (const bg of botGuilds) {
        guildsList.push({
          id: bg.id,
          name: bg.name,
          icon: bg.icon,
          isDemo: false,
          channelsCount: 0,
          rolesCount: 0,
        });
      }
    } catch (err) {
      console.warn('Failed to fetch bot guilds list:', err);
    }

    // Also check explicit target guild ID if not already discovered
    const targetGuildId = settings.targetGuildId || process.env.BLIPMADE_TARGET_GUILD_ID;
    if (targetGuildId && !guildsList.some(g => g.id === targetGuildId)) {
      try {
        const liveGuild = await client.getGuild(targetGuildId);
        guildsList.unshift({
          id: liveGuild.id,
          name: liveGuild.name,
          icon: liveGuild.icon,
          isDemo: false,
          channelsCount: 0,
          rolesCount: liveGuild.roles?.length || 0,
        });
      } catch (err) {
        console.warn(`Failed to fetch target guild ${targetGuildId}:`, err);
      }
    }
  }

  // Always keep Demo Guild available as a safe testing sandbox
  guildsList.push({
    id: demoGuild.id,
    name: demoGuild.name,
    icon: demoGuild.icon,
    isDemo: true,
    channelsCount: demoGuild.channels.length,
    rolesCount: demoGuild.roles.length,
  });

  res.json(guildsList);
});

// 3. Guild details & structure
apiRouter.get('/guilds/:guildId', async (req: Request, res: Response) => {
  const { guildId } = req.params;
  const isDemo = guildId.startsWith('demo-') || guildId === 'demo-guild-blipmade-001';

  if (isDemo) {
    const demo = db.getDemoGuild();
    return res.json({
      id: demo.id,
      name: demo.name,
      icon: demo.icon,
      isDemo: true,
      roles: demo.roles,
      channels: demo.channels,
    });
  }

  const client = getDiscordClient();
  if (!client) {
    return res.status(400).json({ error: 'Live Discord bot token is not configured. Use Demo Guild instead.' });
  }

  try {
    const [guild, channels, roles] = await Promise.all([
      client.getGuild(guildId),
      client.getGuildChannels(guildId),
      client.getGuildRoles(guildId),
    ]);

    res.json({
      id: guild.id,
      name: guild.name,
      icon: guild.icon,
      isDemo: false,
      roles,
      channels,
    });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to load guild ${guildId}: ${err.message}` });
  }
});

// 4. Templates
apiRouter.get('/templates', (req: Request, res: Response) => {
  res.json(db.getTemplates());
});

apiRouter.get('/templates/:templateId', (req: Request, res: Response) => {
  const template = db.getTemplateById(req.params.templateId);
  if (!template) {
    return res.status(404).json({ error: 'Template not found' });
  }
  res.json(template);
});

apiRouter.post('/templates', (req: Request, res: Response) => {
  try {
    const templateData = req.body as ServerTemplate;
    if (!templateData.name || !templateData.channels || !templateData.roles) {
      return res.status(400).json({ error: 'Invalid template structure' });
    }

    if (!templateData.id) {
      templateData.id = `template-custom-${Date.now()}`;
    }
    if (!templateData.version) {
      templateData.version = '1.0.0';
    }

    const saved = db.saveTemplate(templateData);
    res.json(saved);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

apiRouter.delete('/templates/:templateId', (req: Request, res: Response) => {
  const deleted = db.deleteTemplate(req.params.templateId);
  if (!deleted) {
    return res.status(400).json({ error: 'Cannot delete protected official template or template not found' });
  }
  res.json({ success: true });
});

// 5. Diff Calculation
apiRouter.post('/diff', async (req: Request, res: Response) => {
  const { guildId, templateId, customTemplate } = req.body;
  const isDemo = !guildId || guildId.startsWith('demo-') || guildId === 'demo-guild-blipmade-001';

  let template: ServerTemplate | undefined = customTemplate;
  if (!template && templateId) {
    template = db.getTemplateById(templateId);
  }
  if (!template) {
    template = BLIPMADE_OFFICIAL_TEMPLATE;
  }

  let roles: any[] = [];
  let channels: any[] = [];
  let guildName = 'Demo Server';

  if (isDemo) {
    const demo = db.getDemoGuild();
    roles = demo.roles;
    channels = demo.channels;
    guildName = demo.name;
  } else {
    const client = getDiscordClient();
    if (!client) {
      return res.status(400).json({ error: 'Discord credentials missing' });
    }
    try {
      const [g, r, c] = await Promise.all([
        client.getGuild(guildId),
        client.getGuildRoles(guildId),
        client.getGuildChannels(guildId),
      ]);
      guildName = g.name;
      roles = r;
      channels = c;
    } catch (err: any) {
      return res.status(500).json({ error: `Failed to fetch guild state for diff: ${err.message}` });
    }
  }

  const diff = TemplateReconciler.calculateDiff(guildId || 'demo-guild', guildName, roles, channels, template);
  res.json(diff);
});

// 6. Template Deployment
apiRouter.post('/deploy', async (req: Request, res: Response) => {
  const schema = z.object({
    guildId: z.string(),
    guildName: z.string().optional(),
    mode: z.enum(['MERGE', 'SYNC', 'REPLACE']),
    templateId: z.string().optional(),
    customTemplate: z.any().optional(),
    confirmationPhrase: z.string().optional(),
    publishInitialMessages: z.boolean().optional(),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid deployment options', details: parsed.error.issues });
  }

  const { guildId, mode, templateId, customTemplate, confirmationPhrase, publishInitialMessages } = parsed.data;
  const isDemo = guildId.startsWith('demo-') || guildId === 'demo-guild-blipmade-001';

  let targetTemplate: ServerTemplate | undefined = customTemplate;
  if (!targetTemplate && templateId) {
    targetTemplate = db.getTemplateById(templateId);
  }
  if (!targetTemplate) {
    targetTemplate = BLIPMADE_OFFICIAL_TEMPLATE;
  }

  const client = isDemo ? null : getDiscordClient();
  if (!isDemo && !client) {
    return res.status(400).json({ error: 'Cannot run Live deployment without valid Discord bot credentials' });
  }

  try {
    const result = await TemplateReconciler.execute(
      client,
      isDemo,
      guildId,
      parsed.data.guildName || (isDemo ? 'Blipmade Community (Demo)' : 'Live Server'),
      targetTemplate,
      {
        mode,
        confirmationPhrase,
        publishInitialMessages: Boolean(publishInitialMessages),
      }
    );

    res.json(result);
  } catch (err: any) {
    console.error('Deployment failure:', err);
    res.status(500).json({ error: err.message || 'Deployment failed' });
  }
});

// 7. Structural Backups
apiRouter.get('/backups', (req: Request, res: Response) => {
  const guildId = req.query.guildId as string | undefined;
  res.json(db.getBackups(guildId));
});

apiRouter.post('/backups/restore', async (req: Request, res: Response) => {
  const { backupId } = req.body;
  const backup = db.getBackupById(backupId);
  if (!backup) {
    return res.status(404).json({ error: 'Backup not found' });
  }

  // Restore back into demo or live
  const isDemo = backup.guildId.startsWith('demo-');
  if (isDemo) {
    const demo = db.getDemoGuild();
    demo.roles = backup.data.roles.map(r => ({
      id: r.id,
      name: r.name,
      color: r.color,
      hoist: true,
      position: r.position,
      permissions: r.permissions,
    }));
    demo.channels = backup.data.channels.map(c => ({
      id: c.id,
      name: c.name,
      type: c.type,
      position: c.position,
      topic: c.topic || null,
      parent_id: c.parentId || null,
    }));
    db.updateDemoGuild(demo);
    return res.json({ success: true, message: `Restored backup ${backupId} into Demo Guild` });
  }

  return res.status(501).json({ error: 'Live server restoration requires manual review. Download JSON snapshot for manual re-import.' });
});

// 8. Activity & Audit History
apiRouter.get('/activity', (req: Request, res: Response) => {
  res.json(db.getAuditRuns());
});

// 9. Messages & Embed Publishing
apiRouter.post('/messages/publish', async (req: Request, res: Response) => {
  const { channelId, guildId, message } = req.body;
  const isDemo = !guildId || guildId.startsWith('demo-') || guildId === 'demo-guild-blipmade-001';

  if (!channelId || !message) {
    return res.status(400).json({ error: 'channelId and message payload are required' });
  }

  if (isDemo) {
    // Record message publish action in activity
    db.logAuditRun({
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
      mode: 'MERGE',
      guildId: guildId || 'demo-guild',
      guildName: 'Blipmade Community (Demo)',
      isDemo: true,
      status: 'SUCCESS',
      summary: {
        rolesCreated: 0,
        rolesUpdated: 0,
        rolesDeleted: 0,
        categoriesCreated: 0,
        categoriesUpdated: 0,
        categoriesDeleted: 0,
        channelsCreated: 0,
        channelsUpdated: 0,
        channelsDeleted: 0,
        overwritesApplied: 0,
      },
      details: [
        {
          target: `Channel #${channelId}`,
          action: 'PUBLISH_EMBED_MESSAGE',
          status: 'SUCCESS',
          message: `Published embed "${message.embeds?.[0]?.title || 'Message'}" into demo channel`,
        },
      ],
    });

    return res.json({
      success: true,
      simulated: true,
      id: `demo-msg-${Date.now()}`,
      channelId,
    });
  }

  const client = getDiscordClient();
  if (!client) {
    return res.status(400).json({ error: 'Discord bot credentials missing for live publishing' });
  }

  try {
    const published = await client.sendMessage(channelId, message);
    res.json({ success: true, id: published.id, channelId: published.channel_id });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to publish message: ${err.message}` });
  }
});

// 10. Blipmade Webhook Integration Test
apiRouter.post('/integrations/test-webhook', async (req: Request, res: Response) => {
  const { target } = req.body; // 'status' | 'ops' | 'announcements'
  const settings = db.getSettings();

  let webhookUrl = '';
  let payload: any = {};

  if (target === 'status') {
    webhookUrl = settings.webhookStatusUrl;
    payload = {
      username: 'Blipmade Status Prober',
      avatar_url: 'https://blipmade.com/favicon.ico',
      embeds: [
        {
          title: 'Scheduled Node Maintenance Notice',
          description: 'Datacenter node **lon1-vps-c4** scheduled for automated memory compaction and Linux kernel 6.8 live-patching.\n\nEstimated downtime: < 15 seconds.',
          color: 0x3B82F6,
          fields: [
            { name: 'Impacted Services', value: 'NVMe VPS Clusters A-D', inline: true },
            { name: 'Region', value: 'London (UK-South)', inline: true },
            { name: 'Live Status Tracker', value: settings.blipmadeStatusUrl, inline: false },
          ],
          timestamp: new Date().toISOString(),
          footer: { text: 'Blipmade Infrastructure Operations' },
        },
      ],
    };
  } else if (target === 'ops') {
    webhookUrl = settings.webhookOpsUrl;
    payload = {
      username: 'Blipmade Internal Telemetry',
      embeds: [
        {
          title: '[CRITICAL ALERT] RAM Saturation Threshold Exceeded',
          description: 'Game Node `mc-node-eu-08` reached 92.4% memory pressure across 18 Paper 1.21 instances.',
          color: 0xDC2626,
          fields: [
            { name: 'Host Metric', value: 'Mem: 118.2 / 128 GB', inline: true },
            { name: 'Action Taken', value: 'Proactive JVM garbage sweep requested', inline: true },
          ],
          timestamp: new Date().toISOString(),
          footer: { text: 'Blipmade Internal Alert Daemon (Private)' },
        },
      ],
    };
  } else {
    webhookUrl = settings.webhookAnnouncementsUrl;
    payload = {
      username: 'Blipmade Announcements',
      embeds: [
        {
          title: 'New High-Frequency Ryzen 9 9950X Game Server Nodes',
          description: 'Dedicated game hosting clusters are now live in Frankfurt & New York! Featuring DDR5 ECC memory and PCIe 5.0 NVMe.',
          color: 0xE64A4A,
          footer: { text: 'Blipmade Product Engineering' },
        },
      ],
    };
  }

  if (!webhookUrl) {
    // Return simulated success with payload for demo purposes
    return res.json({
      success: true,
      simulated: true,
      message: `No active webhook configured for ${target}. Simulated dispatch verified successfully.`,
      payload,
    });
  }

  try {
    const ok = await DiscordRestClient.sendWebhook(webhookUrl, payload);
    if (!ok) {
      return res.status(502).json({ error: 'Discord webhook returned non-200 status' });
    }
    res.json({ success: true, simulated: false, message: `Live webhook dispatched to ${target}` });
  } catch (err: any) {
    res.status(500).json({ error: `Webhook dispatch failed: ${err.message}` });
  }
});

// 11. Settings
apiRouter.get('/settings', (req: Request, res: Response) => {
  const s = db.getSettings();
  res.json({
    discordClientId: s.discordClientId,
    hasDiscordBotToken: Boolean(s.discordBotToken),
    botTokenPrefix: s.discordBotToken ? `${s.discordBotToken.substring(0, 8)}...` : '',
    discordRedirectUri: s.discordRedirectUri,
    targetGuildId: s.targetGuildId || '',
    webhookStatusUrl: s.webhookStatusUrl,
    webhookOpsUrl: s.webhookOpsUrl,
    webhookAnnouncementsUrl: s.webhookAnnouncementsUrl,
    blipmadeTicketsUrl: s.blipmadeTicketsUrl,
    blipmadeDocsUrl: s.blipmadeDocsUrl,
    blipmadeStatusUrl: s.blipmadeStatusUrl,
    isLiveModeEnabled: s.isLiveModeEnabled,
  });
});

apiRouter.post('/settings', (req: Request, res: Response) => {
  const updated = db.updateSettings(req.body);
  res.json({
    discordClientId: updated.discordClientId,
    hasDiscordBotToken: Boolean(updated.discordBotToken),
    botTokenPrefix: updated.discordBotToken ? `${updated.discordBotToken.substring(0, 8)}...` : '',
    discordRedirectUri: updated.discordRedirectUri,
    targetGuildId: updated.targetGuildId || '',
    webhookStatusUrl: updated.webhookStatusUrl,
    webhookOpsUrl: updated.webhookOpsUrl,
    webhookAnnouncementsUrl: updated.webhookAnnouncementsUrl,
    blipmadeTicketsUrl: updated.blipmadeTicketsUrl,
    blipmadeDocsUrl: updated.blipmadeDocsUrl,
    blipmadeStatusUrl: updated.blipmadeStatusUrl,
    isLiveModeEnabled: updated.isLiveModeEnabled,
  });
});

// 12. Reset Demo Guild
apiRouter.post('/demo/reset', (req: Request, res: Response) => {
  const fresh = db.resetDemoGuild();
  res.json(fresh);
});
