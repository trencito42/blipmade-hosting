/**
 * In-memory & JSON file persistent store for Blipmade Discord Studio
 * Manages templates, backups, audit history, settings, and demo guild simulation.
 */

import fs from 'fs';
import path from 'path';
import { BLIPMADE_OFFICIAL_TEMPLATE, BLIPMADE_MINIMAL_TEMPLATE, BLIPMADE_GAMING_TEMPLATE } from '../templates/blipmadeDefault.ts';
import type { ServerTemplate } from '../templates/blipmadeDefault.ts';

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DATA_FILE = path.join(DATA_DIR, 'studio_store.json');

export interface AuditRun {
  id: string;
  timestamp: string;
  mode: 'MERGE' | 'SYNC' | 'REPLACE';
  guildId: string;
  guildName: string;
  isDemo: boolean;
  status: 'SUCCESS' | 'PARTIAL' | 'FAILED' | 'DRY_RUN';
  summary: {
    rolesCreated: number;
    rolesUpdated: number;
    rolesDeleted: number;
    categoriesCreated: number;
    categoriesUpdated: number;
    categoriesDeleted: number;
    channelsCreated: number;
    channelsUpdated: number;
    channelsDeleted: number;
    overwritesApplied: number;
  };
  details: Array<{
    target: string;
    action: string;
    status: 'SUCCESS' | 'FAILED' | 'SKIPPED';
    message?: string;
  }>;
}

export interface StructuralBackup {
  id: string;
  timestamp: string;
  guildId: string;
  guildName: string;
  reason: string;
  data: {
    roles: Array<{ id: string; name: string; color: number; position: number; permissions: string }>;
    channels: Array<{ id: string; name: string; type: number; position: number; topic?: string; parentId?: string }>;
  };
}

export interface StudioSettings {
  discordClientId: string;
  discordBotToken: string;
  discordRedirectUri: string;
  targetGuildId?: string;
  webhookStatusUrl: string;
  webhookOpsUrl: string;
  webhookAnnouncementsUrl: string;
  blipmadeTicketsUrl: string;
  blipmadeDocsUrl: string;
  blipmadeStatusUrl: string;
  isLiveModeEnabled: boolean;
}

export interface DemoGuildState {
  id: string;
  name: string;
  icon: string | null;
  owner_id: string;
  roles: Array<{
    id: string;
    name: string;
    color: number;
    hoist: boolean;
    position: number;
    permissions: string;
    managed?: boolean;
    mentionable?: boolean;
  }>;
  channels: Array<{
    id: string;
    name: string;
    type: number;
    position: number;
    topic?: string | null;
    parent_id?: string | null;
    rate_limit_per_user?: number;
    permission_overwrites?: Array<{
      id: string;
      type: number;
      allow: string;
      deny: string;
    }>;
  }>;
}

interface StoreSchema {
  templates: ServerTemplate[];
  backups: StructuralBackup[];
  auditRuns: AuditRun[];
  settings: StudioSettings;
  demoGuild: DemoGuildState;
}

function initializeDemoGuild(): DemoGuildState {
  return {
    id: 'demo-guild-blipmade-001',
    name: 'Blipmade Community (Demo Guild)',
    icon: null,
    owner_id: 'user-demo-admin-01',
    roles: [
      { id: 'role-everyone', name: '@everyone', color: 0, hoist: false, position: 0, permissions: '1071698660929' },
      { id: 'role-admin', name: 'Administrator', color: 0xFF7676, hoist: true, position: 3, permissions: '8' },
      { id: 'role-support', name: 'Support Team', color: 0x3B82F6, hoist: true, position: 2, permissions: '1114112' },
      { id: 'role-member', name: 'Community Member', color: 0x9E9B95, hoist: false, position: 1, permissions: '369664' },
    ],
    channels: [
      // Some pre-existing channels to demonstrate realistic MERGE and SYNC
      { id: 'cat-info', name: 'INFORMATION', type: 4, position: 0 },
      { id: 'chan-welcome', name: 'welcome', type: 0, position: 0, parent_id: 'cat-info', topic: 'Initial welcoming' },
      { id: 'chan-general', name: 'general', type: 0, position: 1, parent_id: 'cat-info', topic: 'General discussion' },
    ],
  };
}

class StoreManager {
  private data: StoreSchema;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): StoreSchema {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          templates: parsed.templates || [BLIPMADE_OFFICIAL_TEMPLATE, BLIPMADE_MINIMAL_TEMPLATE, BLIPMADE_GAMING_TEMPLATE],
          backups: parsed.backups || [],
          auditRuns: parsed.auditRuns || [],
          settings: {
            discordClientId: process.env.DISCORD_CLIENT_ID || parsed.settings?.discordClientId || '',
            discordBotToken: process.env.DISCORD_BOT_TOKEN || parsed.settings?.discordBotToken || '',
            discordRedirectUri: process.env.DISCORD_REDIRECT_URI || parsed.settings?.discordRedirectUri || 'http://localhost:3000/api/auth/discord/callback',
            targetGuildId: process.env.BLIPMADE_TARGET_GUILD_ID || parsed.settings?.targetGuildId || '207468519221100544',
            webhookStatusUrl: process.env.BLIPMADE_STATUS_WEBHOOK_URL || parsed.settings?.webhookStatusUrl || '',
            webhookOpsUrl: process.env.BLIPMADE_OPS_WEBHOOK_URL || parsed.settings?.webhookOpsUrl || '',
            webhookAnnouncementsUrl: process.env.BLIPMADE_ANNOUNCEMENTS_WEBHOOK_URL || parsed.settings?.webhookAnnouncementsUrl || '',
            blipmadeTicketsUrl: parsed.settings?.blipmadeTicketsUrl || 'https://blipmade.com/app/tickets',
            blipmadeDocsUrl: parsed.settings?.blipmadeDocsUrl || 'https://blipmade.com/docs',
            blipmadeStatusUrl: parsed.settings?.blipmadeStatusUrl || 'https://blipmade.com/status',
            isLiveModeEnabled: Boolean(process.env.DISCORD_BOT_TOKEN || parsed.settings?.discordBotToken),
          },
          demoGuild: parsed.demoGuild || initializeDemoGuild(),
        };
      }
    } catch (err) {
      console.warn('Failed to read studio_store.json, creating initial store state', err);
    }

    return {
      templates: [BLIPMADE_OFFICIAL_TEMPLATE, BLIPMADE_MINIMAL_TEMPLATE, BLIPMADE_GAMING_TEMPLATE],
      backups: [],
      auditRuns: [],
      settings: {
        discordClientId: process.env.DISCORD_CLIENT_ID || '',
        discordBotToken: process.env.DISCORD_BOT_TOKEN || '',
        discordRedirectUri: process.env.DISCORD_REDIRECT_URI || 'http://localhost:3000/api/auth/discord/callback',
        webhookStatusUrl: process.env.BLIPMADE_STATUS_WEBHOOK_URL || '',
        webhookOpsUrl: process.env.BLIPMADE_OPS_WEBHOOK_URL || '',
        webhookAnnouncementsUrl: process.env.BLIPMADE_ANNOUNCEMENTS_WEBHOOK_URL || '',
        blipmadeTicketsUrl: 'https://blipmade.com/app/tickets',
        blipmadeDocsUrl: 'https://blipmade.com/docs',
        blipmadeStatusUrl: 'https://blipmade.com/status',
        isLiveModeEnabled: Boolean(process.env.DISCORD_BOT_TOKEN),
      },
      demoGuild: initializeDemoGuild(),
    };
  }

  private persist() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error persisting studio data:', err);
    }
  }

  // Templates
  getTemplates(): ServerTemplate[] {
    return this.data.templates;
  }

  getTemplateById(id: string): ServerTemplate | undefined {
    return this.data.templates.find(t => t.id === id);
  }

  saveTemplate(template: ServerTemplate): ServerTemplate {
    const existingIndex = this.data.templates.findIndex(t => t.id === template.id);
    if (existingIndex >= 0) {
      this.data.templates[existingIndex] = template;
    } else {
      this.data.templates.push(template);
    }
    this.persist();
    return template;
  }

  deleteTemplate(id: string): boolean {
    if (id === 'blipmade-official-v1') return false; // Protected
    const initialLen = this.data.templates.length;
    this.data.templates = this.data.templates.filter(t => t.id !== id);
    if (this.data.templates.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // Backups
  createBackup(backup: StructuralBackup): StructuralBackup {
    this.data.backups.unshift(backup);
    if (this.data.backups.length > 50) {
      this.data.backups.pop();
    }
    this.persist();
    return backup;
  }

  getBackups(guildId?: string): StructuralBackup[] {
    if (guildId) {
      return this.data.backups.filter(b => b.guildId === guildId);
    }
    return this.data.backups;
  }

  getBackupById(id: string): StructuralBackup | undefined {
    return this.data.backups.find(b => b.id === id);
  }

  // Audit
  logAuditRun(run: AuditRun): AuditRun {
    this.data.auditRuns.unshift(run);
    if (this.data.auditRuns.length > 100) {
      this.data.auditRuns.pop();
    }
    this.persist();
    return run;
  }

  getAuditRuns(): AuditRun[] {
    return this.data.auditRuns;
  }

  // Settings
  getSettings(): StudioSettings {
    const envToken = process.env.DISCORD_BOT_TOKEN;
    const envClientId = process.env.DISCORD_CLIENT_ID;
    return {
      ...this.data.settings,
      discordClientId: envClientId || this.data.settings.discordClientId,
      discordBotToken: envToken || this.data.settings.discordBotToken,
      isLiveModeEnabled: Boolean(envToken || this.data.settings.discordBotToken),
    };
  }

  updateSettings(settings: Partial<StudioSettings>): StudioSettings {
    this.data.settings = {
      ...this.data.settings,
      ...settings,
      isLiveModeEnabled: Boolean(settings.discordBotToken || this.data.settings.discordBotToken || process.env.DISCORD_BOT_TOKEN),
    };
    this.persist();
    return this.getSettings();
  }

  // Demo Guild state management
  getDemoGuild(): DemoGuildState {
    return this.data.demoGuild;
  }

  updateDemoGuild(guild: DemoGuildState) {
    this.data.demoGuild = guild;
    this.persist();
  }

  resetDemoGuild(): DemoGuildState {
    this.data.demoGuild = initializeDemoGuild();
    this.persist();
    return this.data.demoGuild;
  }
}

export const db = new StoreManager();
