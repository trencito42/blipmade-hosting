/**
 * Official Blipmade Hosting Community Server Template
 * Standardized structure for VPS, game server, bot hosting, and domain operations.
 */

export interface RoleTemplate {
  name: string;
  color: number;
  hoist: boolean;
  mentionable: boolean;
  permissions: string;
  isCustom?: boolean;
  description?: string;
}

export interface OverwriteTemplate {
  roleName: string; // Matched against role name or '@everyone'
  allow: string;
  deny: string;
}

export interface ChannelTemplate {
  id?: string;
  name: string;
  type: number; // 0 = text, 2 = voice, 4 = category, 5 = announcement, 15 = forum
  topic?: string;
  categoryName?: string; // Links channel to a category by name
  position: number;
  nsfw?: boolean;
  rateLimitPerUser?: number; // Slowmode in seconds
  permissionOverwrites?: OverwriteTemplate[];
  initialMessage?: {
    content?: string;
    embeds?: Array<{
      title: string;
      description: string;
      color: number;
      fields?: Array<{ name: string; value: string; inline?: boolean }>;
      footer?: { text: string };
    }>;
  };
}

export interface ServerTemplate {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  roles: RoleTemplate[];
  categories: ChannelTemplate[];
  channels: ChannelTemplate[];
}

export const BLIPMADE_OFFICIAL_TEMPLATE: ServerTemplate = {
  id: 'blipmade-official-v1',
  name: 'Blipmade | Official Hosting Community',
  description: 'The standard Discord community and infrastructure operations server for Blipmade VPS, game server, and application hosting.',
  version: '1.2.0',
  author: 'Blipmade Core Team',
  roles: [
    {
      name: 'Owner',
      color: 0xE64A4A, // Blipmade Red
      hoist: true,
      mentionable: true,
      permissions: '8', // Administrator
      description: 'Blipmade Platform Founders and Executives',
    },
    {
      name: 'Administrator',
      color: 0xFF7676,
      hoist: true,
      mentionable: true,
      permissions: '268435456', // Manage Roles, Channels, etc.
      description: 'System architects and infrastructure managers',
    },
    {
      name: 'Support Team',
      color: 0x3B82F6, // Blue
      hoist: true,
      mentionable: true,
      permissions: '1114112', // Manage Messages, View Audit Log, Priority Speaker
      description: 'Official Blipmade customer technical support staff',
    },
    {
      name: 'Verified Customer',
      color: 0x10B981, // Emerald Green
      hoist: true,
      mentionable: false,
      permissions: '379968', // Embed Links, Attach Files, Add Reactions, Use External Emojis
      description: 'Validated active subscription or server tenant on Blipmade',
    },
    {
      name: 'Community Member',
      color: 0x9E9B95, // Muted Silver
      hoist: false,
      mentionable: false,
      permissions: '369664', // Standard chat, reaction, voice access
      description: 'Registered enthusiast and community member',
    },
  ],
  categories: [
    {
      name: 'START HERE',
      type: 4,
      position: 0,
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '1024', // View Channel
          deny: '2048',  // Send Messages (read-only by default for category)
        },
        {
          roleName: 'Support Team',
          allow: '2048',
          deny: '0',
        },
      ],
    },
    {
      name: 'HELP & SUPPORT',
      type: 4,
      position: 1,
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '3072', // View Channel + Send Messages
          deny: '0',
        },
      ],
    },
    {
      name: 'HOSTING',
      type: 4,
      position: 2,
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '3072',
          deny: '0',
        },
      ],
    },
    {
      name: 'COMMUNITY',
      type: 4,
      position: 3,
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '3072',
          deny: '0',
        },
      ],
    },
    {
      name: 'BLIPMADE TEAM (PRIVATE)',
      type: 4,
      position: 4,
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '0',
          deny: '1024', // Deny View Channel to everyone
        },
        {
          roleName: 'Support Team',
          allow: '3072', // View & Send
          deny: '0',
        },
        {
          roleName: 'Administrator',
          allow: '3072',
          deny: '0',
        },
        {
          roleName: 'Owner',
          allow: '3072',
          deny: '0',
        },
      ],
    },
  ],
  channels: [
    // START HERE
    {
      name: 'welcome',
      type: 0,
      categoryName: 'START HERE',
      position: 0,
      topic: 'Welcome to the official Blipmade Hosting Discord server. Explore documentation and get started.',
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '1024',
          deny: '2048', // Read-only
        },
      ],
      initialMessage: {
        embeds: [
          {
            title: 'Welcome to Blipmade Hosting',
            description: 'Blipmade provides high-performance cloud compute, NVMe VPS, dedicated game servers, and developer bot hosting.\n\n• **Official Website**: https://blipmade.com\n• **Documentation & Guides**: https://blipmade.com/docs\n• **Platform Status**: https://blipmade.com/status\n• **Customer Support Tickets**: https://blipmade.com/app/tickets\n\n*Please review the rules in #rules and introduce yourself in #general!*',
            color: 0xE64A4A,
            fields: [
              { name: 'Need Support?', value: 'For private account or billing matters, open a ticket at [blipmade.com/app/tickets](https://blipmade.com/app/tickets). For peer discussions, use #community-help.', inline: false },
              { name: 'Customer Verification', value: 'Link your Discord in your Blipmade client dashboard to receive the Verified Customer badge.', inline: true },
            ],
            footer: { text: 'Blipmade Infrastructure Services' },
          },
        ],
      },
    },
    {
      name: 'rules',
      type: 0,
      categoryName: 'START HERE',
      position: 1,
      topic: 'Official community standards, guidelines, and hosting platform policies.',
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '1024',
          deny: '2048',
        },
      ],
      initialMessage: {
        embeds: [
          {
            title: 'Blipmade Community Guidelines',
            description: 'To maintain a productive and respectful developer environment, all members must adhere to these policies:\n\n1. **Respect & Professionalism**: Treat all community members, engineers, and support staff with courtesy.\n2. **No Malicious Activity**: Do not discuss, distribute, or configure exploits, stressers/DDoS tools, or malware.\n3. **Privacy & Security**: Never share server root passwords, SSH private keys, API secrets, or personal billing invoices in public channels.\n4. **Appropriate Channels**: Post questions in the appropriate domain channel (#vps-hosting, #game-servers, #apps-and-bots).\n5. **Billing & Dispute Routing**: All payment and SLA disputes must be directed to https://blipmade.com/app/tickets.\n6. **No Self-Promotion / Spam**: Unsolicited advertising of competing services or crypto promotions is prohibited.\n7. **Comply with Discord TOS**: You must adhere to Discord\'s Terms of Service and Community Guidelines.\n8. **Follow Staff Guidance**: Blipmade staff decisions are final.',
            color: 0xE64A4A,
            footer: { text: 'Enforced by Blipmade Team' },
          },
        ],
      },
    },
    {
      name: 'announcements',
      type: 5, // GUILD_ANNOUNCEMENT
      categoryName: 'START HERE',
      position: 2,
      topic: 'Platform releases, node upgrades, new regions, and product updates.',
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '1024',
          deny: '2048',
        },
      ],
    },
    {
      name: 'service-status',
      type: 0,
      categoryName: 'START HERE',
      position: 3,
      topic: 'Automated incidents, scheduled maintenance, and datacenter connectivity updates.',
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '1024',
          deny: '2048',
        },
      ],
    },

    // HELP & SUPPORT
    {
      name: 'community-help',
      type: 0, // Fallback to text channel for universal compatibility
      categoryName: 'HELP & SUPPORT',
      position: 0,
      topic: 'Community peer support for server setup, Linux configuration, game server mods, and deployment tips.',
      rateLimitPerUser: 10,
    },
    {
      name: 'guides',
      type: 0,
      categoryName: 'HELP & SUPPORT',
      position: 1,
      topic: 'Curated tutorials, benchmark comparisons, and system administration best practices.',
      permissionOverwrites: [
        {
          roleName: '@everyone',
          allow: '1024',
          deny: '2048',
        },
      ],
    },
    {
      name: 'suggestions',
      type: 0,
      categoryName: 'HELP & SUPPORT',
      position: 2,
      topic: 'Feature requests and product feedback for the Blipmade cloud platform.',
      rateLimitPerUser: 60,
    },

    // HOSTING
    {
      name: 'vps-hosting',
      type: 0,
      categoryName: 'HOSTING',
      position: 0,
      topic: 'Linux distros, Docker, kernel tuning, network throughput, and cloud VPS architecture.',
    },
    {
      name: 'game-servers',
      type: 0,
      categoryName: 'HOSTING',
      position: 1,
      topic: 'Minecraft (Paper/Forge/Fabric), Rust, Palworld, ARK, Valheim, and dedicated game server optimization.',
    },
    {
      name: 'apps-and-bots',
      type: 0,
      categoryName: 'HOSTING',
      position: 2,
      topic: 'Node.js, Python, Go, and Discord bot container hosting, uptime monitoring, and CI/CD pipelines.',
    },
    {
      name: 'domains-and-email',
      type: 0,
      categoryName: 'HOSTING',
      position: 3,
      topic: 'DNS records, SSL/TLS certificates, reverse proxy, SPF/DKIM/DMARC email routing.',
    },

    // COMMUNITY
    {
      name: 'general',
      type: 0,
      categoryName: 'COMMUNITY',
      position: 0,
      topic: 'General hosting chatter, tech discussions, and developer hanging out.',
    },
    {
      name: 'showcase',
      type: 0,
      categoryName: 'COMMUNITY',
      position: 1,
      topic: 'Show off projects, gaming worlds, custom bots, and websites hosted on Blipmade.',
    },
    {
      name: 'General Voice',
      type: 2, // GUILD_VOICE
      categoryName: 'COMMUNITY',
      position: 2,
    },

    // BLIPMADE TEAM (PRIVATE)
    {
      name: 'staff-chat',
      type: 0,
      categoryName: 'BLIPMADE TEAM (PRIVATE)',
      position: 0,
      topic: 'Private coordination channel for Blipmade executives, developers, and support staff.',
    },
    {
      name: 'ops-alerts',
      type: 0,
      categoryName: 'BLIPMADE TEAM (PRIVATE)',
      position: 1,
      topic: 'Private automated infrastructure alerts: CPU thresholds, node connectivity, and probers.',
    },
    {
      name: 'moderation-log',
      type: 0,
      categoryName: 'BLIPMADE TEAM (PRIVATE)',
      position: 2,
      topic: 'Internal security and audit log for moderation actions and bot activities.',
    },
  ],
};

export const BLIPMADE_MINIMAL_TEMPLATE: ServerTemplate = {
  id: 'blipmade-minimal-v1',
  name: 'Blipmade | Minimal Infrastructure Hub',
  description: 'A streamlined Discord server layout suitable for smaller developer hosting teams.',
  version: '1.0.0',
  author: 'Blipmade Core Team',
  roles: [
    {
      name: 'Admin',
      color: 0xE64A4A,
      hoist: true,
      mentionable: true,
      permissions: '8',
    },
    {
      name: 'Member',
      color: 0x9E9B95,
      hoist: false,
      mentionable: false,
      permissions: '369664',
    },
  ],
  categories: [
    {
      name: 'INFORMATION',
      type: 4,
      position: 0,
    },
    {
      name: 'HOSTING & HELP',
      type: 4,
      position: 1,
    },
  ],
  channels: [
    {
      name: 'announcements',
      type: 0,
      categoryName: 'INFORMATION',
      position: 0,
    },
    {
      name: 'vps-and-games',
      type: 0,
      categoryName: 'HOSTING & HELP',
      position: 0,
    },
    {
      name: 'general-support',
      type: 0,
      categoryName: 'HOSTING & HELP',
      position: 1,
    },
  ],
};

export const BLIPMADE_GAMING_TEMPLATE: ServerTemplate = {
  id: 'blipmade-gaming-v1',
  name: 'Blipmade | Game Hosting Community',
  description: 'Specialized layout tailored for Minecraft, Rust, and Palworld game server hosting communities.',
  version: '1.1.0',
  author: 'Blipmade Core Team',
  roles: [
    {
      name: 'Server Admin',
      color: 0xE64A4A,
      hoist: true,
      mentionable: true,
      permissions: '8',
    },
    {
      name: 'Game Master',
      color: 0xF59E0B,
      hoist: true,
      mentionable: true,
      permissions: '1114112',
    },
    {
      name: 'Player',
      color: 0x10B981,
      hoist: false,
      mentionable: false,
      permissions: '369664',
    },
  ],
  categories: [
    {
      name: 'WELCOME & RULES',
      type: 4,
      position: 0,
    },
    {
      name: 'GAME SERVERS',
      type: 4,
      position: 1,
    },
    {
      name: 'VOICE CHANNELS',
      type: 4,
      position: 2,
    },
  ],
  channels: [
    {
      name: 'server-ip-and-rules',
      type: 0,
      categoryName: 'WELCOME & RULES',
      position: 0,
    },
    {
      name: 'minecraft-discussion',
      type: 0,
      categoryName: 'GAME SERVERS',
      position: 0,
    },
    {
      name: 'rust-and-survival',
      type: 0,
      categoryName: 'GAME SERVERS',
      position: 1,
    },
    {
      name: 'Squad 1 Voice',
      type: 2,
      categoryName: 'VOICE CHANNELS',
      position: 0,
    },
  ],
};
