/**
 * Official Discord REST API Client (v10)
 * Handles rate limits, backoff, and robust error logging.
 */

const DISCORD_API_BASE = 'https://discord.com/api/v10';

export interface DiscordApiError {
  status: number;
  message: string;
  code?: number;
  errors?: Record<string, unknown>;
}

export interface DiscordRole {
  id: string;
  name: string;
  color: number;
  hoist: boolean;
  position: number;
  permissions: string;
  managed: boolean;
  mentionable: boolean;
}

export interface DiscordOverwrite {
  id: string;
  type: number; // 0 for role, 1 for member
  allow: string;
  deny: string;
}

export interface DiscordChannel {
  id: string;
  type: number;
  guild_id?: string;
  position: number;
  permission_overwrites?: DiscordOverwrite[];
  name: string;
  topic?: string | null;
  nsfw?: boolean;
  parent_id?: string | null;
  rate_limit_per_user?: number;
}

export interface DiscordGuild {
  id: string;
  name: string;
  icon: string | null;
  owner_id: string;
  permissions?: string;
  roles?: DiscordRole[];
}

export class DiscordRestClient {
  private token: string;

  constructor(token: string) {
    this.token = token.trim();
  }

  private async request<T>(endpoint: string, options: RequestInit = {}, retries = 3): Promise<T> {
    const url = `${DISCORD_API_BASE}${endpoint}`;
    const headers = {
      'Authorization': `Bot ${this.token}`,
      'Content-Type': 'application/json',
      'User-Agent': 'BlipmadeDiscordStudio/1.2.0 (https://blipmade.com)',
      ...(options.headers || {}),
    };

    try {
      const res = await fetch(url, { ...options, headers });

      if (res.status === 429) {
        const body = await res.json().catch(() => ({ retry_after: 1 }));
        const retryAfter = (body.retry_after || 1) * 1000;
        console.warn(`[Discord API] Rate limited on ${endpoint}. Retrying in ${retryAfter}ms...`);
        if (retries > 0) {
          await new Promise(r => setTimeout(r, retryAfter + 200));
          return this.request<T>(endpoint, options, retries - 1);
        }
        throw new Error(`Discord rate limit exceeded (429). Retry after ${body.retry_after}s`);
      }

      if (!res.ok) {
        const errText = await res.text();
        let parsedErr: any = {};
        try {
          parsedErr = JSON.parse(errText);
        } catch {
          parsedErr = { message: errText };
        }
        const error: DiscordApiError = {
          status: res.status,
          message: parsedErr.message || `HTTP ${res.status} on ${endpoint}`,
          code: parsedErr.code,
          errors: parsedErr.errors,
        };
        throw error;
      }

      if (res.status === 204) {
        return {} as T;
      }

      return await res.json() as T;
    } catch (err: any) {
      if (err.status) throw err;
      throw new Error(`Discord API network request failed: ${err.message || 'Unknown network error'}`);
    }
  }

  async getBotUser(): Promise<{ id: string; username: string; discriminator: string; avatar: string | null }> {
    return this.request('/users/@me');
  }

  async getBotGuilds(): Promise<Array<{ id: string; name: string; icon: string | null; permissions: string }>> {
    return this.request('/users/@me/guilds');
  }

  async getGuild(guildId: string): Promise<DiscordGuild> {
    return this.request(`/guilds/${guildId}?with_counts=true`);
  }

  async getGuildChannels(guildId: string): Promise<DiscordChannel[]> {
    return this.request(`/guilds/${guildId}/channels`);
  }

  async getGuildRoles(guildId: string): Promise<DiscordRole[]> {
    return this.request(`/guilds/${guildId}/roles`);
  }

  async createChannel(guildId: string, payload: {
    name: string;
    type: number;
    topic?: string;
    parent_id?: string | null;
    position?: number;
    rate_limit_per_user?: number;
    permission_overwrites?: DiscordOverwrite[];
  }): Promise<DiscordChannel> {
    return this.request(`/guilds/${guildId}/channels`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async updateChannel(channelId: string, payload: {
    name?: string;
    type?: number;
    position?: number;
    topic?: string | null;
    parent_id?: string | null;
    rate_limit_per_user?: number;
    permission_overwrites?: DiscordOverwrite[];
  }): Promise<DiscordChannel> {
    return this.request(`/channels/${channelId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  }

  async deleteChannel(channelId: string): Promise<void> {
    return this.request(`/channels/${channelId}`, {
      method: 'DELETE',
    });
  }

  async createRole(guildId: string, payload: {
    name: string;
    color?: number;
    hoist?: boolean;
    permissions?: string;
    mentionable?: boolean;
  }): Promise<DiscordRole> {
    return this.request(`/guilds/${guildId}/roles`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async updateRole(guildId: string, roleId: string, payload: {
    name?: string;
    color?: number;
    hoist?: boolean;
    permissions?: string;
    mentionable?: boolean;
    position?: number;
  }): Promise<DiscordRole> {
    return this.request(`/guilds/${guildId}/roles/${roleId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  }

  async deleteRole(guildId: string, roleId: string): Promise<void> {
    return this.request(`/guilds/${guildId}/roles/${roleId}`, {
      method: 'DELETE',
    });
  }

  async updateChannelOverwrite(channelId: string, overwriteId: string, payload: {
    type: number;
    allow: string;
    deny: string;
  }): Promise<void> {
    return this.request(`/channels/${channelId}/permissions/${overwriteId}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  }

  async sendMessage(channelId: string, payload: {
    content?: string;
    embeds?: Array<{
      title?: string;
      description?: string;
      color?: number;
      fields?: Array<{ name: string; value: string; inline?: boolean }>;
      footer?: { text: string; icon_url?: string };
      thumbnail?: { url: string };
      image?: { url: string };
      timestamp?: string;
    }>;
  }): Promise<{ id: string; channel_id: string }> {
    return this.request(`/channels/${channelId}/messages`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  static async sendWebhook(webhookUrl: string, payload: any): Promise<boolean> {
    const res = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.ok;
  }
}
