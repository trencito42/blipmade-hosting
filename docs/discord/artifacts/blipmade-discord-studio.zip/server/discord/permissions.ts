/**
 * Discord Permissions Bitfield Constants & Calculations
 * Based on Discord Developer Portal Documentation (v10)
 */

export const Permissions = {
  CREATE_INSTANT_INVITE: 1n << 0n,
  KICK_MEMBERS: 1n << 1n,
  BAN_MEMBERS: 1n << 2n,
  ADMINISTRATOR: 1n << 3n,
  MANAGE_CHANNELS: 1n << 4n,
  MANAGE_GUILD: 1n << 5n,
  ADD_REACTIONS: 1n << 6n,
  VIEW_AUDIT_LOG: 1n << 7n,
  PRIORITY_SPEAKER: 1n << 8n,
  STREAM: 1n << 9n,
  VIEW_CHANNEL: 1n << 10n,
  SEND_MESSAGES: 1n << 11n,
  SEND_TTS_MESSAGES: 1n << 12n,
  MANAGE_MESSAGES: 1n << 13n,
  EMBED_LINKS: 1n << 14n,
  ATTACH_FILES: 1n << 15n,
  READ_MESSAGE_HISTORY: 1n << 16n,
  MENTION_EVERYONE: 1n << 17n,
  USE_EXTERNAL_EMOJIS: 1n << 18n,
  VIEW_GUILD_INSIGHTS: 1n << 19n,
  CONNECT: 1n << 20n,
  SPEAK: 1n << 21n,
  MUTE_MEMBERS: 1n << 22n,
  DEAFEN_MEMBERS: 1n << 23n,
  MOVE_MEMBERS: 1n << 24n,
  USE_VAD: 1n << 25n,
  CHANGE_NICKNAME: 1n << 26n,
  MANAGE_NICKNAMES: 1n << 27n,
  MANAGE_ROLES: 1n << 28n,
  MANAGE_WEBHOOKS: 1n << 29n,
  MANAGE_GUILD_EXPRESSIONS: 1n << 30n,
  USE_APPLICATION_COMMANDS: 1n << 31n,
  REQUEST_TO_SPEAK: 1n << 32n,
  MANAGE_EVENTS: 1n << 33n,
  MANAGE_THREADS: 1n << 34n,
  CREATE_PUBLIC_THREADS: 1n << 35n,
  CREATE_PRIVATE_THREADS: 1n << 36n,
  USE_EXTERNAL_STICKERS: 1n << 37n,
  SEND_MESSAGES_IN_THREADS: 1n << 38n,
  USE_EMBEDDED_ACTIVITIES: 1n << 39n,
  MODERATE_MEMBERS: 1n << 40n,
};

export const ChannelTypes = {
  GUILD_TEXT: 0,
  DM: 1,
  GUILD_VOICE: 2,
  GROUP_DM: 3,
  GUILD_CATEGORY: 4,
  GUILD_ANNOUNCEMENT: 5,
  ANNOUNCEMENT_THREAD: 10,
  PUBLIC_THREAD: 11,
  PRIVATE_THREAD: 12,
  GUILD_STAGE_VOICE: 13,
  GUILD_DIRECTORY: 14,
  GUILD_FORUM: 15,
  GUILD_MEDIA: 16,
};

/**
 * Checks if a permissions bitfield string has all required permission flags
 */
export function hasPermission(bitfield: string | bigint | number, permission: bigint): boolean {
  try {
    const bit = BigInt(bitfield);
    if ((bit & Permissions.ADMINISTRATOR) === Permissions.ADMINISTRATOR) {
      return true;
    }
    return (bit & permission) === permission;
  } catch {
    return false;
  }
}

/**
 * Combines an array of permission keys into a bigint bitfield string
 */
export function combinePermissions(keys: (keyof typeof Permissions)[]): string {
  let bitfield = 0n;
  for (const key of keys) {
    if (Permissions[key]) {
      bitfield |= Permissions[key];
    }
  }
  return bitfield.toString();
}

/**
 * Decomposes a permissions bitfield string into an array of readable permission keys
 */
export function decomposePermissions(bitfield: string): (keyof typeof Permissions)[] {
  try {
    const bit = BigInt(bitfield);
    const active: (keyof typeof Permissions)[] = [];
    for (const [key, val] of Object.entries(Permissions)) {
      if ((bit & val) === val) {
        active.push(key as keyof typeof Permissions);
      }
    }
    return active;
  } catch {
    return [];
  }
}

/**
 * Required permissions for the Blipmade Discord Studio bot
 */
export const REQUIRED_BOT_PERMISSIONS = combinePermissions([
  'VIEW_CHANNEL',
  'SEND_MESSAGES',
  'EMBED_LINKS',
  'ATTACH_FILES',
  'READ_MESSAGE_HISTORY',
  'MANAGE_CHANNELS',
  'MANAGE_ROLES',
  'MANAGE_MESSAGES',
  'VIEW_AUDIT_LOG',
]);

/**
 * Generates an OAuth2 bot invitation URL with the required permissions
 */
export function getBotInviteUrl(clientId: string): string {
  const permissions = REQUIRED_BOT_PERMISSIONS;
  return `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=${permissions}&scope=bot%20applications.commands`;
}
