/**
 * Smart Template Reconciliation Engine
 * Calculates structural diffs and executes changes in MERGE, SYNC, or REPLACE modes.
 */

import { DiscordRestClient } from './api.ts';
import type { DiscordRole, DiscordChannel } from './api.ts';
import type { ServerTemplate, RoleTemplate, ChannelTemplate } from '../templates/blipmadeDefault.ts';
import { db } from '../store/db.ts';
import type { AuditRun, StructuralBackup } from '../store/db.ts';

export interface DiffItem<T> {
  item: T;
  reason?: string;
}

export interface ServerDiff {
  guildId: string;
  guildName: string;
  targetTemplateId: string;
  targetTemplateName: string;
  roles: {
    toCreate: DiffItem<RoleTemplate>[];
    toUpdate: DiffItem<{ existing: DiscordRole; proposed: RoleTemplate }>[];
    unchanged: DiscordRole[];
    toDelete: DiscordRole[];
  };
  categories: {
    toCreate: DiffItem<ChannelTemplate>[];
    toUpdate: DiffItem<{ existing: DiscordChannel; proposed: ChannelTemplate }>[];
    unchanged: DiscordChannel[];
    toDelete: DiscordChannel[];
  };
  channels: {
    toCreate: DiffItem<ChannelTemplate>[];
    toUpdate: DiffItem<{ existing: DiscordChannel; proposed: ChannelTemplate }>[];
    unchanged: DiscordChannel[];
    toDelete: DiscordChannel[];
  };
  totalChanges: number;
}

export interface ExecutionOptions {
  mode: 'MERGE' | 'SYNC' | 'REPLACE';
  confirmationPhrase?: string;
  includeDeletionsInSync?: boolean;
  publishInitialMessages?: boolean;
}

export class TemplateReconciler {
  /**
   * Generates a comprehensive diff between the current guild state and desired template
   */
  static calculateDiff(
    guildId: string,
    guildName: string,
    existingRoles: DiscordRole[],
    existingChannels: DiscordChannel[],
    template: ServerTemplate
  ): ServerDiff {
    // 1. Roles Diff
    const rolesToCreate: DiffItem<RoleTemplate>[] = [];
    const rolesToUpdate: DiffItem<{ existing: DiscordRole; proposed: RoleTemplate }>[] = [];
    const rolesUnchanged: DiscordRole[] = [];
    const matchedRoleIds = new Set<string>();

    for (const proposedRole of template.roles) {
      const match = existingRoles.find(
        r => r.name.toLowerCase() === proposedRole.name.toLowerCase()
      );

      if (!match) {
        rolesToCreate.push({
          item: proposedRole,
          reason: `Role "${proposedRole.name}" does not exist in the server.`,
        });
      } else {
        matchedRoleIds.add(match.id);
        const needsUpdate =
          match.color !== proposedRole.color ||
          match.hoist !== proposedRole.hoist ||
          match.mentionable !== proposedRole.mentionable;

        if (needsUpdate) {
          rolesToUpdate.push({
            item: { existing: match, proposed: proposedRole },
            reason: `Role properties (color, hoist, or mentionable) differ.`,
          });
        } else {
          rolesUnchanged.push(match);
        }
      }
    }

    const rolesToDelete = existingRoles.filter(
      r => !matchedRoleIds.has(r.id) && r.name !== '@everyone' && !r.managed
    );

    // 2. Categories Diff
    const existingCategories = existingChannels.filter(c => c.type === 4);
    const existingNonCategories = existingChannels.filter(c => c.type !== 4);

    const categoriesToCreate: DiffItem<ChannelTemplate>[] = [];
    const categoriesToUpdate: DiffItem<{ existing: DiscordChannel; proposed: ChannelTemplate }>[] = [];
    const categoriesUnchanged: DiscordChannel[] = [];
    const matchedCategoryIds = new Set<string>();

    for (const proposedCat of template.categories) {
      const match = existingCategories.find(
        c => c.name.toLowerCase() === proposedCat.name.toLowerCase()
      );

      if (!match) {
        categoriesToCreate.push({
          item: proposedCat,
          reason: `Category "${proposedCat.name}" is missing.`,
        });
      } else {
        matchedCategoryIds.add(match.id);
        if (match.position !== proposedCat.position) {
          categoriesToUpdate.push({
            item: { existing: match, proposed: proposedCat },
            reason: `Category position differs (${match.position} -> ${proposedCat.position}).`,
          });
        } else {
          categoriesUnchanged.push(match);
        }
      }
    }

    const categoriesToDelete = existingCategories.filter(c => !matchedCategoryIds.has(c.id));

    // 3. Channels Diff
    const channelsToCreate: DiffItem<ChannelTemplate>[] = [];
    const channelsToUpdate: DiffItem<{ existing: DiscordChannel; proposed: ChannelTemplate }>[] = [];
    const channelsUnchanged: DiscordChannel[] = [];
    const matchedChannelIds = new Set<string>();

    for (const proposedChan of template.channels) {
      const match = existingNonCategories.find(
        c => c.name.toLowerCase() === proposedChan.name.toLowerCase() && c.type === proposedChan.type
      );

      if (!match) {
        channelsToCreate.push({
          item: proposedChan,
          reason: `Channel "#${proposedChan.name}" does not exist.`,
        });
      } else {
        matchedChannelIds.add(match.id);
        const topicDiff = (proposedChan.topic || null) !== (match.topic || null);
        const positionDiff = proposedChan.position !== match.position;
        if (topicDiff || positionDiff) {
          channelsToUpdate.push({
            item: { existing: match, proposed: proposedChan },
            reason: topicDiff ? 'Channel topic/description differs.' : 'Channel position differs.',
          });
        } else {
          channelsUnchanged.push(match);
        }
      }
    }

    const channelsToDelete = existingNonCategories.filter(c => !matchedChannelIds.has(c.id));

    const totalChanges =
      rolesToCreate.length +
      rolesToUpdate.length +
      categoriesToCreate.length +
      categoriesToUpdate.length +
      channelsToCreate.length +
      channelsToUpdate.length;

    return {
      guildId,
      guildName,
      targetTemplateId: template.id,
      targetTemplateName: template.name,
      roles: {
        toCreate: rolesToCreate,
        toUpdate: rolesToUpdate,
        unchanged: rolesUnchanged,
        toDelete: rolesToDelete,
      },
      categories: {
        toCreate: categoriesToCreate,
        toUpdate: categoriesToUpdate,
        unchanged: categoriesUnchanged,
        toDelete: categoriesToDelete,
      },
      channels: {
        toCreate: channelsToCreate,
        toUpdate: channelsToUpdate,
        unchanged: channelsUnchanged,
        toDelete: channelsToDelete,
      },
      totalChanges,
    };
  }

  /**
   * Executes reconciliation against a live Discord API or simulated Demo Guild
   */
  static async execute(
    client: DiscordRestClient | null,
    isDemo: boolean,
    guildId: string,
    guildName: string,
    template: ServerTemplate,
    options: ExecutionOptions
  ): Promise<AuditRun> {
    const runId = `run-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const details: AuditRun['details'] = [];
    let rolesCreated = 0;
    let rolesUpdated = 0;
    let rolesDeleted = 0;
    let categoriesCreated = 0;
    let categoriesUpdated = 0;
    let categoriesDeleted = 0;
    let channelsCreated = 0;
    let channelsUpdated = 0;
    let channelsDeleted = 0;
    let overwritesApplied = 0;

    // Safety checks for REPLACE mode
    if (options.mode === 'REPLACE') {
      const requiredPhrase = 'CONFIRM REPLACE BLIPMADE SERVER';
      if (options.confirmationPhrase !== requiredPhrase) {
        throw new Error(`REPLACE mode requires confirmation phrase: "${requiredPhrase}"`);
      }
    }

    if (isDemo) {
      // Execute on simulated Demo Guild
      const demoGuild = db.getDemoGuild();

      // Automated backup snapshot before changes
      const backup: StructuralBackup = {
        id: `backup-${Date.now()}`,
        timestamp: new Date().toISOString(),
        guildId,
        guildName,
        reason: `Automated backup before ${options.mode} deployment`,
        data: {
          roles: demoGuild.roles.map(r => ({ id: r.id, name: r.name, color: r.color, position: r.position, permissions: r.permissions })),
          channels: demoGuild.channels.map(c => ({ id: c.id, name: c.name, type: c.type, position: c.position, topic: c.topic || undefined, parentId: c.parent_id || undefined })),
        },
      };
      db.createBackup(backup);
      details.push({
        target: 'Backup Snapshot',
        action: 'CREATED_BACKUP',
        status: 'SUCCESS',
        message: `Saved backup snapshot ${backup.id}`,
      });

      if (options.mode === 'REPLACE') {
        // Clear all channels
        channelsDeleted += demoGuild.channels.length;
        demoGuild.channels = [];
        details.push({
          target: 'All Channels',
          action: 'DELETE_CHANNELS',
          status: 'SUCCESS',
          message: 'Purged existing structure under REPLACE mode',
        });
      }

      // 1. Roles
      const roleMap = new Map<string, string>(); // name -> id
      demoGuild.roles.forEach(r => roleMap.set(r.name.toLowerCase(), r.id));

      for (const roleTmpl of template.roles) {
        const existing = demoGuild.roles.find(r => r.name.toLowerCase() === roleTmpl.name.toLowerCase());
        if (!existing) {
          const newRoleId = `role-${roleTmpl.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString().slice(-4)}`;
          demoGuild.roles.push({
            id: newRoleId,
            name: roleTmpl.name,
            color: roleTmpl.color,
            hoist: roleTmpl.hoist,
            position: demoGuild.roles.length,
            permissions: roleTmpl.permissions,
            mentionable: roleTmpl.mentionable,
          });
          roleMap.set(roleTmpl.name.toLowerCase(), newRoleId);
          rolesCreated++;
          details.push({
            target: `Role @${roleTmpl.name}`,
            action: 'CREATE_ROLE',
            status: 'SUCCESS',
            message: `Created role @${roleTmpl.name}`,
          });
        } else if (options.mode !== 'MERGE') {
          existing.color = roleTmpl.color;
          existing.hoist = roleTmpl.hoist;
          existing.mentionable = roleTmpl.mentionable;
          existing.permissions = roleTmpl.permissions;
          rolesUpdated++;
          details.push({
            target: `Role @${roleTmpl.name}`,
            action: 'UPDATE_ROLE',
            status: 'SUCCESS',
            message: `Updated role properties for @${roleTmpl.name}`,
          });
        }
      }

      // 2. Categories
      const categoryMap = new Map<string, string>(); // categoryName -> id
      demoGuild.channels
        .filter(c => c.type === 4)
        .forEach(c => categoryMap.set(c.name.toLowerCase(), c.id));

      for (const catTmpl of template.categories) {
        let catId = categoryMap.get(catTmpl.name.toLowerCase());
        if (!catId) {
          catId = `cat-${catTmpl.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString().slice(-4)}`;
          demoGuild.channels.push({
            id: catId,
            name: catTmpl.name,
            type: 4,
            position: catTmpl.position,
          });
          categoryMap.set(catTmpl.name.toLowerCase(), catId);
          categoriesCreated++;
          details.push({
            target: `Category [${catTmpl.name}]`,
            action: 'CREATE_CATEGORY',
            status: 'SUCCESS',
            message: `Created category ${catTmpl.name}`,
          });
        }
      }

      // 3. Channels
      for (const chanTmpl of template.channels) {
        const parentId = chanTmpl.categoryName
          ? categoryMap.get(chanTmpl.categoryName.toLowerCase()) || null
          : null;

        const existing = demoGuild.channels.find(
          c => c.name.toLowerCase() === chanTmpl.name.toLowerCase() && c.type === chanTmpl.type
        );

        if (!existing) {
          const chanId = `chan-${chanTmpl.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now().toString().slice(-4)}`;
          demoGuild.channels.push({
            id: chanId,
            name: chanTmpl.name,
            type: chanTmpl.type,
            position: chanTmpl.position,
            topic: chanTmpl.topic || null,
            parent_id: parentId,
            rate_limit_per_user: chanTmpl.rateLimitPerUser || 0,
          });
          channelsCreated++;
          details.push({
            target: `Channel #${chanTmpl.name}`,
            action: 'CREATE_CHANNEL',
            status: 'SUCCESS',
            message: `Created channel #${chanTmpl.name} in category ${chanTmpl.categoryName || 'root'}`,
          });
          if (chanTmpl.permissionOverwrites && chanTmpl.permissionOverwrites.length > 0) {
            overwritesApplied += chanTmpl.permissionOverwrites.length;
          }
        } else if (options.mode !== 'MERGE') {
          existing.topic = chanTmpl.topic || null;
          existing.parent_id = parentId;
          existing.position = chanTmpl.position;
          channelsUpdated++;
          details.push({
            target: `Channel #${chanTmpl.name}`,
            action: 'UPDATE_CHANNEL',
            status: 'SUCCESS',
            message: `Updated channel #${chanTmpl.name}`,
          });
        }
      }

      db.updateDemoGuild(demoGuild);
    } else {
      // LIVE DISCORD API EXECUTION
      if (!client) throw new Error('Live Discord client is not initialized');

      // Fetch live guild channels & roles
      const currentRoles = await client.getGuildRoles(guildId);
      const currentChannels = await client.getGuildChannels(guildId);

      // Automated backup snapshot before modifying live guild
      const backup: StructuralBackup = {
        id: `backup-live-${Date.now()}`,
        timestamp: new Date().toISOString(),
        guildId,
        guildName,
        reason: `Automated live backup before ${options.mode} deployment`,
        data: {
          roles: currentRoles.map(r => ({ id: r.id, name: r.name, color: r.color, position: r.position, permissions: r.permissions })),
          channels: currentChannels.map(c => ({ id: c.id, name: c.name, type: c.type, position: c.position, topic: c.topic || undefined, parentId: c.parent_id || undefined })),
        },
      };
      db.createBackup(backup);
      details.push({
        target: 'Live Server Snapshot',
        action: 'CREATED_BACKUP',
        status: 'SUCCESS',
        message: `Saved backup snapshot ${backup.id}`,
      });

      if (options.mode === 'REPLACE') {
        // Caution: Delete existing channels (safe rate-limited loop)
        for (const chan of currentChannels) {
          try {
            await client.deleteChannel(chan.id);
            channelsDeleted++;
            details.push({
              target: `Channel #${chan.name}`,
              action: 'DELETE_CHANNEL',
              status: 'SUCCESS',
            });
            await new Promise(r => setTimeout(r, 250)); // Rate-limit safety
          } catch (err: any) {
            details.push({
              target: `Channel #${chan.name}`,
              action: 'DELETE_CHANNEL',
              status: 'FAILED',
              message: err.message,
            });
          }
        }
      }

      // 1. Roles
      const roleMap = new Map<string, string>();
      currentRoles.forEach(r => roleMap.set(r.name.toLowerCase(), r.id));

      for (const roleTmpl of template.roles) {
        try {
          const existing = currentRoles.find(r => r.name.toLowerCase() === roleTmpl.name.toLowerCase());
          if (!existing) {
            const created = await client.createRole(guildId, {
              name: roleTmpl.name,
              color: roleTmpl.color,
              hoist: roleTmpl.hoist,
              permissions: roleTmpl.permissions,
              mentionable: roleTmpl.mentionable,
            });
            roleMap.set(roleTmpl.name.toLowerCase(), created.id);
            rolesCreated++;
            details.push({
              target: `Role @${roleTmpl.name}`,
              action: 'CREATE_ROLE',
              status: 'SUCCESS',
            });
            await new Promise(r => setTimeout(r, 200));
          } else if (options.mode !== 'MERGE' && !existing.managed && existing.name !== '@everyone') {
            await client.updateRole(guildId, existing.id, {
              color: roleTmpl.color,
              hoist: roleTmpl.hoist,
              mentionable: roleTmpl.mentionable,
              permissions: roleTmpl.permissions,
            });
            rolesUpdated++;
            details.push({
              target: `Role @${roleTmpl.name}`,
              action: 'UPDATE_ROLE',
              status: 'SUCCESS',
            });
            await new Promise(r => setTimeout(r, 200));
          }
        } catch (err: any) {
          details.push({
            target: `Role @${roleTmpl.name}`,
            action: 'ROLE_OPERATION',
            status: 'FAILED',
            message: err.message,
          });
        }
      }

      // 2. Categories
      const categoryMap = new Map<string, string>();
      currentChannels.filter(c => c.type === 4).forEach(c => categoryMap.set(c.name.toLowerCase(), c.id));

      for (const catTmpl of template.categories) {
        try {
          let catId = categoryMap.get(catTmpl.name.toLowerCase());
          if (!catId) {
            const created = await client.createChannel(guildId, {
              name: catTmpl.name,
              type: 4,
              position: catTmpl.position,
            });
            catId = created.id;
            categoryMap.set(catTmpl.name.toLowerCase(), catId);
            categoriesCreated++;
            details.push({
              target: `Category [${catTmpl.name}]`,
              action: 'CREATE_CATEGORY',
              status: 'SUCCESS',
            });
            await new Promise(r => setTimeout(r, 250));
          }
        } catch (err: any) {
          details.push({
            target: `Category [${catTmpl.name}]`,
            action: 'CREATE_CATEGORY',
            status: 'FAILED',
            message: err.message,
          });
        }
      }

      // 3. Channels
      for (const chanTmpl of template.channels) {
        try {
          const parentId = chanTmpl.categoryName
            ? categoryMap.get(chanTmpl.categoryName.toLowerCase()) || null
            : null;

          const existing = currentChannels.find(
            c => c.name.toLowerCase() === chanTmpl.name.toLowerCase() && c.type === chanTmpl.type
          );

          if (!existing) {
            const created = await client.createChannel(guildId, {
              name: chanTmpl.name,
              type: chanTmpl.type,
              position: chanTmpl.position,
              topic: chanTmpl.topic,
              parent_id: parentId,
              rate_limit_per_user: chanTmpl.rateLimitPerUser,
            });
            channelsCreated++;
            details.push({
              target: `Channel #${chanTmpl.name}`,
              action: 'CREATE_CHANNEL',
              status: 'SUCCESS',
            });
            await new Promise(r => setTimeout(r, 250));

            // Permission Overwrites
            if (chanTmpl.permissionOverwrites && chanTmpl.permissionOverwrites.length > 0) {
              for (const ow of chanTmpl.permissionOverwrites) {
                const targetRoleId = ow.roleName === '@everyone'
                  ? currentRoles.find(r => r.name === '@everyone')?.id || guildId
                  : roleMap.get(ow.roleName.toLowerCase());

                if (targetRoleId) {
                  await client.updateChannelOverwrite(created.id, targetRoleId, {
                    type: 0,
                    allow: ow.allow,
                    deny: ow.deny,
                  });
                  overwritesApplied++;
                }
              }
            }

            // Post initial welcome / rules message if specified
            if (options.publishInitialMessages && chanTmpl.initialMessage) {
              await client.sendMessage(created.id, chanTmpl.initialMessage);
              details.push({
                target: `Initial Message in #${chanTmpl.name}`,
                action: 'POST_INITIAL_MESSAGE',
                status: 'SUCCESS',
              });
            }
          } else if (options.mode !== 'MERGE') {
            await client.updateChannel(existing.id, {
              topic: chanTmpl.topic || null,
              parent_id: parentId,
              position: chanTmpl.position,
              rate_limit_per_user: chanTmpl.rateLimitPerUser || 0,
            });
            channelsUpdated++;
            details.push({
              target: `Channel #${chanTmpl.name}`,
              action: 'UPDATE_CHANNEL',
              status: 'SUCCESS',
            });
            await new Promise(r => setTimeout(r, 200));
          }
        } catch (err: any) {
          details.push({
            target: `Channel #${chanTmpl.name}`,
            action: 'CHANNEL_OPERATION',
            status: 'FAILED',
            message: err.message,
          });
        }
      }
    }

    const hasFailures = details.some(d => d.status === 'FAILED');
    const run: AuditRun = {
      id: runId,
      timestamp: new Date().toISOString(),
      mode: options.mode,
      guildId,
      guildName,
      isDemo,
      status: hasFailures ? 'PARTIAL' : 'SUCCESS',
      summary: {
        rolesCreated,
        rolesUpdated,
        rolesDeleted,
        categoriesCreated,
        categoriesUpdated,
        categoriesDeleted,
        channelsCreated,
        channelsUpdated,
        channelsDeleted,
        overwritesApplied,
      },
      details,
    };

    db.logAuditRun(run);
    return run;
  }
}
